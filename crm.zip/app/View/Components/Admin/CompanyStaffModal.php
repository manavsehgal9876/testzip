<?php

namespace App\View\Components\Admin;

use Illuminate\View\Component;
use App\Models\Admin\Company\Company;

class CompanyStaffModal extends Component
{
  public $companies;
  /**
   * Create a new component instance.
   *
   * @return void
   */
  public function __construct()
  {
    $this->companies = Company::where('status', '=', 1)->orderByDesc('id')->get();
  }
  /**
   * Get the view / contents that represent the component.
   *
   * @return \Illuminate\Contracts\View\View|\Closure|string
   */
  public function render()
  {
    return view('components.admin.company-staff-modal');
  }
}
