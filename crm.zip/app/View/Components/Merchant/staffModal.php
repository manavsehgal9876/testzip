<?php

namespace App\View\Components\merchant;

use Illuminate\View\Component;

class staffModal extends Component
{
  public int $merchantId;
  /**
   * Create a new component instance.
   *
   * @return void
   */
  public function __construct($merchantId)
  {
    $this->merchantId = $merchantId;
  }

  /**
   * Get the view / contents that represent the component.
   *
   * @return \Illuminate\Contracts\View\View|\Closure|string
   */
  public function render()
  {
    return view('components.merchant.staff-modal');
  }
}
