<?php

namespace App\Http\Requests\Admin\Company;

use Illuminate\Foundation\Http\FormRequest;

class CompanyRequest extends FormRequest
{
  /**
   * Determine if the user is authorized to make this request.
   *
   * @return bool
   */
  public function authorize()
  {
    return true;
  }

  /**
   * Get the validation rules that apply to the request.
   *
   * @return array<string, mixed>
   */
  public function rules()
  {
    return [
      'added_by' => ['sometimes', 'integer', 'exists:admins,id'],
      'name' => ['required', 'regex:/^[a-zA-Z0-9\s]+$/', 'max:100'],
      'email' => ['required', 'string', 'email', 'max:255', 'unique:App\Models\Admin\Company\Company,email,' . app('request')->segment(3)],
      'phone' => ['nullable', 'digits:10', 'unique:App\Models\Admin\Company\Company,phone,' . app('request')->segment(3)],
      'status' => ['nullable', 'boolean'],
      'country' => ['nullable', 'exists:App\Models\Extension\Country,id'],
      'state' => ['nullable', 'exists:App\Models\Extension\State,id'],
      'city' => ['nullable', 'exists:App\Models\Extension\City,id'],
      'address' => ['nullable', 'string', 'max:150'],
      'logo_image' => ['nullable', 'image', 'mimes:jpeg,png,jpg,webp,gif', 'max:1024'],
    ];
  }

  public function messages()
  {
    return [
      'name.regex' => 'First name must be alphanumeric only',
    ];
  }
}
