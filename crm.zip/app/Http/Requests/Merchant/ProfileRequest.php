<?php

namespace App\Http\Requests\Merchant;

use Illuminate\Validation\Rules\Password;
use Illuminate\Foundation\Http\FormRequest;

class ProfileRequest extends FormRequest
{
  /**
   * Determine if the user is authorized to make this request.
   *
   * @return bool
   */
  public function authorize()
  {
    return true;
  }

  /**
   * Get the validation rules that apply to the request.
   *
   * @return array<string, mixed>
   */
  public function rules()
  {
    return [
      'company_name' => ['required', 'string', 'max:100', 'unique:App\Models\User,company_name,' . app('request')->segment(3)],
      'name' => ['nullable', 'regex:/^[a-zA-Z0-9\s]+$/', 'max:100'],
      'email' => ['nullable', 'string', 'email', 'max:150', 'unique:App\Models\User,email,' . app('request')->segment(3)],
      'phone' => ['nullable', 'max:20'],
      'website' => ['nullable', 'max:1000'],
      'biz_category' => ['nullable'],
      'biz_industry' => ['nullable'],
      'tan_number' => ['required', 'string', 'alpha_num', 'max:10', 'unique:App\Models\User,tan_number,' . app('request')->segment(3)],
      'gst_number' => ['nullable', 'string', 'alpha_num', 'min:15', 'max:15', 'unique:App\Models\User,gst_number,' . app('request')->segment(3)],
      'pancard_number' => ['required', 'string', 'alpha_num', 'min:10', 'max:10', 'unique:App\Models\User,pancard_number,' . app('request')->segment(3)],
      'address' => ['nullable', 'string', 'max:150'],
      'country' => ['nullable', 'exists:App\Models\Extension\Country,id'],
      'state' => ['nullable', 'exists:App\Models\Extension\State,id'],
      'city' => ['nullable', 'exists:App\Models\Extension\City,id'],
      'bank_name' => ['nullable', 'regex:/^[a-zA-Z0-9\s]+$/', 'max:50'],
      'bank_branch' => ['nullable', 'string', 'max:50'],
      'ifsc_code' => ['nullable', 'string', 'max:30'],
      'bank_acc_name' => ['nullable', 'regex:/^[a-zA-Z0-9\s]+$/', 'max:100'],
      'bank_acc_no' => ['nullable', 'digits_between:10,30'],
      'cancel_cheque' => ['nullable', 'mimes:jpeg,png,jpg,docx,doc,pdf', 'max:5120'],
      'representative_name' => ['nullable', 'regex:/^[a-zA-Z0-9\s]+$/', 'max:100'],
      'representative_email' => ['nullable', 'string', 'email', 'max:150', 'unique:App\Models\User,representative_email,' . app('request')->segment(3)],
      'representative_phone' => ['nullable', 'digits_between:7,20', 'unique:App\Models\User,representative_phone,' . app('request')->segment(3)],
      'representative_department' => ['nullable', 'string', 'max:100'],
      'representative_designation' => ['nullable', 'string', 'max:100'],
      'representative_photo' => ['nullable', 'image', 'mimes:jpeg,png,jpg,gif,webp', 'max:5120'],
      'pancard' => ['sometimes', 'mimes:jpeg,png,jpg,docx,doc,pdf', 'max:5120'],
      'tan' => ['nullable', 'mimes:jpeg,png,jpg,docx,doc,pdf', 'max:5120'],
      'gst' => ['sometimes', 'mimes:jpeg,png,jpg,docx,doc,pdf', 'max:5120'],
      'logo_file' => ['nullable', 'image', 'mimes:jpeg,png,jpg,gif,webp', 'max:5120'],
      'password' => [
        'nullable', 'max:30', Password::min(8)->numbers()->letters()->symbols()->uncompromised()
      ],
    ];
  }

  public function messages()
  {
    return [
      'name.regex' => 'First name must be alphanumeric only',
      'company_name.regex' => 'Company name must be alphanumeric only',
      'bank_name.regex' => 'Bank must be alphanumeric only',
      'bank_acc_name.regex' => 'Bank account name must be alphanumeric only',
      'representative_name.regex' => 'Representative name must be alphanumeric only',
    ];
  }
}
