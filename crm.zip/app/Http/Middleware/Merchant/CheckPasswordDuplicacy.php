<?php

namespace App\Http\Middleware\Merchant;

use Closure;
use App\Models\User;
use Illuminate\Http\Request;
use App\Models\PasswordHistory;
use Illuminate\Support\Facades\Hash;

class CheckPasswordDuplicacy
{
  /**
   * Handle an incoming request.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
   * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
   */
  public function handle(Request $request, Closure $next)
  {
    $merchant = User::where('tan_number', $request->merchant_tan)->first();
    $passwordHistory = PasswordHistory::where('user_id', $merchant->id)->orderByDesc('created_at')->limit(5)->get();

    // check if any of the password in the history is the same as the current password
    foreach ($passwordHistory as $password)
      if (Hash::check($request->password, $password->password))
        return back()->withErrors('Password has been used in the past. Please choose a different password.');

    return $next($request);
  }
}
