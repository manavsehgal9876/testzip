<?php

namespace App\Http\Controllers\Admin\Auth;

use App\Models\User;
use Illuminate\View\View;
use App\Actions\LogoutAll;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Models\Merchant\Claim;
use App\Models\Merchant\Staff;
use App\Actions\UpdateLastLoginDate;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Models\Merchant\ClaimHistory;
use Illuminate\Support\Facades\Password;
use App\Models\Admin\Company\CompanyStaff;
use App\Http\Requests\Admin\Auth\LoginRequest;
use Illuminate\Auth\Notifications\ResetPassword;

class AuthController extends Controller
{

  public function dashboard(): View
  {
    $lastLogin = auth()->user()->loginHistories()->latest()->first();

    if (auth()->user()->loginHistories()->count() > 1)
      $lastLogin = auth()->user()->loginHistories()->latest()->skip(1)->first();

    $activeStaff = CompanyStaff::where('status', '=', 1)->count();
    $inActiveStaff = CompanyStaff::where('status', '=', 0)->count();
    $onHoldClaims = Claim::where('status', 6)->count();
    $rejectedClaims = Claim::where('status', 5)->count();
    $completedClaims = Claim::where('status', 4)->count();
    $inProcessClaims = Claim::where('status', 2)->count();
    $approvedClaims = Claim::where('status', 3)->count();
    $pendingClaims = Claim::where('status', 1)->count();
    $draftedClaims = Claim::where('status', 0)->count();
    $totalClaims = Claim::count();
    $allMerchants = User::count();

    $claimHistory = ClaimHistory::latest()
      ->limit(50)
      ->get();
    // \Artisan::call('config:cache');
    return view('admin.dashboard', compact('lastLogin', 'inActiveStaff', 'activeStaff', 'onHoldClaims', 'rejectedClaims', 'completedClaims', 'inProcessClaims', 'approvedClaims', 'pendingClaims', 'draftedClaims', 'totalClaims', 'allMerchants', 'claimHistory'));
  }

  public function login(LoginRequest $request)
  {
    LogoutAll::run();

    if (!Auth::guard('admin')->attempt($request->only('email', 'password'), $request->boolean('remember')))
      return redirect()->back()->withErrors('Invalid email or password');

    UpdateLastLoginDate::run(Auth::guard('admin')->user()->id, Auth::guard('admin')->user()->type);

    return redirect()->route('admin.dashboard')->with('success', 'You are logged in successfully');
  }

  public function forgotPassword(Request $request)
  {
    $request->validate([
      'email' => 'required|email|max:100|exists:admins',
    ]);

    ResetPassword::createUrlUsing(function ($user, string $token) {
      return route('admin.password.reset', ['token' => $token, 'email' => $user->email]);
    });

    $status = Password::broker('admins')->sendResetLink(
      $request->only('email')
    );

    return $status == Password::RESET_LINK_SENT
      ? back()->withErrors(__($status))
      : back()->withInput($request->only('email'))
      ->withErrors(__($status));
  }

  public function resetPasswordView(Request $request)
  {
    return view('admin.auth.set-new-password', ['request' => $request]);
  }

  public function setNewPassword(Request $request)
  {

    $request->validate([
      'token' => 'required',
      'email' => 'required|email',
      'password' => ['required', 'confirmed', 'min:6', 'max:30'],
    ]);

    // Here we will attempt to reset the user's password. If it is successful we
    // will update the password on an actual user model and persist it to the
    // database. Otherwise we will parse the error and return the response.
    $status = Password::broker('admins')->reset(
      $request->only('email', 'password', 'password_confirmation', 'token'),
      function ($user) use ($request) {
        $user->forceFill([
          'password' => $request->password,
          'remember_token' => Str::random(60),
        ])->save();
      }
    );

    // If the password was successfully reset, we will redirect the user back to
    // the application's home authenticated view. If there is an error we can
    // redirect them back to where they came from with their error message.
    if ($status == Password::PASSWORD_RESET) {
      return redirect()->route('admin.login')->with('success', __($status));
    }

    return back()->withErrors([
      'email' => [trans($status)],
    ]);
  }

  public function logout(Request $request)
  {
    Auth::guard('admin')->logout();

    $request->session()->invalidate();

    $request->session()->regenerateToken();

    return redirect()->route('admin.home');
  }
}
