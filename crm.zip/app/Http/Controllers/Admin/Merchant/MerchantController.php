<?php

namespace App\Http\Controllers\Admin\Merchant;

use App\Models\User;
use Illuminate\Http\Request;
use App\Jobs\ProcessMerchants;
use App\Imports\MerchantsImport;
use App\Http\Controllers\Controller;
use Maatwebsite\Excel\Facades\Excel;
use App\Http\Requests\ExcelFileRequest;
use App\Http\Requests\Merchant\ProfileRequest;
use Illuminate\Validation\ValidationException;
use App\Repositories\Merchant\ProfileRepository;
use App\Actions\Admin\UploadMerchantsExcelAndDispatchJob;

class MerchantController extends Controller
{
  public $ProfileRepository;

  public function __construct(ProfileRepository $ProfileRepository)
  {
    $this->ProfileRepository = $ProfileRepository;
  }
  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function index(Request $request)
  {
    $merchants = User::orderByDesc('id');

    if ($request->search)
      $merchants = $merchants->where('name', 'like', '%' . $request->search . '%')
        ->orWhere('company_name', 'like', '%' . $request->search . '%')
        ->orWhere('tan_number', 'like', '%' . $request->search . '%')
        ->orWhere('pancard_number', 'like', '%' . $request->search . '%')
        ->orWhere('gst_number', 'like', '%' . $request->search . '%');

    $merchants = $merchants->paginate(50)->withQueryString();

    return view('admin.merchant.index', compact('merchants'));
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create()
  {
    return view('admin.merchant.create');
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  // public function store(ProfileRequest $request)
  public function store(ExcelFileRequest $request)
  {
    try {
      // UploadMerchantsExcelAndDispatchJob::run($request);
      // Excel::import(new MerchantsImport, $request->excelSheet);
      return back()->with('success', 'Merchants sheet imported successfully.');
    } catch (ValidationException  $th) {
      return back()->withErrors($th->errors());
    }
  }

  /**
   * Display the specified resource.
   *
   * @param  \App\Models\User  $user
   * @return \Illuminate\Http\Response
   */
  public function show(User $user)
  {
    //
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  \App\Models\User  $user
   * @return \Illuminate\Http\Response
   */
  public function edit(User $user)
  {
    //
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  \App\Models\User  $user
   * @return \Illuminate\Http\Response
   */
  public function update(ProfileRequest $request, int $id)
  {
    try {
      $this->ProfileRepository->update($request, $id);
      return back()->with('success', 'Profile updated successfully');
    } catch (\Throwable $th) {
      dd($th);
    }
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  \App\Models\User  $user
   * @return \Illuminate\Http\Response
   */
  public function destroy(User $user)
  {
    //
  }
}
