<?php

namespace App\Http\Controllers\Admin\Merchant;

use App\Models\User;
use Illuminate\Http\Request;
use App\Models\Merchant\LTDC;
use App\Models\Admin\Form26AS;
use App\Models\Merchant\Claim;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Crypt;
use App\Mail\Notification\ClaimStatus;
use Yajra\DataTables\Facades\DataTables;
use App\Http\Requests\Merchant\ClaimRequest;
use App\Repositories\Merchant\ClaimRepository;
use Illuminate\Contracts\Encryption\DecryptException;

class ClaimController extends Controller
{
  public $ClaimRepository;

  public function __construct(ClaimRepository $ClaimRepository)
  {
    $this->ClaimRepository = $ClaimRepository;
  }
  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function index(Request $request)
  {
    // dd($request->all());
    $claims = Claim::orderByDesc('updated_at');

    if (isset($request->status))
      $claims = $claims->where([['status', '=', (int)$request->status], ['status', '!=', 0]]);
    else
      $claims =  $claims->where('status', '!=', 0);

    if (isset($request->date_from))
      $claims = $claims->whereDate('created_at', '>=', $request->date_from);

    if (isset($request->date_till))
      $claims = $claims->whereDate('created_at', '<=', $request->date_till);

    $claims = $claims->get();
    $merchants = User::orderByDesc('id')->select('id', 'name')->get();

    return view('admin.merchant.claims.index', compact('claims', 'merchants'));
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create()
  {
    //
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function store(Request $request)
  {
    //
  }

  /**
   * Display the specified resource.
   *
   * @param  \App\Models\Merchant\Claim  $claim
   * @return \Illuminate\Http\Response
   */
  public function show(string $id)
  {
    try {
      $claim = Claim::findOrFail(Crypt::decryptString($id));
      $route = route('admin.claim.update', $claim->id);
      $form26AS = Form26AS::where([['deductor_tan', '=', $claim->tan_number], ['financial_year', '=', $claim->financial_year], ['quarter', '=', $claim->quarter]])->get();
      $grandTotalOfForm26AS = array_sum(array_column($form26AS->toArray(), 'total_amount_paid'));
      $grandTotalOfTds = array_sum(array_column($form26AS->toArray(), 'total_tax_deducted'));
      $ltdcs = LTDC::where([['tan_number', '=', $claim->tan_number], ['financial_year', '=', $claim->financial_year]])->get();

      return view('admin.merchant.claims.show', compact('claim', 'route', 'form26AS', 'grandTotalOfForm26AS', 'grandTotalOfTds', 'ltdcs'));
    } catch (DecryptException $e) {
      dd($e);
    }
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  \App\Models\Merchant\Claim  $claim
   * @return \Illuminate\Http\Response
   */
  public function edit(Claim $claim)
  {
    //
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  \App\Models\Merchant\Claim  $claim
   * @return \Illuminate\Http\Response
   */
  public function update(ClaimRequest $request, Claim $claim)
  {
    try {
      if ($request->status === '3' && !isset($claim->merchant->sap_code))
        return redirect()->route('admin.claim.show', Crypt::encryptString($claim->id))->withErrors('Claim status cannot be updated as the merchant sap code is missing.');
      $this->ClaimRepository->update($request, $claim->id);
      return redirect()->route('admin.claim.show', Crypt::encryptString($claim->id))->with('success', 'Claim updated successfully');
    } catch (\Throwable $th) {
      dd($th);
    }
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  \App\Models\Merchant\Claim  $claim
   * @return \Illuminate\Http\Response
   */
  public function destroy(Claim $claim)
  {
    //
  }
}
