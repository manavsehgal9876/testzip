<?php

namespace App\Http\Controllers\Admin\Company;

use Illuminate\Support\Str;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Mail;
use App\Models\Admin\Company\Company;
use App\Mail\Admin\Company\NewStaffAdded;
use App\Models\Admin\Company\CompanyStaff;
use App\Mail\Admin\Company\StaffDetailModified;
use App\Repositories\Admin\CompanyStaffRepository;
use App\Http\Requests\Admin\Company\CompanyStaffRequest;

class CompanyStaffController extends Controller
{
  public $CompanyStaffRepository;

  public function __construct(CompanyStaffRepository $CompanyStaffRepository)
  {
    $this->CompanyStaffRepository = $CompanyStaffRepository;
  }
  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function index(int $status = null)
  {
    $companyStaffs = CompanyStaff::orderByDesc('id');
    if (isset($status))
      $companyStaffs->where('status', $status);
    $companyStaffs = $companyStaffs->get();
    return view('admin.company.staff.index', compact('companyStaffs'));
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create()
  {
    $companies = Company::where('status', '=', 1)->orderByDesc('id')->get();
    return view('admin.company.staff.create', compact('companies'));
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function store(CompanyStaffRequest $request)
  {
    try {
      $password = Str::random(6) . 'PAYu$' . mt_rand(100, 999);
      $staff = $this->CompanyStaffRepository->store($request, ['password' => $password]);
      Mail::to(Str::lower($staff->email))->send(new NewStaffAdded(compact('staff', 'password')));
      return redirect()->route('admin.company-staff.create')->with('success', 'Staff added successfully');
    } catch (\Throwable $th) {
      dd($th);
    }
  }

  /**
   * Display the specified resource.
   *
   * @param  \App\Models\Admin\Company\CompanyStaff  $companyStaff
   * @return \Illuminate\Http\Response
   */
  public function show(CompanyStaff $companyStaff)
  {
    //
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  \App\Models\Admin\Company\CompanyStaff  $companyStaff
   * @return \Illuminate\Http\Response
   */
  public function edit(CompanyStaff $companyStaff)
  {
    //
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  \App\Models\Admin\Company\CompanyStaff  $companyStaff
   * @return \Illuminate\Http\Response
   */
  public function update(CompanyStaffRequest $request, CompanyStaff $companyStaff)
  {
    try {
      $this->CompanyStaffRepository->update($request, $companyStaff->id);
      $companyStaff = CompanyStaff::find($companyStaff->id);
      Mail::to($companyStaff->email)->send(new StaffDetailModified($companyStaff));
      return redirect()->route('admin.company-staff.index')->with('success', 'Staff updated successfully');
    } catch (\Throwable $th) {
      dd($th);
    }
  }

  public function toggleStatus(int $id)
  {
    try {
      $this->CompanyStaffRepository->toggleStatus($id);
      return redirect()->route('admin.company-staff.index')->with('success', 'Staff status updated successfully');
    } catch (\Throwable $th) {
      dd($th);
    }
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  \App\Models\Admin\Company\CompanyStaff  $companyStaff
   * @return \Illuminate\Http\Response
   */
  public function destroy(CompanyStaff $companyStaff)
  {
    try {
      $this->CompanyStaffRepository->destroy($companyStaff->id);
      return redirect()->route('admin.company-staff.index')->with('success', 'Staff deleted successfully');
    } catch (\Throwable $th) {
      dd($th);
    }
  }
}
