<?php

namespace App\Http\Controllers\Admin\Company;

use App\Http\Controllers\Controller;
use App\Models\Admin\Company\Company;
use App\Repositories\Admin\CompanyRepository;
use App\Http\Requests\Admin\Company\CompanyRequest;

class CompanyController extends Controller
{
  public $CompanyRepository;

  public function __construct(CompanyRepository $CompanyRepository)
  {
    $this->CompanyRepository = $CompanyRepository;
  }
  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function index()
  {
    $companies = Company::orderByDesc('id')->get();
    return view('admin.company.index', compact('companies'));
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create()
  {
    //
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function store(CompanyRequest $request)
  {
    try {
      $this->CompanyRepository->store($request);
      return back()->with('success', 'Company created successfully.');
    } catch (\Throwable $th) {
      dd($th);
    }
  }

  /**
   * Display the specified resource.
   *
   * @param  \App\Models\Admin\Company\Company  $company
   * @return \Illuminate\Http\Response
   */
  public function show(Company $company)
  {
    //
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  \App\Models\Admin\Company\Company  $company
   * @return \Illuminate\Http\Response
   */
  public function edit(Company $company)
  {
    //
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  \App\Models\Admin\Company\Company  $company
   * @return \Illuminate\Http\Response
   */
  public function update(CompanyRequest $request, Company $company)
  {
    try {
      $this->CompanyRepository->update($request, $company->id);
      return back()->with('success', 'Company updated successfully.');
    } catch (\Throwable $th) {
      dd($th);
    }
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  \App\Models\Admin\Company\Company  $company
   * @return \Illuminate\Http\Response
   */
  public function destroy(Company $company)
  {
    try {
      $this->CompanyRepository->destroy($company->id);
      return back()->with('success', 'Company deleted successfully.');
    } catch (\Throwable $th) {
      dd($th);
    }
  }
}
