<?php

namespace App\Http\Controllers\AdminStaff\Merchant;

use Illuminate\Http\Request;
use App\Models\Merchant\LTDC;
use App\Models\Admin\Form26AS;
use App\Models\Merchant\Claim;
use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Crypt;
use App\Mail\Notification\ClaimStatus;
use App\Models\Merchant\LTDCCollection;
use Illuminate\Support\Facades\Storage;
use App\Actions\Merchant\Claim\GetLTDCInfo;
use App\Http\Requests\Merchant\ClaimRequest;
use App\Repositories\Merchant\ClaimRepository;
use App\Actions\Merchant\Claim\FormSixteenPDFParser;
use Illuminate\Contracts\Encryption\DecryptException;
use App\Actions\Merchant\LTDCandForm26ASCalculations\CalculateLtdcAndForm26;

class ClaimController extends Controller
{
  public $ClaimRepository;

  public function __construct(ClaimRepository $ClaimRepository)
  {
    $this->ClaimRepository = $ClaimRepository;
  }
  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function index(Request $request)
  {
    $claims = Claim::orderByDesc('updated_at')->where('staff_id', auth()->user()->id);

    if (isset($request->status))
      $claims = $claims->where([['status', '=', (int)$request->status], ['status', '!=', 0]]);
    else
      $claims =  $claims->where('status', '!=', 0);

    if (isset($request->status) && $request->status === '4') {
      if (isset($request->date_from))
        $claims = $claims->whereDate('payment_date', '>=', $request->date_from);

      if (isset($request->date_till))
        $claims = $claims->whereDate('payment_date', '<=', $request->date_till);
    }


    if (isset($request->status) && $request->status !== '4') {
      if (isset($request->date_from))
        $claims = $claims->whereDate('created_at', '>=', $request->date_from);

      if (isset($request->date_till))
        $claims = $claims->whereDate('created_at', '<=', $request->date_till);
    }

    $claims = $claims->get();
    return view('adminStaff.merchant.claims.index', compact('claims'));
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create()
  {
    //
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function store(Request $request)
  {
    //
  }

  /**
   * Display the specified resource.
   *
   * @param  \App\Models\Merchant\Claim  $claim
   * @return \Illuminate\Http\Response
   */
  public function show(string $id)
  {
    try {
      $claim = Claim::findOrFail(Crypt::decryptString($id));
      $route = route('adminStaff.claim.update', $claim->id);
      $form26AS = Form26AS::where([['deductor_tan', '=', $claim->tan_number], ['financial_year', '=', $claim->financial_year], ['quarter', '=', $claim->quarter]])->get();
      $grandTotalOfForm26AS = array_sum(array_column($form26AS->toArray(), 'total_amount_paid'));
      $grandTotalOfTds = array_sum(array_column($form26AS->toArray(), 'total_tax_deducted'));
      $ltdcs = LTDC::where([['tan_number', '=', $claim->tan_number], ['financial_year', '=', $claim->financial_year]])->get();

      return view('adminStaff.merchant.claims.show', compact('claim', 'route', 'form26AS', 'grandTotalOfForm26AS', 'grandTotalOfTds', 'ltdcs'));
    } catch (DecryptException $e) {
      dd($e);
    }
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  \App\Models\Merchant\Claim  $claim
   * @return \Illuminate\Http\Response
   */
  public function edit(Claim $claim)
  {
    //
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  \App\Models\Merchant\Claim  $claim
   * @return \Illuminate\Http\Response
   */
  public function update(ClaimRequest $request, Claim $claim)
  {
    try {
      if ($request->status === '3' && !isset($claim->merchant->sap_code))
        return redirect()->route('adminStaff.claim.show', Crypt::encryptString($claim->id))->withErrors('Claim status cannot be updated as the merchant sap code is missing.');

      $this->ClaimRepository->update($request, $claim->id);
      return redirect()->route('adminStaff.claim.show', Crypt::encryptString($claim->id))->with('success', 'Claim updated successfully');
    } catch (\Throwable $th) {
      dd($th);
    }
  }

  public function recalculateClaim($id): RedirectResponse
  {
    try {
      $claim = Claim::findOrFail($id);

      $tanNumber = $claim->tan_number;
      $assessmentYear = $claim->asst_year;
      $financialYear = $claim->financial_year;
      $quarter = $claim->quarter;

      LTDCCollection::where([['tan_number', '=', $tanNumber], ['financial_year', '=', $financialYear]])->delete();

      CalculateLtdcAndForm26::run($tanNumber, $financialYear, explode('-', $financialYear)[0], $quarter);

      $pdfResponse['ltdcInfo'] = GetLTDCInfo::run($tanNumber, $assessmentYear, $quarter);

      if ($claim->original_tds_claim_amount === null)
        $claim->update(['original_tds_claim_amount' => $claim->tds_claim_amount]);

      $claim->update([
        'ltdc' => $pdfResponse['ltdcInfo']['ltdc_available'],
        'ltdc_total_limit' => $pdfResponse['ltdcInfo']['ltdc_total_limit'],
        'ltdc_rate' => $pdfResponse['ltdcInfo']['ltdc_rate'],
        'tdc_limit' => $pdfResponse['ltdcInfo']['tdc_limit_available'],
        'status' => 2,
        'rate_of_tds' => ($claim->tds_claim_amount / $claim->amount_credited) * 100,
      ]);

      return back()->with('success', 'Claim updated successfully');
    } catch (\Throwable $th) {
      dd($th);
      return back()->withErrors($th->getMessage());
    }
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  \App\Models\Merchant\Claim  $claim
   * @return \Illuminate\Http\Response
   */
  public function destroy(Claim $claim)
  {
    //
  }
}
