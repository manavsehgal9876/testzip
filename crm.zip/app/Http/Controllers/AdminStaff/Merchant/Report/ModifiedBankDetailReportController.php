<?php

namespace App\Http\Controllers\AdminStaff\Merchant\Report;

use Illuminate\View\View;
use App\Models\Merchant\BankDetail;
use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Database\Eloquent\Builder;

class ModifiedBankDetailReportController extends Controller
{
  public function show(): View
  {
    $bankDetails = BankDetail::where([['is_approved', '=', 0], ['status', '=', 1]])->whereHas('merchant', function (Builder $query) {
      $query->where('sap_code', '!=', null);
    })->get();
    return view('adminStaff.merchant.report.modified-bank-detail-report', compact('bankDetails'));
  }

  public function setApproved(int $id): RedirectResponse
  {
    BankDetail::find($id)->update(['is_approved' => 1]);
    return back()->with('success', 'Bank detail has been approved.');
  }
}
