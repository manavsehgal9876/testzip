<?php

namespace App\Http\Controllers\AdminStaff\Merchant;

use App\Models\User;
use Illuminate\Http\Request;
use App\Models\Merchant\Staff;
use App\Http\Controllers\Controller;
use App\Mail\Merchant\Staff\NewStaffMail;
use App\Http\Requests\Merchant\StaffRequest;
use App\Repositories\Merchant\StaffRepository;

class StaffController extends Controller
{
  public $StaffRepository;

  public function __construct(StaffRepository $StaffRepository)
  {
    $this->StaffRepository = $StaffRepository;
  }
  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function index(Request $request)
  {
    $staffs = Staff::where('merchant_id', (int)$request->id)->orderByDesc('id')->get();
    $merchantId = (int)$request->id;
    $merchant = User::find($merchantId);
    return view('adminStaff.merchant.staff.index', compact('staffs', 'merchantId', 'merchant'));
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create()
  {
    //
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function store(StaffRequest $request)
  {
    $this->StaffRepository->store($request);
    return redirect()->route('adminStaff.merchant.staff.index', ['id' => $request->merchant_id])->with('success', 'Staff created successfully');
  }

  /**
   * Display the specified resource.
   *
   * @param  \App\Models\Merchant\Staff  $staff
   * @return \Illuminate\Http\Response
   */
  public function show(Staff $staff)
  {
    //
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  \App\Models\Merchant\Staff  $staff
   * @return \Illuminate\Http\Response
   */
  public function edit(Staff $staff)
  {
    //
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  \App\Models\Merchant\Staff  $staff
   * @return \Illuminate\Http\Response
   */
  public function update(StaffRequest $request, Staff $staff)
  {
    $this->StaffRepository->update($request, $staff->id);
    return redirect()->route('adminStaff.merchant.staff.index', ['id' => $staff->merchant_id])->with('success', 'Staff updated successfully');
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  \App\Models\Merchant\Staff  $staff
   * @return \Illuminate\Http\Response
   */
  public function destroy(Staff $staff)
  {
    $this->StaffRepository->destroy($staff->id);
    return redirect()->route('adminStaff.merchant.staff.index', ['id' => $staff->merchant_id])->with('success', 'Staff deleted successfully');
  }
}
