<?php

namespace App\Http\Controllers\Merchant;

use Illuminate\View\View;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests\Merchant\ProfileRequest;
use App\Repositories\Merchant\ProfileRepository;

class ProfileController extends Controller
{
  public $ProfileRepository;

  public function __construct(ProfileRepository $ProfileRepository)
  {
    $this->ProfileRepository = $ProfileRepository;
  }

  public function profile(): View
  {
    $merchant = auth()->user();
    return view('merchant.profile.profile', compact('merchant'));
  }

  public function update(ProfileRequest $request, int $id)
  {
    try {
      $this->ProfileRepository->update($request, $id);
      return redirect()->route('merchant.profile')->with('success', 'Profile updated successfully');
    } catch (\Throwable $th) {
      dd($th);
    }
  }
}
