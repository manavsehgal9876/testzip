<?php

namespace App\Repositories\Merchant;

use Carbon\Carbon;
use App\Models\Merchant\BankDetail;
use App\Repositories\BaseRepository;
use Illuminate\Support\Facades\Mail;
use App\Mail\Notification\OldBankAccountEnabled;
use App\Mail\Notification\NewMerchantBankAccountToAdmin;

class BankDetailRepository extends BaseRepository
{

  public function store($request)
  {
    $this->handleFiles($request);
    $bankDetail = BankDetail::create($request->except('_token', 'cheque'));
    Mail::to(config('myconfig.TDS_SUPER_EMAIL'))->send(new NewMerchantBankAccountToAdmin([
      'merchantDetails' => $bankDetail->merchant,
      'message' => 'A new bank account has been created by one of our merchants, below are the details of the account.'
    ]));
    return true;
  }

  public function update($request, $id)
  {
    $bankDetail = BankDetail::find($id);
    $this->handleFiles($request, $bankDetail);
    $bankDetail->update($request->except('_token', '_method', 'cheque'));
    Mail::to(config('myconfig.TDS_SUPER_EMAIL'))->send(new NewMerchantBankAccountToAdmin([
      'merchantDetails' => $bankDetail->merchant,
      'message' => 'A bank account has modified by one of our merchants, below are the details of the account.'
    ]));
    return true;
  }

  public function handleFiles($request, $bankDetail = null)
  {
    if ($request->hasfile('cheque')) :
      $request->request->add(['cancel_cheque' => $this->handleSingleFileUpload($request->cheque, 'uploads/merchant/')]);
      if (isset($bankDetail))
        $this->handleDeleteFile($bankDetail->cancel_cheque, 'merchant/');
    endif;
    return true;
  }

  public function toggleStatus($id)
  {

    $bankDetail = BankDetail::find($id);
    $bankDetail->status = $bankDetail->status ? 0 : 1;
    $bankDetail->disabled_at = $bankDetail->status ? $bankDetail->disabled_at : Carbon::now();
    $bankDetail->enabled_at = $bankDetail->status ? Carbon::now() : $bankDetail->enabled_at;
    $bankDetail->save();

    if ($bankDetail->status) {
      BankDetail::where([['merchant_id', $bankDetail->merchant_id], ['id', '!=', $bankDetail->id]])->update(['status' => 0]);
      $bankDetail->update(['is_approved' => 0]);
      Mail::to(config('myconfig.TDS_SUPER_EMAIL'))->send(new OldBankAccountEnabled(['merchant' => $bankDetail->merchant]));
    }

    return $bankDetail;
  }

  public function destroy($id)
  {
    $bankDetail = BankDetail::find($id);
    $this->handleDeleteFile($bankDetail->cancel_cheque, 'merchant/');
    $bankDetail->delete();
  }
}
