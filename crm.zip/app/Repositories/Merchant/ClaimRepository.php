<?php

namespace App\Repositories\Merchant;

use App\Models\Merchant\LTDC;
use App\Models\Merchant\Claim;
use App\Repositories\BaseRepository;
use Illuminate\Support\Facades\Mail;
use App\Mail\Merchant\Claim\NewClaim;
use App\Mail\Notification\ClaimStatus;
use App\Models\CompanyStaffAssignedClaim;

class ClaimRepository extends BaseRepository
{
  public function store($request): bool
  {
    if (Claim::where('claim_id', '=', $this->generateClaimId($request))->exists())
      return false;

    $this->handleFiles($request);

    $request->merge(['merchant_id' => auth()->user()->id, 'tan_number' => auth()->user()->tan_number, 'merchant_company_name' => auth()->user()->company_name, 'added_by' => auth()->user()->name, 'claim_id' => $this->generateClaimId($request)]);

    $claim = Claim::create($request->except('_token', 'form16_file'));

    $claim->history()->create($request->only('status', 'claim_document_status', 'remark', 'attachment') + ['claim_id' => $claim->id, 'updated_by' => auth()->user()->id, 'updated_by_role' => auth()->user()->type]);

    if ($claim->status === '1') {
      CompanyStaffAssignedClaim::create([
        'claim_id' => $claim->id,
        'staff_id' => getDefaultStaffID()
      ]);
      $claim->update(['staff_id' => getDefaultStaffID()]);
    }

    LTDC::where([['tan_number', '=', $request->tan_number], ['financial_year', '=', $request->financial_year]])
      ->update(['remaning_limit' => $request->tdc_limit]);

    Mail::to(config('myconfig.TDS_SUPER_EMAIL'))->send(new NewClaim([
      'claim' => $claim,
      'merchant' => auth()->user(),
    ]));

    return true;
  }

  public function generateClaimId($request): string
  {
    $quarter = $request->quarter;
    $financialYear = $request->financial_year;
    $certificate_no = $request->certificate_no;
    return "TDSRm#Q{$quarter}-{$financialYear}#{$certificate_no}";
  }

  public function update($request, $id)
  {
    $claim = Claim::find($id);

    if ($claim->status === 0 && (int)$request->status !== 0) {
      CompanyStaffAssignedClaim::create([
        'claim_id' => $claim->id,
        'staff_id' => getDefaultStaffID()
      ]);
      $claim->update(['staff_id' => getDefaultStaffID()]);
    }

    $this->handleFiles($request, $claim);

    if ($claim->original_tds_claim_amount === null)
      $claim->update(['original_tds_claim_amount' => $claim->tds_claim_amount]);

    $claim->update($request->only('ltdc', 'ltdc_total_limit', 'ltdc_rate', 'tdc_limit', 'status', 'amount_credited', 'tds_claim_amount', 'rate_of_tds', 'form16'));
    $history = $claim->history()->create($request->only('status', 'claim_document_status', 'remark', 'attachment') + ['claim_id' => $claim->id, 'updated_by' => auth()->user()->id, 'updated_by_role' => auth()->user()->type, 'total_paid_amount' => $request->paid_amount, 'tds_claim_amount' => $request->claim_amount]);

    if ($request->status === '3' || $request->status === '4' || $request->status === '5')
      Mail::to($claim->merchant->primaryStaff->email)->send(new ClaimStatus([
        'history' =>  $history,
      ]));

    return $history;
  }

  public function handleFiles($request, $claim = null): bool
  {
    if ($request->hasfile('form16_file')) :
      $request->request->add(['form16' => $this->handleSingleFileUpload($request->form16_file, 'uploads/claim/')]);
      if (isset($claim))
        $this->handleDeleteFile($claim->form16, 'claim/');
    endif;
    if ($request->hasfile('attachment_file')) :
      $request->request->add(['attachment' => $this->handleSingleFileUpload($request->attachment_file, 'uploads/claim/')]);
      if (isset($claim))
        $this->handleDeleteFile($claim->attachment, 'claim/');
    endif;
    return true;
  }
}
