<?php

namespace App\Repositories\Merchant;

use Carbon\Carbon;
use Illuminate\Support\Str;
use App\Models\Merchant\Staff;
use App\Repositories\BaseRepository;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use App\Mail\Merchant\Staff\NewStaffMail;

class StaffRepository extends BaseRepository
{

  public function store($request): bool
  {
    $this->handleFiles($request);

    $request->merge(['password' => 'password@9888']);

    if (!isset($request->merchant_id))
      $request->merge(['merchant_id' => Auth::user()->id]);

    $staff = Staff::create($request->except('_token', 'photo'));

    Mail::to(Str::lower($staff->email))->send(new NewStaffMail([
      'merchant' => $staff->merchant,
      'staff' => $staff,
      'subject' => 'Merchant MR Registered',
    ]));

    if ((bool)$request->is_primary)
      Staff::where([['merchant_id', $staff->merchant_id], ['id', '!=', $staff->id]])->update(['is_primary' => 0]);

    return true;
  }

  public function update($request, $id): bool
  {
    $staff = Staff::find($id);
   
    $this->handleFiles($request, $staff);

    if ($request->working == 0)
      $request->request->add(['left_at' => Carbon::now()]);

    $staff->update($request->except('_token', '_method', 'photo'));

    if ((bool)$request->is_primary)
      Staff::where([['merchant_id', $staff->merchant_id], ['id', '!=', $staff->id]])->update(['is_primary' => 0]);

    Mail::to(Str::lower($staff->email))->send(new NewStaffMail([
      'merchant' => $staff->merchant,
      'staff' => $staff,
      'subject' => 'MR Details Updated',
    ]));

    return true;
  }

  public function handleFiles($request, $staff = null): bool
  {
    if ($request->hasfile('photo')) :

      $request->request->add(['image' => $this->handleSingleFileUpload($request->photo, 'uploads/merchant/')]);

      if (isset($staff))
        $this->handleDeleteFile($staff->image, 'merchant/');

    endif;
    return true;
  }

  public function destroy($id): void
  {
    $staff = Staff::find($id);
    $this->handleDeleteFile($staff->image, 'merchant/');
    $staff->delete();
  }
}
