<?php

namespace App\Repositories\Admin;

use App\Repositories\BaseRepository;
use App\Models\Admin\Company\Company;

class CompanyRepository extends BaseRepository
{
  public function store($request)
  {
    $this->handleFiles($request);
    $request->merge(['added_by' => auth()->user()->id]);
    Company::create($request->except('_token', 'logo_image'));
    return true;
  }

  public function update($request, $id)
  {
    $company = Company::find($id);
    $this->handleFiles($request, $company);
    $company->update($request->except('_token', '_method', 'logo_image'));
    return true;
  }

  public function handleFiles($request, $company = null)
  {
    if ($request->hasfile('logo_image')) :
      $request->request->add(['logo' => $this->handleSingleFileUpload($request->logo_image, 'uploads/company/')]);
      if (isset($company))
        $this->handleDeleteFile($company->logo, 'company/');
    endif;
    return true;
  }

  public function destroy($id)
  {
    $company = Company::find($id);
    $this->handleDeleteFile($company->logo, 'company/');
    $company->delete();
  }
}
