<?php

namespace App\Jobs;

use Illuminate\Bus\Batchable;
use Illuminate\Bus\Queueable;
use App\Imports\ImportForm26AS;
use App\Imports\MerchantsImport;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\BeforeImportForm26AS;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Queue\Middleware\WithoutOverlapping;

class AfterForm26ASImport implements ShouldQueue
{
  use Dispatchable, InteractsWithQueue, Queueable, SerializesModels, Batchable;
  /**
   * Create a new job instance.
   *
   * @return void
   */
  public function __construct(protected $data)
  {
  }

  /**
   * Execute the job.
   *
   * @return void
   */
  public function handle()
  {
    Excel::queueImport(new ImportForm26AS, $this->data['file']);
  }


  // public function middleware()
  // {
  //   return [new WithoutOverlapping($this->data['file'])];
  // }
}
