<?php

namespace App\Models\Merchant;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LTDC extends Model
{
  use HasFactory;

  protected $table = 'ltdc';

  protected $guarded = ['id'];
}
