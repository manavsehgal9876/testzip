<?php

namespace App\Models;

use Illuminate\Support\Str;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Support\Facades\Hash;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Admin extends Authenticatable
{
  use HasApiTokens, HasFactory, Notifiable;

  protected $guarded = ['id'];

  protected $hidden = [
    'password',
    'remember_token',
  ];

  protected function password(): Attribute
  {
    return Attribute::make(
      set: fn ($value) => Hash::make($value),
    );
  }

  protected function email(): Attribute
  {
    return Attribute::make(
      set: fn ($value) => Str::lower($value),
    );
  }

  public function loginHistories(): HasMany
  {
    return $this->hasMany(LoginHistory::class, 'user_id')->whereIn('type', ['Admin', 'Super Admin']);
  }
}
