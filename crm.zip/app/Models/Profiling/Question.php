<?php

namespace App\Models\Profiling;

use Illuminate\Database\Eloquent\Model;
use App\Models\Profiling\QuestionOption;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Question extends Model
{
  use HasFactory;

  protected $table = 'cpr_questions';

  protected $guarded = ['id'];

  public function answers()
  {
    return $this->hasMany(QuestionOption::class, 'question_id', 'id');
  }

  public function stages()
  {
    return $this->belongsToMany(Stage::class, 'cpr_stage_mapped_questions', 'question_id', 'stage_id');
  }
}
