<?php

namespace App\Models\Profiling;

use App\Models\Profiling\Stage;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Tag extends Model
{
  use HasFactory;

  protected $table = 'cpr_tags';

  protected $guarded = ['id'];

  public function stages()
  {
    return $this->belongsToMany(Stage::class, 'cpr_stage_mapped_tags', 'tag_id', 'stage_id');
  }
}
