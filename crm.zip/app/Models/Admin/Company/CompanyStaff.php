<?php

namespace App\Models\Admin\Company;

use Illuminate\Support\Str;
use App\Models\LoginHistory;
use App\Models\Merchant\Claim;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Support\Facades\Hash;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class CompanyStaff extends Authenticatable
{
  use HasApiTokens, HasFactory, Notifiable;

  protected $guarded = ['id'];

  protected function password(): Attribute
  {
    return Attribute::make(
      set: fn ($value) => Hash::make($value),
    );
  }

  protected function email(): Attribute
  {
    return Attribute::make(
      set: fn ($value) => Str::lower($value),
    );
  }

  public function getFullNameAttribute()
  {
    return ucwords("{$this->first_name} {$this->last_name}");
  }

  public function company()
  {
    return $this->hasOne(Company::class, 'id', 'assign_entity');
  }

  public function claims()
  {
    return $this->belongsToMany(Claim::class, 'company_staff_assigned_claims', 'staff_id', 'claim_id');
  }

  public function assignedClaims()
  {
    return $this->hasMany(Claim::class, 'staff_id');
  }

  public function getAssignedClaimsCountAttribute()
  {
    return $this->claims()->where('status', 0)->count();
  }

  public function getClosedClaimsCountAttribute()
  {
    return $this->claims()->where('status', 4)->count();
  }

  public function loginHistories(): HasMany
  {
    return $this->hasMany(LoginHistory::class, 'user_id')->where('type', 'staff');
  }
}
