<?php

namespace App\Exports\Claim;

use App\Models\Merchant\LTDC;
use App\Models\Admin\Form26AS;
use App\Models\Merchant\Claim;
use App\Models\Admin\GlAccount;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;

class ApprovedClaimReportExport implements FromArray, WithColumnFormatting, WithHeadings, ShouldAutoSize, WithStyles
{
  public function styles(Worksheet $sheet)
  {
    return [
      1 => ['font' => ['bold' => true]],
    ];
  }

  public function columnFormats(): array
  {
    return [
      'E' => NumberFormat::FORMAT_TEXT,
    ];
  }

  public function headings(): array
  {
    return [
      ['#', 'Merchant Name', 'SAP Code', 'Ifsc Code', 'Account No', 'Tan No', 'Pan No', 'Claim Date', 'Period From', 'Period To', 'QTR', 'FY', 'Total Amount Paid/Credited', 'TDS Claim Amount', '26AS Amount', 'ClaimTDS %', 'Certificate No', 'Last Update', 'TDS Section', 'Claim ID', 'Reference', 'Payu KAM Email ID', 'MR Email ID', 'LTDC Total Limit', 'LTDC Limit Available', 'LDC Available', 'LDC Applied', 'GL Account', 'GL Account Description', 'Original TDS Claim Amount', 'Staff Response']
    ];
  }

  public function getPeriodFromTo(string $periodFromTo, string $financialYear): array
  {
    $calculatedFinancialYear = substr($financialYear, 2, 2);
    switch ($periodFromTo) {
      case 'Apr-June':
        $periodFrom =  '01-Apr-' . $calculatedFinancialYear;
        $periodTo  = '30-Jun-' . $calculatedFinancialYear;
        break;

      case 'July-Sept':
        $periodFrom =  '01-Jul-' . $calculatedFinancialYear;
        $periodTo  = '30-Sept-' . $calculatedFinancialYear;
        break;

      case 'Oct-Dec':
        $periodFrom =  '01-Oct-' . $calculatedFinancialYear;
        $periodTo  = '31-Dec-' . $calculatedFinancialYear;
        break;

      case 'Jan-Mar':
        $calculatedFinancialYear = substr($financialYear, 5);
        $periodFrom =  '01-Jan-' . $calculatedFinancialYear;
        $periodTo  = '31-Mar-' . $calculatedFinancialYear;
        break;

      default:
        $periodFrom =  "";
        $periodTo  = "";
        break;
    }
    return compact('periodFrom', 'periodTo');
  }

  public function array(): array
  {
    $claims = Claim::where('status', '=', 3)->get();
    $approvedClaims = [];

    foreach ($claims as $key => $claim) {
      $srNo = ++$key;

      $getPeriodFromTo = self::getPeriodFromTo($claim->period_from_to, $claim->financial_year);

      $ltdc = LTDC::where([['tan_number', '=', $claim->tan_number], ['financial_year', '=', $claim->financial_year]])->first();

      $form26AS = Form26AS::where([['deductor_tan', '=', $claim->tan_number], ['financial_year', '=', $claim->financial_year], ['quarter', '=', $claim->quarter]])->get();
      $grandTotalOfForm26AS = array_sum(array_column($form26AS->toArray(), 'total_tax_deducted'));

      $approvedClaims[$key]['#'] = $srNo;
      $approvedClaims[$key]['Merchant Name'] = $claim->merchant->company_name;
      $approvedClaims[$key]['SAP Code'] = $claim->merchant->sap_code;
      $approvedClaims[$key]['Ifsc Code'] = $claim->merchant->activeBankAccount->ifsc;
      $approvedClaims[$key]['Account No'] = $claim->merchant->activeBankAccount->account_number;
      $approvedClaims[$key]['Tan No'] = $claim->merchant->tan_number;
      $approvedClaims[$key]['Pan No'] = $claim->merchant->pancard_number;
      $approvedClaims[$key]['Claim Date'] = $claim->created_at->format('m/d/Y');
      $approvedClaims[$key]['Period From'] = $getPeriodFromTo['periodFrom'];
      $approvedClaims[$key]['Period To'] = $getPeriodFromTo['periodTo'];
      $approvedClaims[$key]['QTR'] = 'Q' . $claim->quarter . '-' . $claim->financial_year;
      $approvedClaims[$key]['FY'] = $claim->financial_year;
      $approvedClaims[$key]['Total Amount Paid/Credited'] = $claim->amount_credited;
      $approvedClaims[$key]['TDS Claim Amount'] = $claim->tds_claim_amount;
      $approvedClaims[$key]['26AS Amount'] = $grandTotalOfForm26AS;
      $approvedClaims[$key]['ClaimTDS %'] = $claim->rate_of_tds;
      $approvedClaims[$key]['Certificate No'] = $claim->certificate_no;
      $approvedClaims[$key]['Last Update'] = $claim->history[0]->created_at->format('m/d/Y');
      $approvedClaims[$key]['TDS Section'] = $claim->nature_of_tds;
      $approvedClaims[$key]['Claim ID'] = $claim->claim_id;
      $approvedClaims[$key]['Reference'] = substr($claim->claim_id, 6);
      $approvedClaims[$key]['Payu KAM Email ID'] = $claim->merchant?->kamStaff?->email;
      $approvedClaims[$key]['MR Email ID'] = $claim->merchant?->primaryStaff?->email;
      // $approvedClaims[$key]['LDC Limit Available'] = (isset($ltdc) && $ltdc->remaning_limit !== 0.00) ? $ltdc->remaning_limit : '0';
      $approvedClaims[$key]['LTDC Total Limit'] = ($claim->ltdc_total_limit !== 0.00) ? $claim->ltdc_total_limit : '0';
      $approvedClaims[$key]['LTDC Limit Available'] = ($claim->tdc_limit !== 0.00) ? $claim->tdc_limit : '0';
      $approvedClaims[$key]['LDC Available'] = isset($ltdc) ? 'Yes' : 'No';
      if ($claim->ltdc === 'Yes')
        $approvedClaims[$key]['LDC Applied'] = (($claim->rate_of_tds !== $claim->ltdc_rate || $claim->tdc_limit === 0.00) && $claim->ltdc === 'Yes') ? 'No' : 'Yes';
      else
        $approvedClaims[$key]['LDC Applied'] = 'No';
      $approvedClaims[$key]['GL Account'] = GlAccount::where('financial_year', '=', $claim->financial_year)->first()?->gl_number;
      $approvedClaims[$key]['GL Account Description'] = GlAccount::where('financial_year', '=', $claim->financial_year)->first()?->gl_description;
      $approvedClaims[$key]['Original TDS Claim Amount'] = $claim->original_tds_claim_amount;
      $approvedClaims[$key]['Staff Response'] = $claim?->history?->where('status', '=', 3)?->first()->remark;
    }

    return $approvedClaims;
  }
}
