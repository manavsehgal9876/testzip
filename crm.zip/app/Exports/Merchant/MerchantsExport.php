<?php

namespace App\Exports\Merchant;

use Carbon\Carbon;
use App\Models\User;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;

class MerchantsExport implements FromArray, WithHeadings, ShouldAutoSize, WithStyles, WithColumnFormatting
{
  public function styles(Worksheet $sheet)
  {
    return [
      1 => ['font' => ['bold' => true]],
    ];
  }

  public function columnFormats(): array
  {
    return [
      'P' => NumberFormat::FORMAT_TEXT,
    ];
  }

  public function headings(): array
  {
    return [
      'Merchant Name', 'SAP Code', 'TAN No', 'PAN No', 'GST No', 'Merchant Company Name', 'Merchant Address', 'Country', 'State', 'City', 'Merchant Email', 'Merchant Phone', 'Bank Name', 'Branch', 'Account Holder name', 'Bank Acc No', 'IFSC', 'MR1 Email ID', 'MR1 Phone', 'MR2 Email ID', 'MR2 Phone', 'MR3 Email ID', 'MR3 Phone', 'MR4 Email ID', 'MR4 Phone', 'is_kam'
    ];
  }

  public function array(): array
  {
    $merchants = User::get();

    $merchantsArray = [];

    foreach ($merchants as $merchant) {
      $merchantsArray[] = [
        $merchant->company_name,
        $merchant->sap_code,
        $merchant->tan_number,
        $merchant->pancard_number,
        $merchant->gst_number,
        $merchant->company_name,
        $merchant->address,
        $merchant->myCountry?->name,
        $merchant->myState?->name,
        $merchant->myCity?->name,
        $merchant->email,
        $merchant->phone,
        $merchant->activeBankAccount?->name,
        $merchant->activeBankAccount?->branch,
        $merchant->activeBankAccount?->acc_holder_name,
        $merchant->activeBankAccount?->account_number,
        $merchant->activeBankAccount?->ifsc,
        $merchant->staff?->first()?->email,
        $merchant->staff?->first()?->mobile,
        $merchant->staff?->skip(1)->first()?->email,
        $merchant->staff?->skip(1)->first()?->mobile,
        $merchant->staff?->skip(2)->first()?->email,
        $merchant->staff?->skip(2)->first()?->mobile,
        $merchant->staff?->skip(3)->first()?->email,
        $merchant->staff?->skip(3)->first()?->is_kam,
      ];
    }
    return $merchantsArray;
  }
}
