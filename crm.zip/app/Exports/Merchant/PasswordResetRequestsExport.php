<?php

namespace App\Exports\Merchant;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithHeadings;
use App\Models\Merchant\PasswordResetRequest;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;


class PasswordResetRequestsExport implements FromArray, WithHeadings, ShouldAutoSize, WithStyles
{
  public function styles(Worksheet $sheet)
  {
    return [
      1 => ['font' => ['bold' => true]],
    ];
  }

  public function headings(): array
  {
    return [
      'Merchant Company Name', 'Merchant TAN', 'Requested Email', 'Requested On'
    ];
  }

  public function array(): array
  {
    $requests = PasswordResetRequest::all()->where('is_completed', '=', 0);
    $allRequests = [];

    foreach ($requests as $key => $request) {
      if (isset($request->merchant)) {
        $allRequests[$key]['Merchant Company Name'] = $request->merchant->company_name;
        $allRequests[$key]['Merchant TAN'] = $request->merchant->tan_number;
        $allRequests[$key]['Merchant Email'] = $request->email;
        $allRequests[$key]['Requested On'] = $request->created_at->format('d M, Y');
      }
    }

    return $allRequests;
  }
}
