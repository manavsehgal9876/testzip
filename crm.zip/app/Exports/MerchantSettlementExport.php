<?php

namespace App\Exports;

use App\Models\User;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;

class MerchantSettlementExport implements FromArray, WithHeadings, ShouldAutoSize, WithStyles, WithColumnFormatting
{
  public function styles(Worksheet $sheet)
  {
    return [
      1 => ['font' => ['bold' => true]],
    ];
  }

  public function columnFormats(): array
  {
    return [
      'D' => NumberFormat::FORMAT_TEXT,
    ];
  }

  public function headings(): array
  {
    return ['Merchant Name', 'TAN Number', 'IFSC Code', 'Account No', 'QTR', 'UTR Number', 'Payment Date', 'Total'];
  }

  public function __construct(private string $tanNumber)
  {
  }

  public function array(): array
  {
    $merchant = User::where('tan_number', '=', $this->tanNumber)->first();
    // dd($merchant->completedClaims);
    $settlements = [];
    $lastKey = 0;
    foreach ($merchant->completedClaims as $key => $claim) {
      if ($key === 0) {
        $settlements[$key]['Merchant Name'] = $merchant->company_name;
        $settlements[$key]['TAN Number'] = $merchant->tan_number;
        $settlements[$key]['IFSC Code'] = $merchant->activeBankAccount?->ifsc;
        $settlements[$key]['Account No'] = "'" . $merchant->activeBankAccount?->account_number;
      } else {
        $settlements[$key]['Merchant Name'] = NULL;
        $settlements[$key]['TAN Number'] = NULL;
        $settlements[$key]['IFSC Code'] = NULL;
        $settlements[$key]['Account No'] = NULL;
      }
      $settlements[$key]['QTR'] = 'Q' . $claim->quarter . '-' . $claim->financial_year;
      $settlements[$key]['UTR Number'] = "'" . $claim->utr;
      $settlements[$key]['Payment Date'] = isset($claim->payment_date) ? $claim->payment_date->format('m/d/y') : NULL;
      $settlements[$key]['Total'] = $claim->tds_claim_amount;
      $lastKey = $key;
    }
    $lastKey = ++$lastKey;
    $settlements[$lastKey]['Merchant Name'] = 'Total';
    $settlements[$lastKey]['TAN Number'] = NULL;
    $settlements[$lastKey]['IFSC Code'] = NULL;
    $settlements[$lastKey]['Account No'] = NULL;
    $settlements[$lastKey]['QTR'] = NULL;
    $settlements[$lastKey]['UTR Number'] = NULL;
    $settlements[$lastKey]['Payment Date'] = NULL;
    $settlements[$lastKey]['Total'] = array_sum(array_column($settlements, 'Total'));

    return $settlements;
  }
}
