<?php

namespace App\Exports;

use App\Models\Admin\Form26AS;
use App\Models\Merchant\Claim;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class Form26AsReportExport implements FromArray, WithHeadings, ShouldAutoSize, WithStyles
{
  public function styles(Worksheet $sheet)
  {
    return [
      1 => ['font' => ['bold' => true]],
    ];
  }

  public function headings(): array
  {
    return ['Merchant Name', 'TAN Number', 'Financial Year', 'Total 26As TDS Amount', 'Total Claim Paid Amount', 'Balance', 'Merchant Category'];
  }

  public function __construct(private string $financialYear)
  {
  }

  public function array(): array
  {
    $form26AsData = Form26AS::where('financial_year', '=', $this->financialYear)
      ->distinct('deductor_tan')
      ->select('deductor_name', 'deductor_tan', 'financial_year', 'category')->get();

    $form26AsReportData = [];

    foreach ($form26AsData as $key => $form26As) {
      $totalClaimPaidAmount = Claim::where([['financial_year', '=', $this->financialYear], ['tan_number', '=', $form26As->deductor_tan], ['status', '=', 4]])->sum('tds_claim_amount');
      $total26AsTDSAmount = Form26AS::where([['financial_year', '=', $this->financialYear], ['deductor_tan', '=', $form26As->deductor_tan]])->sum('total_tax_deducted');
      $form26AsReportData[$key]['Merchant Name'] = $form26As->deductor_name;
      $form26AsReportData[$key]['TAN Number'] = $form26As->deductor_tan;
      $form26AsReportData[$key]['Financial Year'] = $form26As->financial_year;
      $form26AsReportData[$key]['Total 26As TDS Amount'] = $total26AsTDSAmount === 0 ? '0' : $total26AsTDSAmount;
      $form26AsReportData[$key]['Total Claim Paid Amount'] = $totalClaimPaidAmount === 0 ? '0' : $totalClaimPaidAmount;
      $balance = $form26AsReportData[$key]['Total 26As TDS Amount'] - $form26AsReportData[$key]['Total Claim Paid Amount'];
      $form26AsReportData[$key]['Balance'] = $balance === 0.00 ? '0' : $balance;
      $form26AsReportData[$key]['Merchant Category'] = $form26As->category;
    }
    return $form26AsReportData;
  }
}
