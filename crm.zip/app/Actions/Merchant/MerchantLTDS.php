<?php

namespace App\Actions\Merchant;

use App\Models\Merchant\LTDC;
use Illuminate\View\View;
use Lorisleiva\Actions\Concerns\AsAction;

class MerchantLTDS
{
  use AsAction;

  public function handle(): View
  {
    $ltdcs = LTDC::where('tan_number', '=', auth()->user()->tan_number)->get();
    return view('merchant.ltdc', compact('ltdcs'));
  }
}
