<?php

namespace App\Actions\Merchant\Claim;

use App\Traits\ApiResponser;
use App\Models\Merchant\Claim;
use App\Models\Merchant\LTDCCollection;
use Lorisleiva\Actions\Concerns\AsAction;
use App\Actions\Merchant\LTDCandForm26ASCalculations\CalculateLtdcAndForm26;
use Illuminate\Http\JsonResponse;

class CalculateLTDC
{
  use AsAction, ApiResponser;

  public function handle(string $certificateNumber, string $tanNumber, string $assessmentYear, string $financialYear, int $quarter): JsonResponse
  {
    try {
      $claim = Claim::where('certificate_no', '=', $certificateNumber)->first();

      if (Claim::where('certificate_no', '=', $certificateNumber)->exists() && $claim->status !== 5)
        throw new \Error('Claim of the same period has already been processed in the system.', 409);

      LTDCCollection::where([['tan_number', '=', $tanNumber], ['financial_year', '=', $financialYear]])->delete();

      CalculateLtdcAndForm26::run($tanNumber, $financialYear, explode('-', $financialYear)[0], $quarter);

      $ltdcInfo = GetLTDCInfo::run($tanNumber, $assessmentYear, $quarter);

      return $this->successResponse($ltdcInfo, 'LTDC Calculated Successfully');
    } catch (\Throwable $th) {
      return $this->errorResponse([], $th->getMessage());
    }
  }
}
