<?php

namespace App\Actions\Merchant\LTDCandForm26ASCalculations;

use DateTime;
use App\Models\Merchant\LTDC;
use App\Models\Admin\Form26AS;
use App\Models\Merchant\LTDCCollection;
use Lorisleiva\Actions\Concerns\AsAction;

class CalculateQuarterThree
{
  use AsAction;

  private array $quarterThreeMonths = [10, 11, 12];
  private string $tanNumber;
  private string $financialYear;
  private string $currentFinancialYear;
  private int $quarter;

  public function handle($tanNumber, $financialYear, $currentFinancialYear, $quarter, LTDCCollection $ltdcCollection, float $quarterTwoRemaningAmount, bool $runQuarterFour): bool
  {
    $this->tanNumber = $tanNumber;
    $this->financialYear = $financialYear;
    $this->currentFinancialYear = $currentFinancialYear;
    $this->quarter = $quarter;

    if ($quarterTwoRemaningAmount === 0.0)
      $quarterThreeRemaningAmount = $this->revised($ltdcCollection);

    if ($quarterTwoRemaningAmount > 0.0)
      $quarterThreeRemaningAmount = $this->unRevised($ltdcCollection, $quarterTwoRemaningAmount);

    if ($runQuarterFour) CalculateQuarterFour::run($tanNumber, $financialYear, $currentFinancialYear, $quarter, $ltdcCollection, ($quarterThreeRemaningAmount <= 0) ? 0.0 : $quarterThreeRemaningAmount);

    return true;
  }

  public function revised(LTDCCollection $ltdcCollection)
  {
    $ltdc = LTDC::where([['tan_number', '=', $this->tanNumber], ['financial_year', '=', $this->financialYear], ['revised_flag', '=', 1]])->first();
    if (isset($ltdc)) {
      $validFrom = DateTime::createFromFormat('d-M-y', $ltdc->valid_from)->format('Y-m-d');
      $validFrom = DateTime::createFromFormat('d-M-y', $ltdc->valid_from)->format('Y-m-d');
      $validFromYear = DateTime::createFromFormat('d-M-y', $ltdc->valid_from)->format('Y');

      if ($this->currentFinancialYear !== $validFromYear)
        return false;

      $validTill = DateTime::createFromFormat('d-M-y', $ltdc->valid_till)->format('Y-m-d');

      $quarterThreeForm26ASAmountPaidSum = Form26AS::where([
        ['transaction_date', '>=', $validFrom], ['transaction_date', '<=', $validFromYear . '12' . '31'], ['deductor_tan', '=', $this->tanNumber]
      ])
        ->orderBy('transaction_date', 'asc')
        ->sum('total_amount_paid');

      $amountToBeDeducted = $ltdc->income_to_receive;

      $quarterThreeRemaningAmount = $amountToBeDeducted - $quarterThreeForm26ASAmountPaidSum;

      $ltdcCollection->update([
        'quarter_three' => ($quarterThreeRemaningAmount <= 0) ? $amountToBeDeducted : $quarterThreeForm26ASAmountPaidSum,
        'quarter_three_remaining' => ($quarterThreeRemaningAmount <= 0) ? 0.0 : $quarterThreeRemaningAmount,
        'use_revise_quarter_four' => true,
      ]);
      return ($quarterThreeRemaningAmount <= 0) ? 0.0 : $quarterThreeRemaningAmount;
    }
  }

  public function unRevised(LTDCCollection $ltdcCollection, $quarterTwoRemaningAmount): float
  {
    $ltdc = LTDC::where([['tan_number', '=', $this->tanNumber], ['financial_year', '=', $this->financialYear], ['revised_flag', '=', 0]])->first();

    $validFrom = DateTime::createFromFormat('d-M-y', $ltdc->valid_from)->format('Y-m-d');
    $validFromYear = DateTime::createFromFormat('d-M-y', $ltdc->valid_from)->format('Y');
    $validTill = DateTime::createFromFormat('d-M-y', $ltdc->valid_till)->format('Y-m-d');

    $quarterThreeForm26ASAmountPaidSum = Form26AS::where([
      ['transaction_date', '>=', $this->currentFinancialYear . '10' . '01'], ['transaction_date', '<=', $this->currentFinancialYear . '12' . '31'], ['deductor_tan', '=', $this->tanNumber]
    ])
      ->orderBy('transaction_date', 'asc')
      ->sum('total_amount_paid');

    if ($quarterThreeForm26ASAmountPaidSum < $quarterTwoRemaningAmount) {
      $amountToBeDeducted = $quarterTwoRemaningAmount;

      $quarterThreeRemaningAmount = $amountToBeDeducted - $quarterThreeForm26ASAmountPaidSum;

      $ltdcCollection->update([
        'quarter_three' => ($quarterThreeRemaningAmount <= 0) ? $amountToBeDeducted : $quarterThreeForm26ASAmountPaidSum,
        'quarter_three_remaining' => ($quarterThreeRemaningAmount <= 0) ? 0.0 : $quarterThreeRemaningAmount,
      ]);
      return ($quarterThreeRemaningAmount <= 0) ? 0.0 : $quarterThreeRemaningAmount;
    } else {

      $ltdc = LTDC::where([['tan_number', '=', $this->tanNumber], ['financial_year', '=', $this->financialYear], ['revised_flag', '=', 1]])->first();
      $quarterThreeRevisedRemaningAmount = $quarterThreeRevisedAmount = 0;
      $flag = false;
      if (isset($ltdc)) {
        $validFrom = DateTime::createFromFormat('d-M-y', $ltdc->valid_from)->format('Y-m-d');
        $validTill = DateTime::createFromFormat('d-M-y', $ltdc->valid_till)->format('Y-m-d');
        $quarterThreeRevisedForm26ASAmountPaidSum = Form26AS::where([
          ['transaction_date', '>=', $validFrom], ['transaction_date', '<=', $this->currentFinancialYear . '12' . '31'], ['deductor_tan', '=', $this->tanNumber]
        ])
          ->orderBy('transaction_date', 'asc')
          ->sum('total_amount_paid');

        ($quarterThreeRevisedForm26ASAmountPaidSum !== 0) ? $flag = true : $flag = false;

        $revisedAmountToBeDeducted = ($quarterThreeRevisedForm26ASAmountPaidSum === 0) ? 0 : $ltdc->income_to_receive;
        $quarterThreeRevisedRemaningAmount = ($quarterThreeRevisedForm26ASAmountPaidSum === 0) ? 0 : $revisedAmountToBeDeducted - $quarterThreeRevisedForm26ASAmountPaidSum;

        $quarterThreeRevisedRemaningAmount = ($quarterThreeRevisedRemaningAmount <= 0) ? 0 : $quarterThreeRevisedRemaningAmount;
        $quarterThreeRevisedAmount = ($quarterThreeRevisedRemaningAmount <= 0) ? $revisedAmountToBeDeducted : $quarterThreeRevisedForm26ASAmountPaidSum;
      }

      $ltdc = LTDC::where([['tan_number', '=', $this->tanNumber], ['financial_year', '=', $this->financialYear], ['revised_flag', '=', 0]])->first();
      
      $validFromRevised = DateTime::createFromFormat('d-M-y', $ltdc->valid_from)->format('Y-m-d');
      $validFromRevisedMonth = DateTime::createFromFormat('d-M-y', $ltdc->valid_from)->format('m');
      $validFromRevisedYear = DateTime::createFromFormat('d-M-y', $ltdc->valid_from)->format('Y');
      $validFromRevisedDate = DateTime::createFromFormat('d-M-y', $ltdc->valid_from)->format('d');

      $validFrom = DateTime::createFromFormat('d-M-y', $ltdc->valid_from)->format('Y-m-d');
      $validTill = DateTime::createFromFormat('d-M-y', $ltdc->valid_till)->format('Y-m-d');

      if ($validFromRevisedYear > DateTime::createFromFormat('d-M-y', $ltdc->valid_from)->format('Y')) {
        $validFromRevisedMonth = 12;
        $validFromRevisedDate = 31;
      }

      $quarterThreeForm26ASAmountPaidSum = Form26AS::where([
        ['transaction_date', '>=', $this->currentFinancialYear . '10' . '01'], ['transaction_date', '<=', $this->currentFinancialYear . $validFromRevisedMonth . $validFromRevisedDate], ['deductor_tan', '=', $this->tanNumber]
      ])
        ->orderBy('transaction_date', 'asc')
        ->sum('total_amount_paid');

      $amountToBeDeducted = $quarterTwoRemaningAmount;

      $quarterThreeRemaningAmount = $amountToBeDeducted - $quarterThreeForm26ASAmountPaidSum;

      $quarterThreeRemaningAmount = ($quarterThreeRemaningAmount <= 0) ? 0.0 : $quarterThreeRemaningAmount;
      $quarterThreeAmount = ($quarterThreeRemaningAmount <= 0) ? $amountToBeDeducted : $quarterThreeForm26ASAmountPaidSum;

      $totalQuarterThreeAmount = $quarterThreeRevisedAmount + $quarterThreeAmount;
      $totalQuarterThreeRemaningAmount = $quarterThreeRemaningAmount + $quarterThreeRevisedRemaningAmount;

      $ltdcCollection->update([
        'quarter_three' => $totalQuarterThreeAmount,
        'quarter_three_remaining' => $totalQuarterThreeRemaningAmount,
        'use_revise_quarter_four' => $flag,
      ]);
      return $totalQuarterThreeRemaningAmount;
    }
  }
}



/* 
first condition : if remaning quarter two ltdc is 0
if any revised ltdc found then it will be applied on new valid from and till dates 
$revisedLtdc = 100000;
$quarterThreeForm26ASAmountPaidSum = 20000;
quarter three ltdc = $revisedLtdc - $quarterThreeForm26ASAmountPaidSum (<- this will be the amount of the new valid from and till dates sum);
$remaningQuarterThree = 80000;
*************************************************************************************************************************

second condition : if remaning quarter two ltdc is greater than 0 
  1. if quarter three ltdc is < quarter two remaning

      $quarterTwoRemaningAmount = 100000;
      $quarterThreeTotalLtdc = 50000;
      $remaningQuarterThree = $quarterTwoRemaningAmount - $quarterThreeTotalLtdc = 50000;
      if any revised ltdc found
      $revisedLtdc = 100000;
      then $remaningQuarterThree = $remaningQuarterThree + $revisedLtdc = 150000;
      if any revised ltdc not found
      then $remaningQuarterThree = $remaningQuarterThree = 50000;

  2. else if quarter three ltdc is > quarter two remaning
    check if any revised ltdc is present or not
    if present then get the revised from and till ltdc
*/




// quarter one sum = 7332526.00

// revised 26AS value = 3046708
// income to receive from revised = 20000000 

// quarter two remaining : 205373.00
// oct num 26AS sum: 5707454