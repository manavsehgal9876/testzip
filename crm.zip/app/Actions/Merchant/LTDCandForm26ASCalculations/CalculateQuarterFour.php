<?php

namespace App\Actions\Merchant\LTDCandForm26ASCalculations;

use DateTime;
use App\Models\Merchant\LTDC;
use App\Models\Admin\Form26AS;
use App\Models\Merchant\LTDCCollection;
use Lorisleiva\Actions\Concerns\AsAction;

class CalculateQuarterFour
{
  use AsAction;

  private array $quarterThreeMonths = [1, 2, 3];
  private string $tanNumber;
  private string $financialYear;
  private string $currentFinancialYear;
  private int $quarter;

  public function handle($tanNumber, $financialYear, $currentFinancialYear, $quarter, LTDCCollection $ltdcCollection, float $quarterThreeRemaningAmount)
  {
    // var_dump($quarterThreeRemaningAmount, 'dkhasjhjshfdjhjskfhkjewhk', $quarter, $ltdcCollection);
    // exit;
    // return false;
    $this->tanNumber = $tanNumber;
    $this->financialYear = $financialYear;
    $this->currentFinancialYear = $currentFinancialYear;
    $this->quarter = $quarter;

    if ($quarterThreeRemaningAmount === 0.0) {
      if ($ltdcCollection->use_revise_quarter_four === false)
        return $this->revised($ltdcCollection);

      return $ltdcCollection->update([
        'quarter_four' => 0.0,
        'quarter_four_remaining' => 0.0
      ]);
    }

    if ($quarterThreeRemaningAmount > 0.0) {
      if ($ltdcCollection->use_revise_quarter_four === false)
        return $this->unRevised($ltdcCollection, $quarterThreeRemaningAmount);

      return $this->unRevisedWithRevised($ltdcCollection, $quarterThreeRemaningAmount);
    }
  }

  public function revised(LTDCCollection $ltdcCollection)
  {
    $ltdc = LTDC::where([['tan_number', '=', $this->tanNumber], ['financial_year', '=', $this->financialYear], ['revised_flag', '=', 1]])->first();
    if (isset($ltdc)) {
      $validFrom = DateTime::createFromFormat('d-M-y', $ltdc->valid_from)->format('Y-m-d');
      $validFromYear = DateTime::createFromFormat('d-M-y', $ltdc->valid_from)->format('Y');

      $validTill = DateTime::createFromFormat('d-M-y', $ltdc->valid_till)->format('Y-m-d');
      $validTillYear = DateTime::createFromFormat('d-M-y', $ltdc->valid_till)->format('Y');

      $quarterFourForm26ASAmountPaidSum = Form26AS::where([
        ['transaction_date', '>=', $validFrom], ['transaction_date', '<=', $validTillYear . '03' . '31'], ['deductor_tan', '=', $this->tanNumber]
      ])
        ->orderBy('transaction_date', 'asc')
        ->sum('total_amount_paid');

      $amountToBeDeducted = $ltdc->income_to_receive;

      $quarterFourRemaningAmount = $amountToBeDeducted - $quarterFourForm26ASAmountPaidSum;

      $ltdcCollection->update([
        'quarter_four' => ($quarterFourRemaningAmount <= 0) ? $amountToBeDeducted : $quarterFourForm26ASAmountPaidSum,
        'quarter_four_remaining' => ($quarterFourRemaningAmount <= 0) ? 0 : $quarterFourRemaningAmount,
      ]);
    }
  }

  public function unRevised(LTDCCollection $ltdcCollection, $quarterThreeRemaningAmount)
  {
    $ltdc = LTDC::where([['tan_number', '=', $this->tanNumber], ['financial_year', '=', $this->financialYear], ['revised_flag', '=', 1]])->first();
    $validFrom = '';
    if (isset($ltdc)) $validFrom = DateTime::createFromFormat('d-M-y', $ltdc->valid_from)->format('Y-m-d');

    if (isset($ltdc) && $validFrom < $this->currentFinancialYear . '12' . '31') {
      $quarterFourForm26ASAmountPaidSum = Form26AS::where([
        ['transaction_date', '>=', $this->currentFinancialYear + 1 . '01' . '01'], ['transaction_date', '<=', $this->currentFinancialYear + 1 . '03' . '31'], ['deductor_tan', '=', $this->tanNumber]
      ])
        ->orderBy('transaction_date', 'asc')
        ->sum('total_amount_paid');

      $amountToBeDeducted = $ltdcCollection->quarter_three_remaining + $ltdc->income_to_receive;

      $quarterFourRemaningAmount = $amountToBeDeducted - $quarterFourForm26ASAmountPaidSum;

      return $ltdcCollection->update([
        'quarter_four' => ($quarterFourRemaningAmount <= 0) ? $amountToBeDeducted : $quarterFourForm26ASAmountPaidSum,
        'quarter_four_remaining' => ($quarterFourRemaningAmount <= 0) ? 0 : $quarterFourRemaningAmount,
      ]);
    } elseif (!isset($ltdc) && $validFrom < $this->currentFinancialYear . '12' . '31') {
      return $this->unRevisedWithRevised($ltdcCollection, $quarterThreeRemaningAmount);
    }

    if ($validFrom > $this->currentFinancialYear . '12' . '31' && isset($ltdc)) {

      $quarterFourRevisedRemaningAmount = $quarterFourRevisedAmount = 0;

      if (isset($ltdc)) {
        $validTill = DateTime::createFromFormat('d-M-y', $ltdc->valid_till)->format('Y-m-d');
        $quarterFourRevisedForm26ASAmountPaidSum = Form26AS::where([
          ['transaction_date', '>=', $validFrom], ['transaction_date', '<=', $this->currentFinancialYear + 1 . '03' . '31'], ['deductor_tan', '=', $this->tanNumber]
        ])
          ->orderBy('transaction_date', 'asc')
          ->sum('total_amount_paid');

        $revisedAmountToBeDeducted = ($quarterFourRevisedForm26ASAmountPaidSum === 0) ? 0 : $ltdc->income_to_receive;
        $quarterFourRevisedRemaningAmount = ($quarterFourRevisedForm26ASAmountPaidSum === 0) ? 0 : $revisedAmountToBeDeducted - $quarterFourRevisedForm26ASAmountPaidSum;

        $quarterFourRevisedRemaningAmount = ($quarterFourRevisedRemaningAmount <= 0) ? 0 : $quarterFourRevisedRemaningAmount;
        $quarterFourRevisedAmount = ($quarterFourRevisedRemaningAmount <= 0) ? $revisedAmountToBeDeducted : $quarterFourRevisedForm26ASAmountPaidSum;
      }

      $quarterFourForm26ASAmountPaidSum = Form26AS::where([
        ['transaction_date', '>=', $this->currentFinancialYear + 1 . '01' . '01'], ['transaction_date', '<', $validFrom], ['deductor_tan', '=', $this->tanNumber]
      ])
        ->orderBy('transaction_date', 'asc')
        ->sum('total_amount_paid');

      $amountToBeDeducted = $quarterThreeRemaningAmount;

      $quarterFourRemaningAmount = $amountToBeDeducted - $quarterFourForm26ASAmountPaidSum;

      $quarterFourRemaningAmount = ($quarterThreeRemaningAmount <= 0) ? 0.0 : $quarterFourRemaningAmount;
      $quarterFourAmount = ($quarterFourRemaningAmount <= 0) ? $amountToBeDeducted : $quarterFourForm26ASAmountPaidSum;

      $totalQuarterFourAmount = $quarterFourRevisedAmount + $quarterFourAmount;
      $totalQuarterFourRemaningAmount = $quarterFourRemaningAmount + $quarterFourRevisedRemaningAmount;

      return $ltdcCollection->update([
        'quarter_four' => $totalQuarterFourAmount,
        'quarter_four_remaining' => $totalQuarterFourRemaningAmount,
      ]);
    }

    return $ltdcCollection->update([
      'quarter_four' => 0.0,
      'quarter_four_remaining' => 0.0
    ]);
  }

  public function unRevisedWithRevised(LTDCCollection $ltdcCollection, $quarterThreeRemaningAmount)
  {
    $quarterFourForm26ASAmountPaidSum = Form26AS::where([
      ['transaction_date', '>=', $this->currentFinancialYear + 1 . '01' . '01'], ['transaction_date', '<=', $this->currentFinancialYear + 1 . '03' . '31'], ['deductor_tan', '=', $this->tanNumber]
    ])
      ->orderBy('transaction_date', 'asc')
      ->sum('total_amount_paid');

    $amountToBeDeducted = $ltdcCollection->quarter_three_remaining;

    $quarterFourRemaningAmount = $amountToBeDeducted - $quarterFourForm26ASAmountPaidSum;

    $ltdcCollection->update([
      'quarter_four' => ($quarterFourRemaningAmount <= 0) ? $amountToBeDeducted : $quarterFourForm26ASAmountPaidSum,
      'quarter_four_remaining' => ($quarterFourRemaningAmount <= 0) ? 0 : $quarterFourRemaningAmount,
    ]);
  }
}
