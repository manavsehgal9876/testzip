<?php

namespace App\Actions\Merchant\LTDCandForm26ASCalculations;

use DateTime;
use App\Models\Merchant\LTDC;
use App\Models\Admin\Form26AS;
use App\Models\Merchant\LTDCCollection;
use Lorisleiva\Actions\Concerns\AsAction;

class CalculateQuarterTwo
{
  use AsAction;

  private array $quarterTwoMonths = [7, 8, 9];

  public function handle($tanNumber, $financialYear, $currentFinancialYear, $quarter, LTDCCollection $ltdcCollection, float $quarterOneRemaningAmount, bool $runQuarterThree): bool
  {
    // calculating for the financial year of 2021-22
    $ltdc = LTDC::where([['tan_number', '=', $tanNumber], ['financial_year', '=', $financialYear], ['revised_flag', '=', 0]])->first();

    $validFrom = DateTime::createFromFormat('d-M-y', $ltdc->valid_from)->format('Y-m-d');
    $validFromYear = DateTime::createFromFormat('d-M-y', $ltdc->valid_from)->format('Y');
    $validTill = DateTime::createFromFormat('d-M-y', $ltdc->valid_till)->format('Y-m-d');

    $quarterTwoForm26ASAmountPaidSum = Form26AS::where([
      ['transaction_date', '>=', $validFromYear . '07' . '01'], ['transaction_date', '<=', $validFromYear . '09' . '30'], ['deductor_tan', '=', $tanNumber]
    ])
      ->orderBy('transaction_date', 'asc')
      ->sum('total_amount_paid');

    $amountToBeDeducted = $ltdcCollection->quarter_one_remaining;

    $quarterTwoRemaningAmount = $amountToBeDeducted - $quarterTwoForm26ASAmountPaidSum;

    $ltdcCollection->update([
      'quarter_two' => ($quarterTwoRemaningAmount <= 0) ? $amountToBeDeducted : $quarterTwoForm26ASAmountPaidSum,
      'quarter_two_remaining' => ($quarterTwoRemaningAmount <= 0) ? 0 : $quarterTwoRemaningAmount,
      // 'quarter_two_remaining' => 0,
    ]);
    
    if ($runQuarterThree) CalculateQuarterThree::run($tanNumber, $financialYear, $currentFinancialYear, $quarter, $ltdcCollection, ($quarterTwoRemaningAmount <= 0) ? 0 : $quarterTwoRemaningAmount, $quarter > 3 ? true : false);
    // CalculateQuarterThree::run($ltdcCollection, 0.00);

    return true;
  }
}
