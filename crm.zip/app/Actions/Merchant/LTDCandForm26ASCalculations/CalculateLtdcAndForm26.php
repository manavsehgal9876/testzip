<?php

namespace App\Actions\Merchant\LTDCandForm26ASCalculations;

use Lorisleiva\Actions\Concerns\AsAction;

class CalculateLtdcAndForm26
{
  use AsAction;

  private function handle(string $tanNumber, string $financialYear, string $currentFinancialYear, int $quarter)
  {
    if ($quarter === 1) {
      CalculateQuarterOne::run($tanNumber, $financialYear, $currentFinancialYear, $quarter, false);
    } else if ($quarter === 2) {
      CalculateQuarterOne::run($tanNumber, $financialYear, $currentFinancialYear, $quarter, true);
    } else if ($quarter === 3) {
      CalculateQuarterOne::run($tanNumber, $financialYear, $currentFinancialYear, $quarter, true);
    } else if ($quarter === 4) {
      CalculateQuarterOne::run($tanNumber, $financialYear, $currentFinancialYear, $quarter, true);
    }
  }
}
