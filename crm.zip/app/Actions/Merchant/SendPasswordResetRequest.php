<?php

namespace App\Actions\Merchant;

use App\Models\User;
use Illuminate\Http\Request;
use Lorisleiva\Actions\Concerns\AsAction;
use App\Models\Merchant\PasswordResetRequest;

class SendPasswordResetRequest
{
  use AsAction;

  public function asController(Request $request)
  {
    $request->validate([
      'tan_number' => 'required|max:10|exists:users,tan_number',
      'email' => 'required|max:255',
    ]);

    PasswordResetRequest::create([
      'email' => $request->email,
      'tan_number' => $request->tan_number,
    ]);

    return back()->with('success', 'Password reset request sent to the admin.');
  }
}
