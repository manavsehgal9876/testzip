<?php

namespace App\Actions\Staff\Merchant;

use App\Models\Merchant\PasswordResetRequest;
use Lorisleiva\Actions\Concerns\AsAction;

class PasswordResetRequests
{
  use AsAction;

  public function asController()
  {
    $requests = PasswordResetRequest::orderByDesc('id')->where('is_completed', '=', false)->paginate(100);
    return view('adminStaff.merchant.password-reset-requests', compact('requests'));
  }
}
