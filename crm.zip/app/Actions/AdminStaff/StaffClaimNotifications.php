<?php

namespace App\Actions\AdminStaff;

use App\Models\Merchant\ClaimHistory;
use Lorisleiva\Actions\Concerns\AsAction;

class StaffClaimNotifications
{
  use AsAction;

  public function handle()
  {
    $claimHistory = ClaimHistory::whereHas('claim', function ($query) {
      $query->where('staff_id', auth()->user()->id);
    })
      ->latest()
      ->paginate(100);

    return view('adminStaff.claim-notifications', compact('claimHistory'));
  }
}
