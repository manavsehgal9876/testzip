<?php

namespace App\Actions\AdminStaff;

use App\Models\User;
use Illuminate\Http\Request;
use App\Models\Merchant\BankDetail;
use Illuminate\Support\Facades\Mail;
use App\Mail\Notification\MerchantMail;
use Illuminate\Http\RedirectResponse;
use Lorisleiva\Actions\Concerns\AsAction;

class SendMailToMerchant
{
  use AsAction;

  public function asController(Request $request): RedirectResponse
  {
    // dd($request->all());
    $merchant = User::findOrFail($request->merchant_id);
    Mail::to($merchant->primaryStaff->email)->send(new MerchantMail([
      'title' => $request->title,
      'body' => $request->body,
    ]));

    if (isset($request->reject_bank_account))
      BankDetail::find($request->reject_bank_account)->update(['is_approved' => 2]);

    return back()->with('success', 'Mail has been sent to the merchant successfully.');
  }
}
