<?php

namespace App\Actions\Admin\Claim;

use Maatwebsite\Excel\Facades\Excel;
use App\Http\Requests\ExcelFileRequest;
use Lorisleiva\Actions\Concerns\AsAction;
use App\Imports\UTRImport as ImportsUTRImport;
use Illuminate\Validation\ValidationException;

class UTRImport
{
  use AsAction;

  public function handle(ExcelFileRequest $request)
  {
    try {
      Excel::import(new ImportsUTRImport, $request->excelSheet);
      return back()->with('success', 'UTR sheet imported successfully.');
    } catch (ValidationException  $th) {
      return back()->withErrors($th->errors());
    }
  }
}
