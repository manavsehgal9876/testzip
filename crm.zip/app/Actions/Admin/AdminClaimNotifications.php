<?php

namespace App\Actions\Admin;

use App\Models\Merchant\ClaimHistory;
use Lorisleiva\Actions\Concerns\AsAction;

class AdminClaimNotifications
{
  use AsAction;

  public function handle()
  {
    $claimHistory = ClaimHistory::latest()
      ->paginate(100);
    return view('admin.claim-notifications', compact('claimHistory'));
  }
}
