<?php

namespace App\Actions\Admin\Staff;

use App\Traits\ApiResponser;
use Illuminate\Http\JsonResponse;
use Lorisleiva\Actions\Concerns\AsAction;
use App\Models\Admin\Company\CompanyStaff;

class GetStaffList
{
  use AsAction, ApiResponser;

  public function handle(): JsonResponse
  {
    return $this->successResponse(CompanyStaff::where('status', '=', 1)->with(['claims'])->get()->append('full_name'));
  }
}
