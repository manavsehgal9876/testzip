<?php

namespace App\Actions\Admin\Reports;

use Maatwebsite\Excel\Facades\Excel;
use Lorisleiva\Actions\Concerns\AsAction;
use App\Exports\Claim\ApprovedClaimReportExport;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class ApprovedClaimReport
{
  use AsAction;

  public function handle(): BinaryFileResponse
  {
    return Excel::download(new ApprovedClaimReportExport(), 'approved-claim-report.xlsx');
  }
}
