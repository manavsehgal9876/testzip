<?php

namespace App\Actions\Admin\Reports;

use App\Models\User;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\MerchantSettlementExport;
use Lorisleiva\Actions\Concerns\AsAction;
use App\Mail\Notification\SettlementReport;
use Symfony\Component\HttpFoundation\RedirectResponse;

class SendMerchantSettlementReports
{
  use AsAction;

  public function handle(string $tanNumber): RedirectResponse
  {
    $random = Str::random(16);
    Excel::store(new MerchantSettlementExport($tanNumber), "merchant-settlement-report-{$random}-{$tanNumber}.xlsx");
    $merchant = User::where('tan_number', '=', $tanNumber)->firstOrFail();
    Mail::to($merchant->primaryStaff->email)->send(new SettlementReport([
      'fileName' => "merchant-settlement-report-{$random}-{$tanNumber}.xlsx"
    ]));
    return back()->with('success', 'Settlement report has been sent');
  }
}
