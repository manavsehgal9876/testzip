<?php

namespace App\Actions\Admin\Reports;

use Maatwebsite\Excel\Facades\Excel;
use App\Exports\Merchant\MerchantsExport;
use Lorisleiva\Actions\Concerns\AsAction;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class MerchantsReport
{
  use AsAction;

  public function handle(): BinaryFileResponse
  {
    return Excel::download(new MerchantsExport, 'merchants-report.xlsx');
  }
}
