<?php

namespace App\Actions\Admin\Reports;

use Maatwebsite\Excel\Facades\Excel;
use App\Exports\Merchant\RecentMonthMerchantBankUpdateExport;
use Lorisleiva\Actions\Concerns\AsAction;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class RecentMonthMerchantBankUpdateReport
{
  use AsAction;

  public function handle(): BinaryFileResponse
  {
    return Excel::download(new RecentMonthMerchantBankUpdateExport, 'recent-month-merchant-bank-update-report.xlsx');
  }
}
