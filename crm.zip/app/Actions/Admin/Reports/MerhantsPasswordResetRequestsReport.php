<?php

namespace App\Actions\Admin\Reports;

use Maatwebsite\Excel\Facades\Excel;
use Lorisleiva\Actions\Concerns\AsAction;
use App\Exports\Merchant\PasswordResetRequestsExport;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class MerhantsPasswordResetRequestsReport
{
  use AsAction;

  public function handle(): BinaryFileResponse
  {
    return Excel::download(new PasswordResetRequestsExport(), 'merchants-password-reset-requests-report.xlsx');
  }
}
