<?php

namespace App\Actions\Admin;

use App\Traits\FileUpload;
use App\Models\ImportSheet;
use App\Jobs\ProcessMerchants;
use App\Imports\MerchantsImport;
use Maatwebsite\Excel\Facades\Excel;
use Lorisleiva\Actions\Concerns\AsAction;

class UploadMerchantsExcelAndDispatchJob
{
  use AsAction, FileUpload;

  protected function handle($request)
  {
    // return Excel::import(new MerchantsImport(auth()->user()->id, auth()->user()->type), request()->file('excelSheet'));
    if ($request->hasfile('excelSheet'))
      $request->request->add(['sheet' => $this->handleSingleFileUpload($request->excelSheet, 'uploads/merchant/')]);

    $fileNameWithPath = public_path('uploads/merchant/' . $request->sheet);

    ImportSheet::create([
      'file' => $request->sheet,
      'type' => 'merchants_sheet',
      'user_id' => auth()->user()->id,
      'user_type' => auth()->user()->type,
    ]);

    dispatch(new ProcessMerchants(['file' => $fileNameWithPath, 'id' => auth()->user()->id, 'type' => auth()->user()->type]));
  }
}
