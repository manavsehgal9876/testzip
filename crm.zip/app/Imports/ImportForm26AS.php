<?php

namespace App\Imports;

use App\Models\Admin\Form26AS;
use App\Mail\ReportImportErrors;
use App\Mail\ReportImportCompleted;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Events\AfterImport;
use Maatwebsite\Excel\Validators\Failure;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\WithEvents;
use Illuminate\Contracts\Queue\ShouldQueue;
use Maatwebsite\Excel\Concerns\SkipsOnFailure;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Concerns\WithBatchInserts;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Maatwebsite\Excel\Concerns\RegistersEventListeners;

class ImportForm26AS implements
  ToModel,
  WithHeadingRow,
  WithValidation,
  WithChunkReading,
  ShouldQueue,
  SkipsOnFailure,
  WithEvents
{
  use Importable, RegistersEventListeners;

  private array $quarterOne = ["April", "May", "June"];
  private array $quarterTwo = ["July", "August", "September"];
  private array $quarterThree = ["October", "November", "December"];
  private array $quarterFour = ["January", "February", "March"];

  public static function afterImport(AfterImport $event)
  {
    Mail::to(config('myconfig.TDS_SUPER_EMAIL'))->send(new ReportImportCompleted(['message' => 'Excel Import sheet have been completed for Form26AS upload']));
  }

  /**
   * @param Failure[] $failures
   */
  public function onFailure(Failure ...$failures)
  {
    $errors = [];
    foreach ($failures as $key => $failure) {
      $errors[$key]['row'] = $failure->row();
      $errors[$key]['error'] = $failure->errors()[0];
    }
    if (count($errors) > 0)
      Mail::to(config('myconfig.TDS_SUPER_EMAIL'))->send(new ReportImportErrors(['errors' => $errors, 'errorSheet' => 'Upload new Form26AS']));
  }

  /**
   * @param array $row
   *
   * @return \Illuminate\Database\Eloquent\Model|null
   */
  public function model(array $row)
  {
    $quarter = '';
    $financialYear = '';

    if (in_array(Date::excelToDateTimeObject($row['transaction_date'])->format('F'), $this->quarterOne)) {
      $quarter = '1';
      $financialYear = Date::excelToDateTimeObject($row['transaction_date'])->format('Y') . '-' . Date::excelToDateTimeObject($row['transaction_date'])->format('y') + 1;
    } else if (in_array(Date::excelToDateTimeObject($row['transaction_date'])->format('F'), $this->quarterTwo)) {
      $quarter = '2';
      $financialYear = Date::excelToDateTimeObject($row['transaction_date'])->format('Y') . '-' . Date::excelToDateTimeObject($row['transaction_date'])->format('y') + 1;
    } else if (in_array(Date::excelToDateTimeObject($row['transaction_date'])->format('F'), $this->quarterThree)) {
      $quarter = '3';
      $financialYear = Date::excelToDateTimeObject($row['transaction_date'])->format('Y') . '-' . Date::excelToDateTimeObject($row['transaction_date'])->format('y') + 1;
    } else if (in_array(Date::excelToDateTimeObject($row['transaction_date'])->format('F'), $this->quarterFour)) {
      $quarter = '4';
      $financialYear = Date::excelToDateTimeObject($row['transaction_date'])->format('Y') - 1 . '-' . Date::excelToDateTimeObject($row['transaction_date'])->format('y');
    }

    $month = Date::excelToDateTimeObject($row['transaction_date'])->format('m');

    Form26AS::create([
      'deductor_name' => $row['name_of_deductor'],
      'deductor_tan' => $row['tan_of_deductor'],
      'section' => $row['section'],
      'transaction_date' => Date::excelToDateTimeObject($row['transaction_date'])->format('Y-m-d'),
      'month' => $month,
      'quarter' => $quarter,
      'financial_year' => $financialYear,
      'status_of_booking' => $row['status_of_booking'],
      'date_of_booking' => Date::excelToDateTimeObject($row['date_of_booking'])->format('Y-m-d'),
      'remarks' => $row['remarks'],
      'total_amount_paid' => $row['total_amount_paid'],
      'total_tax_deducted' => $row['total_tax_deducted'],
      'total_tds_deposited' => $row['total_tds_deposited'],
      'rate' => ($row['total_tds_deposited'] === 0 || $row['total_amount_paid'] === 0) ? 0 : ($row['total_tds_deposited'] / $row['total_amount_paid']) * 100,
      'category' => $row['category'],
    ]);
  }

  public function rules(): array
  {
    return [
      // 'name_of_deductor' => ['bail', 'required', 'string', 'max:255'],
      // 'tan_of_deductor' => ['bail', 'required', 'string', 'min:10', 'max:10'],
      // 'section' => ['bail', 'required', 'string', 'max:50'],
      // 'transaction_date' => ['bail', 'required'],
      // 'status_of_booking' => ['bail', 'nullable', 'string', 'max:50'],
      // 'date_of_booking' => ['bail', 'required'],
      // 'remarks' => ['bail', 'nullable', 'string', 'max:255'],
      // 'total_amount_paid' => ['bail', 'required', 'numeric'],
      // 'total_tax_deducted' => ['bail', 'required', 'numeric'],
      // 'total_tds_deposited' => ['bail', 'required', 'numeric'],
    ];
  }

  public function chunkSize(): int
  {
    return 2500;
  }
}
