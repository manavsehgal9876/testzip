<?php

namespace App\Imports;

use App\Models\Admin\Form26AS;
use App\Jobs\AfterForm26ASImport;
use App\Jobs\BeforeForm26ASImport;
use Illuminate\Support\Collection;
use App\Mail\ReportImportCompleted;
use Illuminate\Support\Facades\Bus;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Events\AfterImport;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\WithEvents;
use Illuminate\Contracts\Queue\ShouldQueue;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Concerns\WithBatchInserts;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Maatwebsite\Excel\Concerns\RegistersEventListeners;

class BeforeImportForm26AS implements ToModel, WithHeadingRow, WithValidation, ShouldQueue, WithChunkReading, WithEvents
{
  use Importable, RegistersEventListeners;

  private array $quarterOne = ["April", "May", "June"];
  private array $quarterTwo = ["July", "August", "September"];
  private array $quarterThree = ["October", "November", "December"];
  private array $quarterFour = ["January", "February", "March"];

  private static string $fileNameWithPath;

  public function __construct($fileNameWithPath)
  {
    self::$fileNameWithPath = $fileNameWithPath;
  }

  public static function afterImport(AfterImport $event)
  {
    Log::debug(self::$fileNameWithPath);
    Bus::chain([
      new AfterForm26ASImport(['file' => self::$fileNameWithPath]),
    ])->dispatch();
  }

  public function model(array $row)
  {
    $quarter = '';
    $financialYear = '';

    if (in_array(Date::excelToDateTimeObject($row['transaction_date'])->format('F'), $this->quarterOne)) {
      $quarter = '1';
      $financialYear = Date::excelToDateTimeObject($row['transaction_date'])->format('Y') . '-' . Date::excelToDateTimeObject($row['transaction_date'])->format('y') + 1;
    } else if (in_array(Date::excelToDateTimeObject($row['transaction_date'])->format('F'), $this->quarterTwo)) {
      $quarter = '2';
      $financialYear = Date::excelToDateTimeObject($row['transaction_date'])->format('Y') . '-' . Date::excelToDateTimeObject($row['transaction_date'])->format('y') + 1;
    } else if (in_array(Date::excelToDateTimeObject($row['transaction_date'])->format('F'), $this->quarterThree)) {
      $quarter = '3';
      $financialYear = Date::excelToDateTimeObject($row['transaction_date'])->format('Y') . '-' . Date::excelToDateTimeObject($row['transaction_date'])->format('y') + 1;
    } else if (in_array(Date::excelToDateTimeObject($row['transaction_date'])->format('F'), $this->quarterFour)) {
      $quarter = '4';
      $financialYear = Date::excelToDateTimeObject($row['transaction_date'])->format('Y') - 1 . '-' . Date::excelToDateTimeObject($row['transaction_date'])->format('y');
    }

    $month = Date::excelToDateTimeObject($row['transaction_date'])->format('m');

    Form26AS::where([['deductor_tan', '=', $row['tan_of_deductor']], ['quarter', '=', $quarter], ['financial_year', '=', $financialYear]])->delete();
  }

  public function rules(): array
  {
    return [
      // 'name_of_deductor' => ['bail', 'required', 'string', 'max:255'],
      // 'tan_of_deductor' => ['bail', 'required', 'string', 'min:10', 'max:10'],
      // 'section' => ['bail', 'required', 'string', 'max:50'],
      // 'transaction_date' => ['bail', 'required'],
      // 'status_of_booking' => ['bail', 'nullable', 'string', 'max:50'],
      // 'date_of_booking' => ['bail', 'required'],
      // 'remarks' => ['bail', 'nullable', 'string', 'max:255'],
      // 'total_amount_paid' => ['bail', 'required', 'numeric'],
      // 'total_tax_deducted' => ['bail', 'required', 'numeric'],
      // 'total_tds_deposited' => ['bail', 'required', 'numeric'],
    ];
  }

  public function chunkSize(): int
  {
    return 2500;
  }
}
