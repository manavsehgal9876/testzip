<?php

namespace App\Imports;

use App\Models\User;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Concerns\WithBatchInserts;
use Maatwebsite\Excel\Concerns\WithChunkReading;

// , ShouldQueue
class SapCodeUpdateImport implements ToModel, WithHeadingRow, WithValidation, WithBatchInserts, WithChunkReading
{
  /**
   * @param array $row
   *
   * @return \Illuminate\Database\Eloquent\Model|null
   */
  public function model(array $row)
  {
    User::where('tan_number', '=', $row['tan'])->update(['sap_code' => $row['sap_vendor_code']]);
  }

  public function rules(): array
  {
    return [
      'company_code' => ['required', 'max:50'],
      'merchant_name' => ['required', 'max:100'],
      'pan' => ['required', 'alpha_num', 'min:10', 'max:10'],
      'sap_vendor_code' => ['nullable', 'alpha_num', 'max:50'],
      'tan' => ['bail', 'required', 'string', 'alpha_num', 'max:10', 'exists:App\Models\User,tan_number'],
    ];
  }

  public function messages()
  {
    return [];
  }

  public function batchSize(): int
  {
    return 50;
  }

  public function chunkSize(): int
  {
    return 50;
  }
}
