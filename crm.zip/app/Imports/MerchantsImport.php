<?php

namespace App\Imports;

use App\Models\User;
use Illuminate\Support\Str;
use App\Models\Merchant\Staff;
use App\Mail\ReportImportErrors;
use App\Models\Extension\Country;
use App\Mail\ReportImportCompleted;
use App\Models\Merchant\BankDetail;
use Illuminate\Support\Facades\Mail;
use Maatwebsite\Excel\Concerns\ToModel;
use App\Mail\Merchant\Staff\NewStaffMail;
use Maatwebsite\Excel\Events\AfterImport;
use Maatwebsite\Excel\Validators\Failure;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\WithEvents;
use Illuminate\Contracts\Queue\ShouldQueue;
use Maatwebsite\Excel\Concerns\SkipsOnFailure;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Concerns\WithBatchInserts;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Maatwebsite\Excel\Concerns\RegistersEventListeners;

class MerchantsImport implements
  ToModel,
  WithHeadingRow,
  WithValidation,
  WithChunkReading,
  WithBatchInserts,
  ShouldQueue,
  SkipsOnFailure,
  WithEvents
{
  use Importable, RegistersEventListeners;

  public static function afterImport(AfterImport $event)
  {
    Mail::to(config('myconfig.TDS_SUPER_EMAIL'))->send(new ReportImportCompleted(['message' => 'Excel Import sheet have been completed for merchant uploads']));
  }

  /**
   * @param Failure[] $failures
   */
  public function onFailure(Failure ...$failures)
  {
    $errors = [];
    foreach ($failures as $key => $failure) {
      $errors[$key]['row'] = $failure->row();
      $errors[$key]['error'] = $failure->errors()[0];
    }
    if (count($errors) > 0)
      Mail::to(config('myconfig.TDS_SUPER_EMAIL'))->send(new ReportImportErrors(['errors' => $errors, 'errorSheet' => 'Create merchant']));
  }

  public function __construct(private $id, private $type)
  {
  }
  /**
   * @param array $row
   *
   * @return \Illuminate\Database\Eloquent\Model|null
   */
  public function model(array $row)
  {
    $country = (isset($row['country'])) ? Country::where('name', $row['country'])->first() : null;
    $state = (isset($country)) ? $country->states()->where('name', $row['state'])->first() : null;
    $city = (isset($state)) ? $state->cities()->where('name', $row['city'])->first() : null;
    // saving merchant
    $merchant = User::create([
      'added_by' => $this->id,
      'added_type' => $this->type,
      'name' => $row['merchant_name'],
      'email' => $row['merchant_email'],
      'phone' => $row['merchant_phone'],
      'sap_code' => $row['sap_code'],
      'company_name' => $row['merchant_company_name'],
      'tan_number' => $row['tan_no'],
      'pancard_number' => $row['pan_no'],
      'gst_number' => $row['gst_no'],
      'address' => $row['merchant_address'],
      'country' => isset($country) ? $country->id : null,
      'state' => isset($state) ? $state->id : null,
      'city' => isset($city) ? $city->id : null,
      'password' => 'password@9888',
      'biz_category' => $row['category'],
    ]);
    // saving merchant's bank details
    BankDetail::create([
      'merchant_id' => $merchant->id,
      'name' => $row['bank_name'],
      'branch' => $row['branch'],
      'ifsc' => $row['ifsc'],
      'account_number' => $row['bank_acc_no'],
      'acc_holder_name' => $row['account_holder_name'],
      'is_approved' => 1,
    ]);
    // saving merchant's staff details
    if (isset($row['mr1_email_id']) || isset($row['mr1_phone'])) {
      $staff = Staff::create([
        'merchant_id' => $merchant->id,
        'email' => $row['mr1_email_id'],
        'phone' => $row['mr1_phone'],
        'password' => 'password@9888',
        'is_primary' => true,
      ]);
      Mail::to(Str::lower($staff->email))->queue(new NewStaffMail([
        'merchant' => $staff->merchant,
        'staff' => $staff,
        'subject' => 'Merchant MR Registered',
      ]));
    }
    if (isset($row['mr2_email_id']) || isset($row['mr2_phone']))
      $staff = Staff::create([
        'merchant_id' => $merchant->id,
        'email' => $row['mr2_email_id'],
        'phone' => $row['mr2_phone'],
        'password' => 'password@9888',
      ]);
    if (isset($row['mr3_email_id']) || isset($row['mr3_phone']))
      $staff = Staff::create([
        'merchant_id' => $merchant->id,
        'email' => $row['mr3_email_id'],
        'phone' => $row['mr3_phone'],
        'password' => 'password@9888',
      ]);
    if (isset($row['mr4_email_id']) || isset($row['mr4_phone']))
      $staff = Staff::create([
        'merchant_id' => $merchant->id,
        'email' => $row['mr4_email_id'],
        'phone' => $row['mr4_phone'],
        'password' => 'password@9888',
        'is_kam' => $row['is_kam'] == 1 ? true : false,
      ]);
  }

  public function rules(): array
  {
    return [
      // merchant validation rules
      'merchant_name' => ['bail', 'required', 'string', 'max:200'],
      'merchant_email' => ['bail', 'nullable', 'string', 'email', 'max:150'],
      'merchant_phone' => ['bail', 'nullable', 'min:7', 'max:20'],
      'sap_code' => ['bail', 'nullable', 'regex:/^[a-zA-Z0-9]+$/', 'max:30', 'unique:App\Models\User,sap_code'],
      'tan_no' => ['bail', 'required', 'string', 'alpha_num', 'max:10', 'unique:App\Models\User,tan_number'],
      'gst_no' => ['bail', 'nullable', 'string', 'alpha_num', 'min:15', 'max:15', 'unique:App\Models\User,gst_number'],
      'pan_no' => ['bail', 'nullable', 'string', 'alpha_num', 'min:10', 'max:10', 'unique:App\Models\User,pancard_number'],
      'merchant_company_name' => ['bail', 'required', 'string', 'max:100', 'unique:App\Models\User,company_name'],
      'merchant_address' => ['bail', 'nullable', 'string', 'max:150'],
      'country' => ['bail', 'nullable', 'string', 'max:100'],
      'state' => ['bail', 'nullable', 'string', 'max:100'],
      'city' => ['bail', 'nullable', 'string', 'max:100'],
      // bank acc validation rules
      'bank_name' => ['bail', 'required', 'string', 'max:100'],
      'branch' => ['bail', 'nullable', 'string', 'max:100'],
      'ifsc' => ['bail', 'required', 'alpha_num', 'min:11'],
      'account_holder_name' => ['bail', 'required', 'string', 'max:100'],
      'bank_acc_no' => ['bail', 'required', 'digits_between:10,30', 'max:30'],
      // merchant staff validation rules
      'mr1_email_id' => ['bail', 'required', 'email', 'max:150'],
      'mr1_phone' => ['bail', 'nullable', 'digits:10'],
      'mr2_email_id' => ['bail', 'nullable', 'email', 'max:150'],
      'mr2_phone' => ['bail', 'nullable', 'digits:10'],
      'mr3_email_id' => ['bail', 'nullable', 'email', 'max:150'],
      'mr3_phone' => ['bail', 'nullable', 'digits:10'],
      'mr4_email_id' => ['bail', 'nullable', 'email', 'max:150'],
      'mr4_phone' => ['bail', 'nullable', 'digits:10'],
      'category' => ['bail', 'nullable', 'string', 'max:100'],
    ];
  }

  public function messages()
  {
    return [
      'merchant_name.regex' => 'Merchant name must be alphabets and numbers only',
      'sap_code.regex' => 'SAP code must be alphabets and numbers only',
      'merchant_company_name.regex' => 'Merchant company name must be alphabets and numbers only',
      'country.regex' => 'Country must be alphabets only',
      'state.regex' => 'State must be alphabets only',
      'city.regex' => 'City must be alphabets only',
      'bank_name.regex' => 'Bank name must be alphabets and numbers only',
      'account_holder_name.regex' => 'Account holder name must be alphabets and numbers only',
    ];
  }

  public function batchSize(): int
  {
    return 1000;
  }

  public function chunkSize(): int
  {
    return 1000;
  }
}
