<?php

use Illuminate\Support\Facades\Route;
use App\Actions\Merchant\Claim\CalculateLTDC;
use App\Http\Controllers\GlobalAjaxController;
use App\Http\Controllers\Merchant\FormSixteenController;


Route::middleware(['throttle:60,1'])->group(function () {
  Route::get('/getCountries', [GlobalAjaxController::class, 'getCountries'])->name('getCountries');

  Route::get('/getStates/{countryId}', [GlobalAjaxController::class, 'getStates'])->name('getStates');

  Route::get('/getCities/{stateId}', [GlobalAjaxController::class, 'getCities'])->name('getCities');

  Route::post('/set-form-sixteen-data', FormSixteenController::class)->name('set-form-sixteen-data');

  Route::get('/calculate-ltdc/{certificateNumber}/{tanNumber}/{assessmentYear}/{financialYear}/{quarter}', CalculateLTDC::class)->name('calculate-ltdc');
});
