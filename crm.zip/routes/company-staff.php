<?php

use App\Actions\Staff\Form26AS;
use App\Actions\Staff\MerchantLTDS;
use App\Actions\Admin\Form26ASImport;
use Illuminate\Support\Facades\Route;
use App\Actions\Admin\Claim\UTRImport;
use App\Actions\Staff\SummarisedForm26AS;
use App\Actions\Admin\Reports\LtdcReports;
use App\Models\Merchant\PasswordResetRequest;
use App\Actions\Admin\Reports\Form26AsReports;
use App\Actions\Admin\Reports\MerchantsReport;
use App\Actions\AdminStaff\SendMailToMerchant;
use App\Actions\Admin\Reports\ApprovedClaimReport;
use App\Actions\AdminStaff\StaffClaimNotifications;
use App\Http\Controllers\AdminStaff\EventController;
use App\Actions\Staff\Merchant\PasswordResetRequests;
use App\Http\Controllers\AdminStaff\TicketController;
use App\Actions\Admin\Merchant\MerchantSapCodeRequest;
use App\Actions\Admin\Reports\EmptySapMerchantsReport;
use App\Actions\Admin\Reports\MerchantSettlementReports;
use App\Http\Controllers\AdminStaff\Auth\AuthController;
use App\Actions\Admin\Reports\SendMerchantSettlementReports;
use App\Http\Controllers\AdminStaff\Merchant\ClaimController;
use App\Http\Controllers\AdminStaff\Merchant\StaffController;
use App\Http\Controllers\AdminStaff\Merchant\MerchantController;
use App\Actions\Admin\Reports\MerhantsPasswordResetRequestsReport;
use App\Actions\Admin\Reports\RecentMonthMerchantBankUpdateReport;
use App\Http\Controllers\AdminStaff\Merchant\BankDetailController;
use App\Http\Controllers\AdminStaff\Merchant\SapCodeUploaderController;
use App\Http\Controllers\AdminStaff\Merchant\Report\ApprovedClaimSapReportController;
use App\Http\Controllers\AdminStaff\Merchant\Report\ModifiedBankDetailReportController;
/*
|--------------------------------------------------------------------------
| Admin Company Staff Routes
|--------------------------------------------------------------------------
|
| Here is where you can register adminStaff routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "adminStaff" middleware group. Now create something great!
|
*/

Route::middleware(['guest:company_staff', 'throttle:60,1'])->prefix('staff')->name('adminStaff.')->group(function () {
  Route::view('/', 'adminStaff.auth.login')->name('home');
  Route::view('/login', 'adminStaff.auth.login')->name('login');
  Route::post('/login', [AuthController::class, 'login'])->name('login');
  // Route::view('/forgot-password', 'adminStaff.auth.forgot-password')->name('forgot-password');
  // Route::post('/forgot-password', [AuthController::class, 'forgotPassword'])->name('forgot-password');
  // Route::get('reset-password/{token}/{email}', [AuthController::class, 'resetPasswordView'])->name('password.reset');
  // Route::post('/set-new-password', [AuthController::class, 'setNewPassword'])->name('set-new-password');
});

Route::middleware(['web', 'auth:company_staff', 'throttle:60,1'])->prefix('staff')->name('adminStaff.')->group(function () {
  Route::get('/dashboard', [AuthController::class, 'dashboard'])->name('dashboard');
  Route::get('/logout', [AuthController::class, 'logout'])->name('logout');

  Route::view('/utr/create', 'adminStaff.merchant.claims.utr-create')->name('claim.utr.create');
  Route::post('/utr/store', UTRImport::class)->name('claim.utr.store');
  Route::get('/ltdc', MerchantLTDS::class)->name('ltdc');

  Route::get('/form-twenty-six', Form26AS::class)->name('form-twenty-six.index');
  Route::get('/summarised-form-twenty-six', SummarisedForm26AS::class)->name('summarised-form-twenty-six.index');
  Route::view('/form-twenty-six/create', 'adminStaff.form-26.create')->name('form-twenty-six.create');
  Route::post('/form-twenty-six/store', Form26ASImport::class)->name('form-twenty-six.store');

  Route::get('/merchants/password-reset-requests', PasswordResetRequests::class)->name('merchant.password-reset-requests');
  Route::get('/merchants/toggle-password-reset-requests/{id}/{status}', function ($id, $status) {
    PasswordResetRequest::findOrFail($id)->update(['is_completed' => $status]);
    return back()->with('success', 'Password reset request status has been changed');
  })->name('merchant.toggle-password-reset-requests');
  Route::get('/claim-notifications', StaffClaimNotifications::class)->name('claim-notifications');

  Route::get('/approved-claims-report', ApprovedClaimReport::class)->name('approved-claims-report');
  Route::get('/merchants-report', MerchantsReport::class)->name('merchants-report');
  Route::get('/empty-sap-merchants-report', EmptySapMerchantsReport::class)->name('empty-sap-merchants-report');
  Route::get('/recent-month-merchants-bank-update-report', RecentMonthMerchantBankUpdateReport::class)->name('recent-month-merchants-bank-update-report');
  Route::get('/merchants-password-reset-requests-report', MerhantsPasswordResetRequestsReport::class)->name('merchants-password-reset-requests-report');
  Route::get('/ltdc-report/{financialYear}', LtdcReports::class)->name('ltdc-report');
  Route::get('/form-26-as-report/{financialYear}', Form26AsReports::class)->name('form-26-as-report');
  Route::get('/merchant-settlement-report/{tanNumber}', MerchantSettlementReports::class)->name('merchant-settlement-report');
  Route::get('/send-merchant-settlement-report/{tanNumber}', SendMerchantSettlementReports::class)->name('send-merchant-settlement-report');
  Route::controller(ApprovedClaimSapReportController::class)->group(function () {
    Route::get('/approved-claims-sap-report', 'show')->name('approved-claims-sap-report');
    Route::post('/approved-claims-sap-report', 'download')->name('approved-claims-sap-report');
  });
  Route::controller(ModifiedBankDetailReportController::class)->group(function () {
    Route::get('/modified-bank-detail-report', 'show')->name('modified-bank-detail-report');
    Route::get('/approve-modified-bank-detail-report/{id}', 'setApproved')->name('approve-modified-bank-detail-report');
  });

  Route::prefix('merchant')->name('merchant.')->group(function () {

    Route::get('/bank-details/{id}/toggle', [BankDetailController::class, 'toggleStatus'])->name('bank-details.toggle');

    Route::get('/sap-code-request/{merchantId}/{for}', MerchantSapCodeRequest::class)->name('sap-code-request');
    Route::controller(SapCodeUploaderController::class)->group(function () {
      Route::get('/upload-sap-code', 'create')->name('upload-sap-code');
      Route::post('/upload-sap-code', 'import')->name('upload-sap-code');
    });
    Route::post('/send-mail-to-merchant', SendMailToMerchant::class)->name('send-mail-to-merchant');
    Route::resources([
      'bank-details' => BankDetailController::class,
      'staff' => StaffController::class,
    ]);
  });

  Route::get('/recalculate-claim/{id}', [ClaimController::class, 'recalculateClaim'])->name('recalculate-claim');

  Route::resources([
    'merchants' => MerchantController::class,
    'claim' => ClaimController::class,
    'event' => EventController::class,
    'tickets' => TicketController::class,
  ]);
});
