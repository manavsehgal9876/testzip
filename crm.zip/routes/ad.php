<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\GlobalAjaxController;
use App\Http\Controllers\Ad\AdController;
use App\Http\Controllers\Ad\AdFilterController;
use App\Http\Controllers\Ad\AdCategoryController;
use App\Http\Controllers\Ad\AdFilterValueController;

Route::get('get-ad-categories-and-filter', [GlobalAjaxController::class, 'getAdCategoriesAndFilter'])->name('get-ad-categories-and-filter');

Route::middleware(['web', 'auth'])->prefix('admin')->name('admin.')->group(function () {

  Route::get('ad-category/status/{id}/{status}', [AdCategoryController::class, 'toggleStatus'])->name('ad-category.status');
  Route::get('ad-category/{parent_id}', [AdCategoryController::class, 'index'])->name('ad-category.index');
  Route::get('ad-category/create/{parent_id}', [AdCategoryController::class, 'create'])->name('ad-category.create');
  Route::resource('ad-category', AdCategoryController::class)->except(['index', 'create']);

  Route::get('ad-filter/status/{id}/{status}', [AdFilterController::class, 'toggleStatus'])->name('ad-filter.status');
  Route::patch('ad-filter/sort', [AdFilterController::class, 'updateSorts'])->name('ad-filter.sort');

  Route::get('ad-filter-values/status/{id}/{status}', [AdFilterValueController::class, 'toggleStatus'])->name('ad-filter-values.status');
  Route::patch('ad-filter-values/sort', [AdFilterValueController::class, 'updateSorts'])->name('ad-filter-values.sort');

  Route::get('ad/status/{id}/{status}', [AdController::class, 'toggleStatus'])->name('ad.status');

  Route::resources([
    'ad' => AdController::class,
    'ad-filter' => AdFilterController::class,
    'ad-filter-values' => AdFilterValueController::class,
  ]);
});
