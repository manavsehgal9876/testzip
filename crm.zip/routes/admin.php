<?php

use App\Actions\Admin\Form26AS;
use App\Actions\Admin\MerchantLTDS;
use App\Actions\Admin\Form26ASImport;
use Illuminate\Support\Facades\Route;
use App\Actions\Admin\Claim\UTRImport;
use App\Actions\Admin\Staff\GetStaffList;
use App\Actions\Admin\Reports\LtdcReports;
use App\Models\Merchant\PasswordResetRequest;
use App\Actions\Admin\AdminClaimNotifications;
use App\Actions\Admin\Reports\Form26AsReports;
use App\Actions\Admin\Reports\MerchantsReport;
use App\Http\Controllers\Admin\EventController;
use App\Actions\Admin\Staff\AssignClaimsToStaff;
use App\Http\Controllers\Admin\TicketController;
use App\Actions\Admin\Reports\ApprovedClaimReport;
use App\Http\Controllers\Admin\Auth\AuthController;
use App\Http\Controllers\Admin\GlAccountController;
use App\Actions\Admin\Merchant\PasswordResetRequests;
use App\Actions\Admin\Merchant\MerchantSapCodeRequest;
use App\Actions\Admin\Reports\EmptySapMerchantsReport;
use App\Actions\Admin\Reports\MerchantSettlementReports;
use App\Http\Controllers\Admin\Merchant\ClaimController;
use App\Http\Controllers\Admin\Merchant\StaffController;
use App\Http\Controllers\Admin\Company\CompanyController;
use App\Http\Controllers\Admin\Merchant\MerchantController;
use App\Http\Controllers\Admin\Merchant\BankDetailController;
use App\Http\Controllers\Admin\Company\CompanyStaffController;
use App\Actions\Admin\Reports\MerhantsPasswordResetRequestsReport;
use App\Actions\Admin\Reports\RecentMonthMerchantBankUpdateReport;
use App\Http\Controllers\Admin\Merchant\Report\ApprovedClaimSapReportController;
/*
|--------------------------------------------------------------------------
| Admin Routes
|--------------------------------------------------------------------------
|
| Here is where you can register admin routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "admin" middleware group. Now create something great!
|
*/

Route::middleware(['guest:admin', 'throttle:60,1'])->prefix('admin')->name('admin.')->group(function () {
  Route::view('/', 'admin.auth.login')->name('home');
  Route::view('/login', 'admin.auth.login')->name('login');
  Route::post('/login', [AuthController::class, 'login'])->name('login');
  Route::view('/forgot-password', 'admin.auth.forgot-password')->name('forgot-password');
  Route::post('/forgot-password', [AuthController::class, 'forgotPassword'])->name('forgot-password');
  Route::get('reset-password/{token}/{email}', [AuthController::class, 'resetPasswordView'])->name('password.reset');
  Route::post('/set-new-password', [AuthController::class, 'setNewPassword'])->name('set-new-password');
});

Route::middleware(['web', 'auth:admin', 'throttle:60,1'])->prefix('admin')->name('admin.')->group(function () {
  Route::get('/dashboard', [AuthController::class, 'dashboard'])->name('dashboard');
  Route::get('/logout', [AuthController::class, 'logout'])->name('logout');

  Route::middleware('isSuperAdmin')->group(function () {
    Route::get('/company-staff/{id}/toggle', [CompanyStaffController::class, 'toggleStatus'])->name('company-staff.toggle');
    Route::get('/all-company-staff/{status?}', [CompanyStaffController::class, 'index'])->name('company-staff.index');
    Route::resource('company-staff', CompanyStaffController::class)->except(['index']);

    Route::resources([
      'companies' => CompanyController::class,
      'event' => EventController::class,
      'tickets' => TicketController::class,
    ]);
  });

  Route::view('/utr/create', 'admin.merchant.claims.utr-create')->name('claim.utr.create');
  Route::post('/utr/store', UTRImport::class)->name('claim.utr.store');

  Route::get('/ltdc', MerchantLTDS::class)->name('ltdc');

  Route::get('/form-twenty-six/store', Form26AS::class)->name('form-twenty-six.index');
  Route::view('/form-twenty-six/create', 'admin.form-26.create')->name('form-twenty-six.create');
  Route::post('/form-twenty-six/store', Form26ASImport::class)->name('form-twenty-six.store');

  Route::get('/merchants/password-reset-requests', PasswordResetRequests::class)->name('merchant.password-reset-requests');
  Route::get('/merchants/toggle-password-reset-requests/{id}/{status}', function ($id, $status) {
    PasswordResetRequest::findOrFail($id)->update(['is_completed' => $status]);
    return back()->with('success', 'Password reset request status has been changed');
  })->name('merchant.toggle-password-reset-requests');

  Route::get('/approved-claims-report', ApprovedClaimReport::class)->name('approved-claims-report');
  Route::get('/merchants-report', MerchantsReport::class)->name('merchants-report');
  Route::get('/empty-sap-merchants-report', EmptySapMerchantsReport::class)->name('empty-sap-merchants-report');
  Route::get('/recent-month-merchants-bank-update-report', RecentMonthMerchantBankUpdateReport::class)->name('recent-month-merchants-bank-update-report');
  Route::get('/merchants-password-reset-requests-report', MerhantsPasswordResetRequestsReport::class)->name('merchants-password-reset-requests-report');
  Route::get('/ltdc-report/{financialYear}', LtdcReports::class)->name('ltdc-report');
  Route::get('/form-26-as-report/{financialYear}', Form26AsReports::class)->name('form-26-as-report');
  Route::get('/merchant-settlement-report/{tanNumber}', MerchantSettlementReports::class)->name('merchant-settlement-report');
  Route::controller(ApprovedClaimSapReportController::class)->group(function () {
    Route::get('/approved-claims-sap-report', 'show')->name('approved-claims-sap-report');
    Route::post('/approved-claims-sap-report', 'download')->name('approved-claims-sap-report');
  });

  Route::get('/get-staff-list', GetStaffList::class)->name('get-staff-list');
  Route::post('/assign-claim-to-staff', AssignClaimsToStaff::class)->name('assign-claim-to-staff');

  Route::resources([
    'merchants' => MerchantController::class,
    'claim' => ClaimController::class,
    'gl-account' => GlAccountController::class,
  ]);

  Route::get('/claim-notifications', AdminClaimNotifications::class)->name('claim-notifications');

  Route::prefix('merchant')->name('merchant.')->group(function () {

    Route::get('/bank-details/{id}/toggle', [BankDetailController::class, 'toggleStatus'])->name('bank-details.toggle');

    Route::get('sap-code-request/{merchantId}/{for}', MerchantSapCodeRequest::class)->name('sap-code-request');

    Route::resources([
      'bank-details' => BankDetailController::class,
      'staff' => StaffController::class,
    ]);
  });
});
