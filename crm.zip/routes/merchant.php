<?php

use App\Actions\Events;
use Illuminate\Support\Facades\Route;
use App\Actions\Merchant\MerchantLTDS;
use App\Actions\Merchant\SendPasswordResetRequest;
use App\Http\Controllers\Merchant\ClaimController;
use App\Http\Controllers\Merchant\StaffController;
use App\Http\Controllers\Merchant\TicketController;
use App\Actions\Merchant\MerchantClaimNotifications;
use App\Http\Controllers\Merchant\ProfileController;
use App\Http\Controllers\Merchant\Auth\AuthController;
use App\Http\Controllers\Merchant\BankDetailController;
use App\Actions\Merchant\LTDCandForm26ASCalculations\CalculateQuarterOne;

/*
|--------------------------------------------------------------------------
| Merchant Routes
|--------------------------------------------------------------------------
|
| Here is where you can register merchant routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware(['web', 'guest', 'throttle:60,1'])->group(function () {
  Route::get('patch', [AuthController::class, 'patch']);
  Route::view('/', 'merchant.auth.login')->name('home');
  Route::view('/register', 'merchant.auth.register')->name('register');
  Route::post('/register', [AuthController::class, 'register'])->name('register');
  Route::view('/login', 'merchant.auth.login')->name('login');
  Route::post('/login', [AuthController::class, 'login'])->name('login');
  Route::view('/forgot-password', 'merchant.auth.forgot-password')->name('forgot-password');
  Route::post('/forgot-password', [AuthController::class, 'forgotPassword'])->name('forgot-password')->middleware('CheckPasswordFrequency');
  Route::get('/reset-password/{token}/{staffEmail}/{merchantTan}', [AuthController::class, 'resetPasswordView'])->name('password.reset');
  Route::post('/set-new-password', [AuthController::class, 'setNewPassword'])->name('set-new-password')->middleware('CheckPasswordDuplicacy');

  Route::view('/password-reset-request', 'merchant.auth.password-reset-request')->name('password-reset-request');
  Route::post('/password-reset-request', SendPasswordResetRequest::class)->name('password-reset-request');
});

Route::middleware(['web', 'auth', 'throttle:60,1'])->prefix('merchant')->name('merchant.')->group(function () {
  Route::get('/dashboard', [AuthController::class, 'dashboard'])->name('dashboard');
  Route::get('/profile', [ProfileController::class, 'profile'])->name('profile');
  Route::patch('/profile/{id}', [ProfileController::class, 'update'])->name('profile.update');
  Route::get('/bank-details/{id}/toggle', [BankDetailController::class, 'toggleStatus'])->name('bank-details.toggle');
  Route::get('/ltdc', MerchantLTDS::class)->name('ltdc');
  Route::get('/events', Events::class)->name('events');

  Route::get('/claim/manual-create', [ClaimController::class, 'createManually'])->name('claim.manual-create');
  Route::post('/claim/manual-store', [ClaimController::class, 'store'])->name('claim.manual-store');

  Route::resources([
    'bank-details' => BankDetailController::class,
    'staff' => StaffController::class,
    'claim' => ClaimController::class,
    'tickets' => TicketController::class,
  ]);

  Route::get('/calculate-quarter-one', CalculateQuarterOne::class)->name('calculate-quarter-one');

  Route::get('/claim-notifications', MerchantClaimNotifications::class)->name('claim-notifications');

  Route::get('/logout', [AuthController::class, 'logout'])->name('logout');
});
