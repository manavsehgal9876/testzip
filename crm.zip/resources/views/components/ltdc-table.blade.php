<div class="table-responsive">
  <table class="table align-middle table-striped table-nowrap mb-0 data-table" id="customerTable">
    <thead>
      <tr>
        <th scope="col" class=" text-center">Merchant Name</th>
        <th scope="col" class=" text-center">Tan Number</th>
        <th scope="col" class=" text-center">Valid From</th>
        <th scope="col" class=" text-center">Valid Till</th>
        <th scope="col" class=" text-center">Section</th>
        <th scope="col" class=" text-center">Nature of Payment</th>
        <th scope="col" class=" text-center">Income to Receive</th>
        <th scope="col" class=" text-center">Rate of Deduction</th>
        <th scope="col" class=" text-center">Category</th>
        <th scope="col" class=" text-center">Financial Year</th>
        <th scope="col" class=" text-center">Remaning Limit</th>
    </thead>
    <tbody>
      @foreach ($ltdcs as $ltdc)
        <tr>

          <td class="name text-center">
            <p class="text-muted mb-0">{{ $ltdc->merchant_name }}</p>
          </td>

          <td class="name text-center">
            <p class="text-muted mb-0">{{ $ltdc->tan_number }}</p>
          </td>

          <td class="name text-center">
            <p class="text-muted mb-0">{{ $ltdc->valid_from }}</p>
          </td>

          <td class="name text-center">
            <p class="text-muted mb-0">{{ $ltdc->valid_till }}</p>
          </td>

          <td class="name text-center">
            <p class="text-muted mb-0">{{ $ltdc->section }} </p>
          </td>

          <td class="name text-center">
            <p class="text-muted mb-0">{{ $ltdc->nature_of_payment }} </p>
          </td>

          <td class="name text-center">
            <p class="text-muted mb-0">₹ {{ number_format($ltdc->income_to_receive, 2) }} </p>
          </td>

          <td class="name text-center">
            <p class="text-muted mb-0">{{ $ltdc->rate_of_deduction }}% </p>
          </td>

          <td class="name text-center">
            <p class="text-muted mb-0">{{ $ltdc->category }} </p>
          </td>

          <td class="name text-center">
            <p class="text-muted mb-0">{{ $ltdc->financial_year }} </p>
          </td>

          <td class="name text-center">
            <p class="text-muted mb-0">₹ {{ number_format($ltdc->remaning_limit, 2) }} </p>
          </td>

        </tr>
      @endforeach
    </tbody>
  </table>
</div>
