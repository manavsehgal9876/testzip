<div class="table-responsive">
  <table class="table align-middle table-striped table-nowrap mb-0" id="customerTable">
    <thead>
      <tr>
        <th scope="col" class="">Name of Deductor</th>
        <th scope="col" class="">TAN of Deductor</th>
        <th scope="col" class="">Category</th>
        <th scope="col" class="">Financial Year</th>
        <th scope="col" class="">Quarter</th>
        <th scope="col" class="">Sum of Total Amount Paid / Credited(Rs.)</th>
        <th scope="col" class="">Sum of Total TDS Deposited(Rs.)</th>
    </thead>
    <tbody>
      @foreach ($form26as as $form26)
        <tr>

          <td class="name text-center">
            <p class="text-muted mb-0">{{ $form26->deductor_name }} </p>
          </td>

          <td class="name text-center">
            <p class="text-muted mb-0">{{ $form26->deductor_tan }} </p>
          </td>

          <td class="name text-center">
            <p class="text-muted mb-0">{{ $form26->category }} </p>
          </td>

          <td class="name text-center">
            <p class="text-muted mb-0">{{ $form26->financial_year }} </p>
          </td>

          <td class="name text-center">
            <p class="text-muted mb-0">{{ $form26->quarter }} </p>
          </td>

          <td class="name text-center">
            <p class="text-muted mb-0">{{ $form26->sumOfTotalAmountPaid }} </p>
          </td>

          <td class="name text-center">
            <p class="text-muted mb-0">{{ $form26->sumOfTotalTdsDesposited }} </p>
          </td>

        </tr>
      @endforeach
    </tbody>
  </table>
  <div class="row mt-3">
    {{ $form26as->links() }}
  </div>
</div>
