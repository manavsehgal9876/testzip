<div class="col-xxl-3 col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12 mb-5">
  <div class="blog__card mb-50">
    <div class="blog__thumb w-img p-relative">
      <a class="blog__thumb--image" href="{{ $url }}">
        <img @isset($image) src="{{ $path }}/{{ $image }}" @endisset
          alt="{{ $name }}" />
      </a>
      <em class="b_date">{{ $createdAt->format('d, M') }}</em>
    </div>
    <div class="blog__card--content">
      <div class="blog__card--content-area mb-25">
        <span class="blog__card--date">{{ $categoryName }}</span>
        <h3 class="blog__card--title">
          <a href="{{ $url }}">{{ $name }}</a>
        </h3>
      </div>
      <div class="blog__card--icon">
        <div class="blog__card--icon-1">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
            class="feather feather-user">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
            <circle cx="12" cy="7" r="4"></circle>
          </svg>
          <span>{{ $createdBy }}</span>
        </div>
      </div>
    </div>
  </div>
</div>
