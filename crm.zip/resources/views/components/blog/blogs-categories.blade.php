<ul class="recent-category">
  <li> <a href="{{ $url }}">{{ $categoryName }} <em>({{ $blogsCount }})</em></a></li>
</ul>
