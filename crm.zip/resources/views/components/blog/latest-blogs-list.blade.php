<li>
  <a href="{{ route('blog-detail', $slug) }}"><span class="post-images">
      <img
       @isset($image) src="{{ $path }}/{{ $image }}" @endisset
        alt="{{ $name }}">
    </span></a>
  <div class="titles">
    <h4><a href="{{ route('blog-detail', $slug) }}">{{ $name }}</a></h4>
    <span><i data-feather="book"></i> {{ $categoryName }}</span>
  </div>
</li>
