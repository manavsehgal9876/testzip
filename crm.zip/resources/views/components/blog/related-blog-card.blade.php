<div class="single-studies col-md-4 grid-item">
  <div class="inner-course">
    <div class="case-img">
      <a href="{{ route('blog-detail', $slug) }}" class="cate-w">{{ $createdAt->format('d, M') }}</a>
      <img
       @isset($image) src="{{ $path }}/{{ $image }}" @endisset
        alt="{{ $name }}">
    </div>
    <div class="case-content">
      <em class="cate-camp">{{ $categoryName }}</em>
      <h4 class="case-title"> <a href="{{ route('blog-detail', $slug) }}">{{ $name }}</a></h4>
      <div class="react__user"> {{ $createdBy }}
      </div>
    </div>
  </div>
</div>
