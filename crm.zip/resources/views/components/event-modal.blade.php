<div class="modal fade" id="showModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" style="max-width: 802px;">
    <div class="modal-content border-0">
      <div class="modal-header bg-soft-info p-3">
        <h5 class="modal-title" id="exampleModalLabel"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" id="close-modal"></button>
      </div>
      <form action="" class="checkout-tab event-form" method="post" enctype="multipart/form-data">
        @csrf
        @method('PATCH')
        <div class="modal-body p-0">
          <div class="step-arrow-nav">
            <ul class="nav nav-pills nav-justified custom-nav" role="tablist">
              <li class="nav-item" role="presentation">
                <button class="nav-link p-3 active" id="pills-bill-info-tab" data-bs-toggle="pill"
                  data-bs-target="#pills-bill-info" type="button" role="tab" aria-controls="pills-bill-info"
                  aria-selected="true">Event Info</button>
              </li>
            </ul>
          </div>
        </div>
        <!--end modal-body-->
        <div class="modal-body">
          <div class="tab-content">
            <div class="tab-pane fade show active" id="pills-bill-info" role="tabpanel"
              aria-labelledby="pills-bill-info-tab">
              <div class="row g-3">
                <div class="col-lg-12">
                  <div>
                    <label for="eventName" class="form-label">Event Name</label>
                    <input type="text" class="form-control" id="eventName" placeholder="Enter Event Name"
                      minlength="0" maxlength="150" name="name" value="{{ old('name') }}" required>
                  </div>
                </div>

                <div class="col-lg-12">
                  <div>
                    <label for="eventDesc" class="form-label">Event Description</label>
                    <textarea type="text" class="form-control description" id="eventDesc" placeholder="Enter Event Description" maxlength="500"
                      name="description">{{ old('description') }}</textarea>
                  </div>
                </div>

                <div class="col-lg-12">
                  <div>
                    <label for="eventDesc" class="form-label">Event Date/Time</label>
                    <input type="datetime-local" class="form-control" id="eventDesc"
                      placeholder="Enter Event Description" min="{{ date('Y-m-d\TH:i') }}" name="date_time"
                      value="{{ old('date_time') }}">
                  </div>
                </div>
                <!--end col-->

                <div class="col-lg-12">
                  <div class="d-flex align-items-start gap-3 mt-3">
                    <button type="submit" class="btn btn-primary btn-label right ms-auto nexttab"
                      data-nexttab="pills-bill-address-tab"><i
                        class="ri-arrow-right-line label-icon align-middle fs-16 ms-2"></i>
                      Submit</button>
                  </div>
                </div>
                <!--end col-->
              </div>
              <!--end row-->
            </div>
            <!-- end tab pane -->

          </div>
          <!-- end tab content -->
        </div>
        <!--end modal-body-->
      </form>
    </div>
  </div>
</div>
