<li class="list-group-item ps-0">
  <div class="d-flex align-items-start">
    <div class="flex-grow-1">
      <label class="form-check-label mb-0 ps-2" for="task_one">The Claim
        ({{ $history->claim->claim_id }})
        is
        {{ $history->claimStatus }}</label>
    </div>
    <div class="flex-shrink-0 ms-2">
      <p class="text-muted fs-12 mb-0">
        <a href="{{ $viewLink }}" class="link-success">View More <i class="ri-arrow-right-line align-middle"></i></a>
      </p>
    </div>
  </div>
</li>
