 <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-dialog-centered modal-lg add_new_claim_form">
     <div class="modal-content">
       <div class="modal-header p-3" style="background: #f2fac3;">
         <h5 class="modal-title text-uppercase" id="exampleModalLabel">Add New Claims Details.
         </h5>
         <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
       </div>
       <form action="{{ route('merchant.claim.store') }}" method="post" class="checkout-tab claim-form validity-form"
         enctype="multipart/form-data">
         @csrf
         <input type="hidden" name="ltdc_file" class="file-name" value="" />
         <input type="hidden" name="status" class="status" value="1" />
         <input type="hidden" name="bank_id" value="{{ auth()->user()->activeBankAccount->id }}" />
         <!--end modal-body-->
         <div class="modal-body">
           <div class="tab-content">
             <div class="tab-pane fade show active" id="pills-bill-info" role="tabpanel"
               aria-labelledby="pills-bill-info-tab">
               <div class="row g-3">
                 <!--end col-->
                 <div class="col-lg-4">
                   <div>
                     <label for="phoneNumber" class="form-label">Claim on TAN</label>
                     <input type="text" class="form-control tan-number" id="phoneNumber"
                       placeholder="{{ auth()->user()->tan_number }}" readonly>
                   </div>
                 </div>
                 <div class="col-lg-4">
                   <div>
                     <label for="phoneNumber" class="form-label">Merchant Company Name</label>
                     <input type="text" class="form-control" id="phoneNumber"
                       placeholder="{{ auth()->user()->company_name }}" readonly>
                   </div>
                 </div>
                 <div class="col-lg-4 d-none">
                   <div>
                     <label for="phoneNumber" class="form-label">Added By(Merchant Staff)</label>
                     <input type="text" class="form-control" id="phoneNumber"
                       placeholder="{{ auth()->user()->name }}" readonly>
                   </div>
                 </div>
                 <div class="col-lg-4">
                   <div>
                     <label for="accountnumberInput" class="form-label">Pan Number</label>
                     <input type="text" class="form-control" id="accountnumberInput"
                       placeholder="{{ auth()->user()->pancard_number }}" readonly>
                   </div>
                 </div>
                 <div class="col-lg-12" style="border-top:1px solid #eee"></div>
                 <!--end col-->
                 <div class="col-lg-5">
                   <div>
                     <label for="serviceTax" class="form-label">Upload: Form 16A(Only PDF)</label>
                     <input type="file" class="form-control tds-form" id="serviceTax" placeholder=""
                       name="form16_file" accept=".pdf" required>
                   </div>
                 </div>
                 <div class="col-lg-12" style="border-top:1px solid #eee"></div>
                 <!--end col-->
                 <div class="col-lg-3">
                   <div>
                     <label for="serviceTax" class="form-label"> Asst.Year</label>
                     <input type="text" name="asst_year" value="{{ old('asst_year') }}" readonly
                       class="form-control asst-year" required placeholder="Asst.Year" />
                   </div>
                 </div>
                 <!--end col-->
                 <div class="col-lg-3">
                   <div>
                     <label for="serviceTax" class="form-label"> Period From/To</label>
                     <input type="text" name="period_from_to" value="{{ old('period_from_to') }}" readonly
                       class="form-control period-from-to" required placeholder="Period From/To" />
                   </div>
                 </div>
                 <div class="col-lg-3">
                   <div>
                     <label for="serviceTax" class="form-label"> Quarter</label>
                     <input type="text" name="quarter" value="{{ old('quarter') }}" readonly
                       class="quarter form-control" required placeholder="Quarter" />

                   </div>
                 </div>
                 <!--end col-->
                 <div class="col-lg-3">
                   <div>
                     <label for="serviceTax" class="form-label"> Financial Year</label>
                     <input type="text" name="financial_year" value="{{ old('financial_year') }}" readonly
                       class="form-control financial-year" required placeholder="Financial Year" />

                   </div>
                 </div>
                 <!--end col-->

                 <!--end col-->
                 <div class="col-lg-3">
                   <div>
                     <label for="serviceTax" class="form-label"> Total Amount Paid/Credited</label>
                     <input type="number" min="0" step="0.01" class="form-control amount-credited"
                       id="serviceTax" placeholder="Enter" name="amount_credited"
                       value="{{ old('amount_credited') }}" required readonly
                       placeholder="Total Amount Paid/Credited" />

                   </div>
                 </div>

                 <div class="col-lg-3">
                   <div>
                     <label for="serviceTax" class="form-label">TDS Claim Amount</label>
                     <input type="number" min="0" step="0.01" class="form-control tds-claim-amount"
                       id="serviceTax" name="tds_claim_amount" value="{{ old('tds_claim_amount') }}" required
                       readonly placeholder="TDS Claim Amount" />

                   </div>
                 </div>
                 <!--end col-->
                 <div class="col-lg-3">
                   <div>
                     <label for="serviceTax" class="form-label">Rate of TDS in %</label>
                     <input type="number" min="0" step="0.01" class="form-control" id="serviceTax"
                       name="rate_of_tds" value="{{ old('rate_of_tds') }}" readonly required
                       placeholder="Rate of TDS in %" />

                   </div>
                 </div>
                 <!--end col-->
                 <div class="col-lg-3">
                   <div>
                     <label for="serviceTax" class="form-label">Nature of payment(TDS Sec)</label>
                     <input type="text" maxlength="50" class="form-control nature-of-payment" id="serviceTax"
                       placeholder="Nature of payment(TDS Sec)" name="nature_of_tds"
                       value="{{ old('nature_of_tds') }}" required readonly>
                   </div>
                 </div>
                 <!--end col-->
                 <div class="col-lg-3">
                   <div>
                     <label for="serviceTax" class="form-label">Certificate No.</label>
                     <input type="text" class="form-control certificate-no" id="serviceTax" name="certificate_no"
                       maxlength="100" value="{{ old('certificate_no') }}" required readonly
                       placeholder="Certificate No." />

                   </div>
                 </div>
                 <!--end col-->
                 <div class="col-lg-3">
                   <div>
                     <label for="serviceTax" class="form-label">Last updated on</label>
                     <input type="date" class="form-control last-updated-on" id="serviceTax"
                       name="last_updated_on" readonly
                       value="{{ old('last_updated_on') != null ? old('last_updated_on') : '' }}" required
                       placeholder="Last updated on" />

                   </div>
                 </div>



                 <!--end col-->
                 <div class="col-lg-12" style="border:1px solid #eee;background: #fafafa;padding: 20px;">

                   <div class="row">
                     <div class="col-lg-12">
                       <div class="mt-2">
                         <label for="banknameInput" class="form-label font-normal">
                           <a href="javascript:;" target="_blank" class="ltdc-file-path">
                             <i class=" bx bxs-file-pdf"></i>
                             View Merchant Lower TAX Deduction Certificate(
                             LTDC) : (Click to View).
                           </a>
                         </label>
                         <label for="banknameInput" class="form-label font-normal d-none revised-ltdc">
                           <a href="javascript:;" target="_blank" class="ltdc-file-path-revised">
                             <i class=" bx bxs-file-pdf"></i>
                             View Revised Merchant Lower TAX Deduction Certificate(
                             LTDC) : (Click to View).
                           </a>
                         </label>
                       </div>
                     </div>
                     <!--end col-->
                     <div class="col-lg-3">
                       <div class="mt-3">
                         <label for="branchInput" class="form-label font-normal">LTDC available</label>
                         <input type="text" class="form-control ltdc" id="ltdc" name="ltdc"
                           maxlength="100" value="{{ old('ltdc') }}" required readonly
                           placeholder="Certificate No." />
                       </div>
                     </div>
                     <!--end col-->
                     <div class="col-lg-3">
                       <div class="mt-3">
                         <label for="ifscInput" class="form-label font-normal">LTDC Total limit</label>
                         <input type="number" class="form-control ltdc-total-limit" min="0" step="0.01"
                           id="ifscInput" placeholder="Enter" name="ltdc_total_limit"
                           value="{{ old('ltdc_total_limit') }}" readonly>
                       </div>
                     </div>
                     <!--end col-->
                     <div class="col-lg-3">
                       <div class="mt-3">
                         <label for="accountnameInput" class="form-label font-normal">LTDC Rate</label>
                         <input type="number" class="form-control ltdc-rate" id="accountnameInput"
                           placeholder="Enter" min="0" step="0.01" name="ltdc_rate"
                           value="{{ old('ltdc_rate') }}" readonly>
                       </div>
                     </div>
                     <!--end col-->
                     <div class="col-lg-3">
                       <div class="mt-3">
                         <label for="accountnumberInput" class="form-label font-normal">
                           TDC limit available
                         </label>
                         <input type="number" class="form-control tds-limit-available" id="accountnumberInput"
                           placeholder="Enter" min="0" step="0.01" name="tdc_limit"
                           value="{{ old('tdc_limit') }}" readonly>
                       </div>
                     </div>
                   </div>
                 </div>

                 <!--end col-->
                 <div class="col-lg-12">
                   <div class="d-flex align-items-start gap-3 mt-3">
                     <button type="submit" class="btn btn-primary btn-label  nexttab save-btn"
                       data-nexttab="pills-bill-address-tab" onclick="document.querySelector('.status').value='0'">
                       <i class="ri-arrow-left-line label-icon align-middle fs-16 ms-2"></i>
                       Save as Draft Claim
                     </button>
                     <button type="submit" class="btn btn-primary btn-label right ms-auto nexttab save-btn"
                       data-nexttab="pills-bill-address-tab">
                       <i class="ri-arrow-right-line label-icon align-middle fs-16 ms-2"></i>
                       Submit Claim
                     </button>
                   </div>
                 </div>
                 <!--end col-->
               </div>
               <!--end row-->
             </div>
             <!-- end tab pane -->


           </div>
           <!-- end tab content -->
         </div>
         <!--end modal-body-->
       </form>
     </div>
   </div>
 </div>
 <script type="module" src="{{ asset('assets/merchantAssets/claim.js') }}"></script>
