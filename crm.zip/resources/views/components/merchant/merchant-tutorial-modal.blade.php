<div class="modal fade" id="tutorialModal" tabindex="-1" aria-labelledby="tutorialModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="tutorialModalLabel">How it Works?</h1>
        <button type="button" class="btn" data-bs-dismiss="modal" aria-label="Close">
          <i class="ri-close-circle-line ri-xl"></i>
        </button>
      </div>
      <div class="modal-body">
        <div class="row justify-content-center align-items-center">
          <lottie-player src="https://assets2.lottiefiles.com/private_files/lf30_qam8tww4.json" mode="bounce"
            background="transparent" speed="1" style="width: auto; height: auto;" loop autoplay></lottie-player>
        </div>
        <div class="row mx-0 mt-5">
          <a href="{{ asset('assets/PayUMerchantPanel-SOP.pdf') }}" target="_blank"
            class="align-items-center btn btn-outline-success btn-rounded d-flex w-auto">
            Click here too see how it works <i class="mx-1 ri-send-plane-2-line ri-lg"></i>
          </a>
          <a href="javascript:;" data-bs-dismiss="modal"
            class="align-items-center mt-2 mt-md-0 ms-0 ms-md-auto btn btn-outline-danger btn-rounded d-flex w-auto hide-tutorial-forever">
            Okay I got it. Hide it forever <i class="mx-1 ri-thumb-up-line ri-lg"></i>
          </a>
        </div>
      </div>
    </div>
  </div>
</div>
