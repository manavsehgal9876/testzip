<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header p-3">
        <h5 class="modal-title text-uppercase" id="exampleModalLabel">Update Merchant Staff.
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="" class="checkout-tab staff-form" method="post"
        enctype="multipart/form-data">
        @csrf
        <input type="hidden" name="merchant_id" value="{{ $merchantId }}" />
        <div class="modal-body p-0">
          <div class="step-arrow-nav">
            <ul class="nav nav-pills nav-justified custom-nav" role="tablist">

              <li class="nav-item" role="presentation">
                <button class="nav-link p-3 active" id="pills-finish-tab" data-bs-toggle="pill"
                  data-bs-target="#pills-finish" type="button" role="tab" aria-controls="pills-finish"
                  aria-selected="false">Representatve</button>
              </li>
            </ul>
          </div>
        </div>
        <!--end modal-body-->
        <div class="modal-body">
          <div class="tab-content">
            <div class="tab-pane fade  show active" id="pills-finish" role="tabpanel"
              aria-labelledby="pills-finish-tab">
              <div class="row g-3">

                <div class="col-lg-6">
                  <label for="firstName" class="form-label mb-3">Photo upload</label>
                  <div class="dropzone d-flex align-items-center documents_upload_tb">
                    <div class="fallback">
                      <input type="file" name="photo"
                        accept="image/jpeg,image/png,image/jpg,image/gif,image/webp" />
                    </div>
                    <div class="dz-message needsclick text-center">
                      <div class="mb-3">
                        <i class="display-4 text-muted ri-upload-cloud-2-fill"></i>
                      </div>

                      <h4>Photo upload</h4>
                    </div>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="row">
                    <!--end col-->
                    <div class="col-lg-12">
                      <div>
                        <label for="firstName" class="form-label">Full Name</label>
                        <input type="text" class="form-control mb-3" id="firstName" placeholder="Enter"
                          name="name" maxlength="100" value="{{ old('name') }}" required>
                      </div>
                    </div>
                    <!--end col-->
                    <div class="col-lg-12">
                      <div>
                        <label for="phoneNumber" class="form-label">Email ID</label>
                        <input type="email" class="form-control mb-3" id="phoneNumber" placeholder="Enter"
                          name="email" maxlength="100" value="{{ old('email') }}">
                      </div>
                    </div>

                    <!--end col-->
                    <div class="col-lg-12">
                      <div>
                        <label for="emailID" class="form-label"> Mobile No </label>
                        <input type="tel" class="form-control mb-3" id="emailID" placeholder="Enter"
                          name="mobile" min="0" value="{{ old('mobile') }}"
                          title="Please use a 10 digit telephone number with no dashes or dots" pattern="[0-9]{10}">
                      </div>
                    </div>
                    <!--end col-->
                    {{-- <div class="col-lg-6">
                      <div>
                        <label for="confirmPassword" class="form-label">Department</label>
                        <select class="form-select mb-3 departmentt" aria-label="Default select example" name="department">
                          <option @selected(old('department') === 'sales') value="sales">Sales</option>
                          <option @selected(old('department') === 'marketing') value="marketing">Marketing</option>
                          <option @selected(old('department') === 'development') value="development">Development</option>
                        </select>
                      </div>
                    </div> --}}
                    <!--end col-->
                    {{-- <div class="col-lg-6">
                      <div>
                        <label for="vatNo" class="form-label">Designations</label>
                        <select class="form-select mb-3 designation" aria-label="Default select example" name="designation">
                          <option @selected(old('designation') === 'executive') value="executive">Executive </option>
                          <option @selected(old('designation') === 'manager') value="manager">Manager</option>
                          <option @selected(old('designation') === 'vp') value="vp">VP</option>
                        </select>
                      </div>
                    </div> --}}
                    <div class="col-lg-6">
                      <div>
                        <label for="vatNo" class="form-label">Status</label>
                        <select class="form-select mb-3 status" aria-label="Default select example" name="status">
                          <option @selected(old('status') === '1') value="1">Enable</option>
                          <option @selected(old('status') === '0') value="0">Disable</option>
                        </select>
                      </div>
                    </div>

                    <div class="col-lg-6">
                      <div>
                        <label for="vatNo" class="form-label">Working</label>
                        <select class="form-select mb-3 working" aria-label="Default select example" name="working">
                          <option @selected(old('working') === '1') value="1">Yes</option>
                          <option @selected(old('working') === '0') value="0">No</option>
                        </select>
                      </div>
                    </div>

                    <div class="col-lg-12">
                      <div>
                        <label for="vatNo" class="form-label">Primary Staff</label>
                        <select class="form-select mb-3 primary" aria-label="Default select example"
                          name="is_primary">
                          <option @selected(old('is_primary') === '1') value="1">Yes</option>
                          <option @selected(old('is_primary') === '0') value="0">No</option>
                        </select>
                      </div>
                    </div>

                  </div>

                </div>

                <!--end col-->
                <div class="col-lg-12">
                  <div class="d-flex align-items-start gap-3 mt-3">
                    <button type="submit" class="btn btn-primary btn-label right ms-auto nexttab"
                      data-nexttab="pills-bill-address-tab"><i
                        class="ri-arrow-right-line label-icon align-middle fs-16 ms-2"></i>
                      Save</button>
                  </div>
                </div>
                <!--end col-->
              </div>
            </div>
            <!-- end tab pane -->
          </div>
          <!-- end tab content -->
        </div>
        <!--end modal-body-->
      </form>
    </div>
  </div>
</div>
