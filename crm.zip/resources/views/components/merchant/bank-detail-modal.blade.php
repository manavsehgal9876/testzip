<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header p-3">
        <h5 class="modal-title text-uppercase" id="exampleModalLabel"> Update New Account.</h5>

        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="" method="post" class="checkout-tab bank-form validity-form" enctype="multipart/form-data">
        @csrf
        <input type="hidden" name="merchant_id" value="{{ $merchantId }}" />
        <div class="modal-body p-0">
          <div class="step-arrow-nav">
            <ul class="nav nav-pills nav-justified custom-nav" role="tablist">
              <li class="nav-item" role="presentation">
                <button class="nav-link p-3 active" id="pills-bill-address-tab" data-bs-toggle="pill"
                  data-bs-target="#pills-bill-address" type="button" role="tab" aria-controls="pills-bill-address"
                  aria-selected="false">Bank Details <br>
                </button>
              </li>

            </ul>
          </div>
        </div>
        <!--end modal-body-->
        <div class="modal-body">
          <div class="tab-content">


            <div class="tab-pane fade show active" id="pills-bill-address" role="tabpanel"
              aria-labelledby="pills-bill-address-tab">
              <div class="row">
                <div class="col-lg-4">
                  <div class="mb-3">
                    <label for="banknameInput" class="form-label">Bank
                      Name *</label>
                    <input type="text" class="form-control" id="banknameInput" placeholder="Enter your bank name"
                      name="name" maxlength="100" value="{{ old('name') }}" required>
                  </div>
                </div>
                <!--end col-->
                <div class="col-lg-4">
                  <div class="mb-3">
                    <label for="branchInput" class="form-label">Branch *</label>
                    <input type="text" class="form-control" id="branchInput" placeholder="Branch" name="branch"
                      maxlength="100" value="{{ old('branch') }}" required>
                  </div>
                </div>
                <!--end col-->
                <div class="col-lg-4">
                  <div class="mb-3">
                    <label for="ifscInput" class="form-label">IFSC *</label>
                    <input type="text" class="form-control" id="ifscInput" placeholder="IFSC" name="ifsc"
                      maxlength="11" title="Please use 11 chracters alpha numeric" pattern="[0-9A-Za-z]{11}"
                      value="{{ old('ifsc') }}" required>
                  </div>
                </div>
                <!--end col-->
                <div class="col-lg-4">
                  <div class="mb-3">
                    <label for="accountnameInput" class="form-label">Account
                      Holder Name *</label>
                    <input type="text" class="form-control" id="accountnameInput"
                      placeholder="Enter account holder name" name="acc_holder_name" maxlength="100"
                      value="{{ old('acc_holder_name') }}" required>
                  </div>
                </div>
                <!--end col-->
                <div class="col-lg-4">
                  <div class="mb-3">
                    <label for="accountnumberInput" class="form-label">Account
                      Number *</label>
                    <input type="text" class="form-control" id="accountnumberInput"
                      placeholder="Enter account number" name="account_number" maxlength="50"
                      value="{{ old('account_number') }}"
                      title="Please keep the account number length upto 50 characters long" required>
                  </div>
                </div>
                <!--end col-->
                <div class="col-lg-4">
                  <div class="mb-3">
                    <label for="ifscInput" class="form-label">Cancel Cheque *</label>
                    <input type="file" class="form-control" accept=".jpg, .png, .jpeg, .docx, .doc, .pdf"
                      name="cheque" required>
                  </div>
                </div>
                {{-- <div class="row">
                  <div class="col-lg-3">
                    <div>
                      <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="chk_child" value="option1">
                        Validate Data
                      </div>

                    </div>
                  </div>
                  <div class="col-lg-3 " style="margin-top: 11px;"><span style="color:green;"><i
                        class="ri-check-fill fs-16" style="color:green;font-weight: bold;"></i> Information
                      is Valid</span></div>
                </div> --}}

                <!--end col-->
                <div class="col-lg-12">
                  <div class="hstack align-items-start gap-3 mt-4">

                    <button type="submit" class="btn btn-primary btn-label right ms-auto nexttab save-btn"><i
                        class="ri-arrow-right-line label-icon align-middle fs-16 ms-2 "></i>Save</button>
                  </div>
                </div>
                <!--end col-->
              </div>
            </div>
            <!-- end tab pane -->

          </div>
          <!-- end tab content -->
        </div>
        <!--end modal-body-->
      </form>
    </div>
  </div>
</div>
