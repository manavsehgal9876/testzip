   <!-- start page title -->
   <div class="row">
     <div class="col-12">
       <div class="page-title-box d-sm-flex align-items-center justify-content-between"
         style="padding: 10px 1.5rem;
              background-color: var(--vz-card-bg) !important;
              -webkit-box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
              box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
              border-bottom: 1px solid none;
              border-top: 1px solid none;
              margin: -23px -1.5rem 1.5rem -1.5rem;">
         <h4 class="mb-sm-0" style="width: 100%;text-align: center;font-weight: normal;color: #2d4187 !important;">CLAIM
           DETAIL :
           {{ $claim->claim_id }}</h4>
       </div>
     </div>
   </div>
   <!-- end page title -->
   <div class="row justify-content-center">
     <div class="col-lg-7">
       <form action="{{ $route }}" class="checkout-tab claim-form" method="post" enctype="multipart/form-data">
         @csrf
         @method('PATCH')
         <fieldset @if ($claim->status === 4 && auth()->user()->type != 'admin') disabled @endif>
           <div class="card">
             <div class="card-body">
               <div class="text-left">

                 <div class="row justify-content-center">
                   <div @class([
                       'col-lg-12 text-end',
                       'd-none' =>
                           !in_array($claim->status, [0, 1, 2, 3]) ||
                           auth()->guard('company_staff')->check() === false,
                   ])>
                     <a href="{{ route('adminStaff.recalculate-claim', $claim->id) }}" disabled
                       class="btn btn-outline-danger btn-sm">
                       Recalculate
                     </a>
                   </div>
                   <div class="col-lg-12 text-center">

                     <div class="@if (auth()->user()->type === 'merchant' && $claim->status === 5) @else d-none @endif">
                       <label for="serviceTax" class="form-label">Upload: Form 16A(Only PDF)</label>
                       <input type="file" class="form-control tds-form" id="serviceTax" placeholder=""
                         name="form16_file" accept=".pdf" @if (auth()->user()->type === 'merchant' && $claim->status === 5) required @endif>
                     </div>

                     <p @class([
                         'fs-5 text-danger text-center mb-2 text-decoration-underline',
                         'd-none' => $claim->is_manually_added === 0,
                     ])>
                       Notice :- This claim has been added manually!
                     </p>
                     <h4 class="mt-4 fw-semibold">CLAIM DETAIL</h4>
                     @if ($claim->form16 && Storage::disk('appFiles')->exists("claim/{$claim->form16}"))
                       <a href="{{ asset('crm/public/uploads/claim') . '/' . $claim->form16 }}" target="_blank">Form
                         16
                         <i class="ri-download-2-line fs-17 lh-1 align-middle"></i>
                       </a>
                     @else
                       N/A
                     @endif
                   </div>
                 </div>

                 <div class="row justify-content-center mb-2">
                   <!--end modal-body-->
                   <div class="modal-body">
                     <div class="tab-content">
                       <div class="tab-pane fade show active" id="pills-bill-info" role="tabpanel"
                         aria-labelledby="pills-bill-info-tab">
                         <div class="row g-3">
                           <!--end col-->
                           <div class="col-lg-4">
                             <div>
                               <label for="phoneNumber" class="form-label">Claim on TAN</label>
                               <input type="text" class="form-control tan-number" id="phoneNumber"
                                 placeholder="{{ $claim->merchant->tan_number }}" readonly>
                             </div>
                           </div>
                           <div class="col-lg-4">
                             <div>
                               <label for="phoneNumber" class="form-label">Merchant Company Name</label>
                               <input type="text" class="form-control" id="phoneNumber"
                                 placeholder="{{ $claim->merchant->company_name }}" readonly>
                             </div>
                           </div>
                           <div class="col-lg-4 d-none">
                             <div>
                               <label for="phoneNumber" class="form-label">Added By(Merchant Staff)</label>
                               <input type="text" class="form-control" id="phoneNumber"
                                 placeholder="{{ $claim->merchant->name }}" readonly>
                             </div>
                           </div>
                           <div class="col-lg-4">
                             <div>
                               <label for="accountnumberInput" class="form-label">Pan Number</label>
                               <input type="text" class="form-control" id="accountnumberInput"
                                 placeholder="{{ $claim->merchant->pancard_number }}" readonly>
                             </div>
                           </div>
                           <div class="col-lg-12" style="border-top:1px solid #eee"></div>
                           <!--end col-->
                           <div class="col-lg-3">
                             <div>
                               <label for="serviceTax" class="form-label"> Asst.Year</label>
                               <input type="text" name="asst_year" value="{{ $claim->asst_year }}" readonly
                                 class="form-control asst-year" required placeholder="Asst.Year" />
                             </div>
                           </div>

                           <div class="col-lg-3">
                             <div>
                               <label for="serviceTax" class="form-label"> Period From/To</label>
                               <input type="text" name="period_from_to" value="{{ $claim->period_from_to }}" readonly
                                 class="form-control period-from-to" required placeholder="Period From/To" />
                             </div>
                           </div>
                           <div class="col-lg-3">
                             <div>
                               <label for="serviceTax" class="form-label"> Quarter</label>
                               <input type="text" name="quarter" value="{{ $claim->quarter }}" readonly
                                 class="quarter form-control" required placeholder="Quarter" />

                             </div>
                           </div>
                           <!--end col-->
                           <div class="col-lg-3">
                             <div>
                               <label for="serviceTax" class="form-label"> Financial Year</label>
                               <input type="text" name="financial_year" value="{{ $claim->financial_year }}"
                                 readonly class="form-control financial-year" required placeholder="Financial Year" />

                             </div>
                           </div>
                           <!--end col-->

                           <!--end col-->
                           <div class="col-lg-3">
                             <div>
                               <label for="serviceTax" class="form-label"> Total Amount Paid/Credited</label>
                               <input type="number" min="0" step="0.01"
                                 class="form-control amount-credited" id="serviceTax" placeholder="Enter"
                                 name="amount_credited" value="{{ $claim->amount_credited }}" required
                                 {{-- @if (auth()->user()->type === 'merchant') readonly @endif --}} readonly placeholder="Total Amount Paid/Credited" />

                             </div>
                           </div>
                           <div class="col-lg-3">
                             <div>
                               <label for="serviceTax" class="form-label">TDS Claim Amount</label>
                               <input type="number" min="0" step="0.01"
                                 class="form-control tds-claim-amount" id="serviceTax" name="tds_claim_amount"
                                 value="{{ $claim->tds_claim_amount }}" required
                                 @if (!Auth::guard('company_staff')->check()) readonly @endif placeholder="TDS Claim Amount" />

                             </div>
                           </div>
                           <!--end col-->
                           <div class="col-lg-3">
                             <div>
                               <label for="serviceTax" class="form-label">Rate of TDS in %</label>
                               <input type="number" min="0" step="0.01" class="form-control"
                                 id="serviceTax" name="rate_of_tds" value="{{ $claim->rate_of_tds }}" readonly
                                 required placeholder="Rate of TDS in %" />

                             </div>
                           </div>
                           <!--end col-->
                           <div class="col-lg-3">
                             <div>
                               <label for="serviceTax" class="form-label">Nature of payment(TDS Sec)</label>
                               <input type="text" maxlength="50" class="form-control nature-of-payment"
                                 id="serviceTax" placeholder="Nature of payment(TDS Sec)" name="nature_of_tds"
                                 value="{{ $claim->nature_of_tds }}" required readonly>
                             </div>
                           </div>
                           <!--end col-->
                           <div class="col-lg-3">
                             <div>
                               <label for="serviceTax" class="form-label">Certificate No.</label>
                               <input type="text" class="form-control certificate-no" id="serviceTax"
                                 name="certificate_no" maxlength="100" value="{{ $claim->certificate_no }}" required
                                 readonly placeholder="Certificate No." />

                             </div>
                           </div>
                           <!--end col-->
                           <div class="col-lg-3">
                             <div>
                               <label for="serviceTax" class="form-label">Last updated on</label>
                               <input type="date" class="form-control last-updated-on" id="serviceTax"
                                 name="last_updated_on" readonly
                                 value="{{ isset($claim->last_updated_on) ? $claim->last_updated_on->format('Y-m-d') : '' }}"
                                 required placeholder="Last updated on" />
                             </div>
                           </div>

                           <div class="col-lg-3">
                             <div>
                               <label for="serviceTax" class="form-label">Original TDS Claim Amount</label>
                               <input type="number" min="0" step="0.01"
                                 class="form-control tds-claim-amount" id="serviceTax" readonly
                                 value="{{ $claim->original_tds_claim_amount === null ? $claim->tds_claim_amount : $claim->original_tds_claim_amount }}"
                                 required @if (!Auth::guard('company_staff')->check()) readonly @endif
                                 placeholder="TDS Claim Amount" />

                             </div>
                           </div>

                           <!--end col-->
                           <div class="col-lg-12" style="border-top:1px solid #eee;"></div>
                           <div class="col-lg-12 mt-0"
                             style="border:1px solid #eee;background: #fafafa;padding: 20px;">
                             <div class="row">
                               <div class="col-lg-12">
                                 <div class="mt-2">
                                   <label for="banknameInput" class="form-label font-normal"><a
                                       @isset($claim->ltdc_file) target="_blank" href="{{ asset('crm/public/uploads/ltdc-') . $claim->financial_year . '/' . $claim->ltdc_file }}" @endisset><i
                                         class=" bx bxs-file-pdf"></i> View Merchant Lower TAX
                                       Deduction
                                       Certificate( LTDC) : (Click to View).</a>
                                   </label>
                                 </div>
                                 <div class="mt-2">
                                   <label for="banknameInput"
                                     class="form-label font-normal @if ($claim->quarter !== '4') d-none @endif">
                                     <a
                                       @isset($claim->ltdc_file) target="_blank" href="{{ asset('crm/public/uploads/ltdc-') . $claim->financial_year . '-r' . '/' . $claim->ltdc_file }}" @endisset><i
                                         class=" bx bxs-file-pdf"></i>
                                       View Revised Merchant Lower TAX Deduction Certificate( LTDC) : (Click to
                                       View).
                                     </a>
                                   </label>
                                 </div>
                               </div>
                               <!--end col-->
                               <div class="col-lg-3">
                                 <div class="mt-3">
                                   <label for="branchInput" class="form-label font-normal">LTDC available</label>
                                   <input type="text" class="form-control ltdc" id="ltdc" name="ltdc"
                                     maxlength="100" value="{{ $claim->ltdc }}" readonly
                                     placeholder="Certificate No." />
                                 </div>
                               </div>
                               <!--end col-->
                               <div class="col-lg-3">
                                 <div class="mt-3">
                                   <label for="ifscInput" class="form-label font-normal">LTDC Total limit</label>
                                   <input type="number" class="form-control ltdc-total-limit" min="0"
                                     step="0.01" id="ifscInput" placeholder="Enter" name="ltdc_total_limit"
                                     value="{{ $claim->ltdc_total_limit }}" readonly>
                                 </div>
                               </div>
                               <!--end col-->
                               <div class="col-lg-3">
                                 <div class="mt-3">
                                   <label for="accountnameInput" class="form-label font-normal">LTDC Rate</label>
                                   <input type="text" class="form-control ltdc-rate" id="accountnameInput"
                                     placeholder="Enter" min="0" step="0.01" name="ltdc_rate"
                                     value="{{ $claim->ltdc_rate }}" readonly>
                                 </div>
                               </div>
                               <!--end col-->
                               <div class="col-lg-3">
                                 <div class="mt-3">
                                   <label for="accountnumberInput" class="form-label font-normal">LTDC limit
                                     available</label>
                                   <input type="number" class="form-control tds-limit-available"
                                     id="accountnumberInput" placeholder="Enter" min="0" step="0.01"
                                     name="tdc_limit" value="{{ $claim->tdc_limit }}" readonly>
                                 </div>
                               </div>
                             </div>
                           </div>
                           <!--end col-->
                           @auth('company_staff')
                             <div class="col-lg-12 mt-0" style="border:1px solid #eee;background: #grey;padding: 20px;">
                               <div class="row">
                                 @if (isset($ltdcs[0]) && $claim->nature_of_tds !== $ltdcs[0]->section)
                                   <p class="text-danger fw-bold text-center">Claim TDS Section and LTDC section is not
                                     same.</p>
                                 @endif
                                 @if (($claim->rate_of_tds !== $claim->ltdc_rate || $claim->tdc_limit === 0.0) && $claim->ltdc === 'Yes')
                                   <p class="text-danger fw-bold text-center">
                                     LTDC is available and the merchant has not taken benefit.
                                   </p>
                                 @endif
                                 @if ($grandTotalOfTds !== $claim->tds_claim_amount)
                                   <p class="text-danger fw-bold text-center">TDS claim amount is not matching with the
                                     grand total of 26AS.</p>
                                 @endif
                               </div>
                             </div>
                           @endauth

                           <!--end col-->
                           <div class="col-lg-12" style="border-top:1px solid #eee;"></div>
                           <div class="col-lg-12 mt-0"
                             style="border:1px solid #eee;background: #fafafa;padding: 20px;">
                             <div class="row">
                               <x-ltdc-table :ltdcs="$ltdcs" />
                             </div>
                           </div>
                           <!--end col-->

                           <div class="col-lg-12" style="border-top:1px solid #eee;"></div>
                           <div class="col-lg-12 mt-0"
                             style="border:1px solid #eee;background: #fafafa;padding: 20px;">
                             <div class="row">
                               <div class="col-lg-12">
                                 <div class="mt-2">
                                   <label for="banknameInput" class="form-label font-normal"><a href=""><i
                                         class="bx bxs-bank"></i> Claim Bank Details</a> </label>
                                 </div>
                               </div>

                               <div class="row">
                                 <div class="col-lg-4">
                                   <div class="mb-3">
                                     <label for="banknameInput" class="form-label">Bank
                                       Name</label>
                                     <input type="text" readonly class="form-control" id="banknameInput"
                                       placeholder="Enter your bank name" name="name" maxlength="100"
                                       value="{{ $claim->bankDetail?->name }}" required>
                                   </div>
                                 </div>
                                 <!--end col-->
                                 <div class="col-lg-4">
                                   <div class="mb-3">
                                     <label for="branchInput" class="form-label">Branch</label>
                                     <input type="text" readonly class="form-control" id="branchInput"
                                       placeholder="Branch" name="branch" maxlength="100"
                                       value="{{ $claim->bankDetail?->branch }}" required>
                                   </div>
                                 </div>
                                 <!--end col-->
                                 <div class="col-lg-4">
                                   <div class="mb-3">
                                     <label for="ifscInput" class="form-label">IFSC</label>
                                     <input type="text" readonly class="form-control" id="ifscInput"
                                       placeholder="IFSC" name="ifsc" maxlength="11"
                                       title="Please use 11 chracters alpha numeric" pattern="[0-9A-Za-z]{11}"
                                       value="{{ $claim->bankDetail?->ifsc }}" required>
                                   </div>
                                 </div>
                                 <!--end col-->
                                 <div class="col-lg-4">
                                   <div class="mb-3">
                                     <label for="accountnameInput" class="form-label">Account
                                       Holder Name</label>
                                     <input type="text" readonly class="form-control" id="accountnameInput"
                                       placeholder="Enter account holder name" name="acc_holder_name" maxlength="100"
                                       value="{{ $claim->bankDetail?->acc_holder_name }}" required>
                                   </div>
                                 </div>
                                 <!--end col-->
                                 <div class="col-lg-4">
                                   <div class="mb-3">
                                     <label for="accountnumberInput" class="form-label">Account
                                       Number</label>
                                     <input type="text" readonly class="form-control" id="accountnumberInput"
                                       placeholder="Enter account number" name="account_number" maxlength="50"
                                       value="{{ $claim->bankDetail?->account_number }}"
                                       title="Please keep the account number length upto 50 characters long" required>
                                   </div>
                                 </div>
                                 <!--end col-->
                                 <div class="col-lg-4">
                                   <div class="mb-3">
                                     <label for="ifscInput" class="form-label">Cancel Cheque</label><br />
                                     @if (isset($claim->bankDetail->cancel_cheque) &&
                                             Storage::disk('appFiles')->exists("merchant/{$claim->bankDetail->cancel_cheque}"))
                                       <a href="{{ asset('crm/public/uploads/merchant') . '/' . $claim->bankDetail->cancel_cheque }}"
                                         target="_blank" class="btn btn-info">
                                         <p class="">Cheque
                                           <lord-icon src="https://cdn.lordicon.com/kpsnbsyj.json" trigger="loop"
                                             style="width:20px;height:20px">
                                           </lord-icon>
                                         </p>
                                       </a>
                                     @endif
                                   </div>
                                 </div>

                               </div>

                             </div>
                           </div>

                           <div class="col-lg-12" style="border-top:1px solid #eee;"></div>
                           <div class="col-lg-12 mt-0"
                             style="border:1px solid #eee;background: #fafafa;padding: 20px;">
                             <div class="row">
                               @if (Auth::guard('admin')->check() || Auth::guard('company_staff')->check())
                                 <div class="col-lg-12">
                                   <div class="mt-2">
                                     <label for="banknameInput" class="form-label w-100 fw-bold">
                                       <div class="row">
                                         <div class="col-auto">
                                           26AS Total:
                                         </div>
                                         <div class="col-10">
                                           ₹ {{ number_format($grandTotalOfForm26AS, 2) }}
                                         </div>
                                       </div>
                                       <div class="row">
                                         <div class="col-auto">
                                           Total TDS:
                                         </div>
                                         <div class="col-10">
                                           ₹ {{ number_format($grandTotalOfTds, 2) }}
                                         </div>
                                       </div>
                                     </label>
                                   </div>
                                 </div>
                               @endif
                             </div>
                           </div>

                           <div class="col-lg-12" style="border-top:1px solid #eee;">
                             <p class="text-center mb-0 mt-3">
                               <img
                                 src="@if ($claim->merchant->logo && Storage::disk('appFiles')->exists("merchant/{$claim->merchant->logo}")) {{ asset('crm/public/uploads/merchant') . '/' . $claim->merchant->logo }}@else {{ defaultProfileImage() }} @endif"
                                 alt="{{ $claim->merchant_company_name }}" style="width: 70px;height: 70px;">
                             </p>

                             <h5 class="mt-0 text-center" style="color: #52639c;">
                               {{ Str::ucfirst(auth()->user()->type) }} Response</h5>
                             <p class="mb-2 text-center">Note: Refer to last status & comment boxes: Please
                               provide relevant asked information and re-submit the claim. You claim ID will remain
                               same for further process. </p>
                           </div>

                           <div class="col-lg-12 mt-0"
                             style="border:1px solid #eee;background: #fafafa;padding: 20px;">
                             <div class="row">
                               <!--end col-->
                               @if ($claim->status === 5)
                                 <input type="hidden" name="status" value="{{ '1' }}">
                               @elseif($claim->status >= 2 && $claim->staff_id !== null && auth()->user()->type === 'merchant')
                                 <input type="hidden" name="status" value="{{ $claim->status }}">
                               @endif
                               <div class="col-lg-4
                               ">
                                 <div>
                                   <label for="ifscInput" class="form-label font-normal">Claim Status</label>
                                   <select class="form-select status" aria-label="Default select example"
                                     name="status">
                                     @if (auth()->user()->type === 'merchant')
                                       @if ($claim->status <= 1)
                                         <option @selected($claim->history->first()->status === 0) value="0">Draft</option>
                                         <option @selected($claim->history->first()->status === 1) value="1">Submit</option>
                                       @endif
                                     @endif
                                     @if (auth()->user()->type === 'Admin')
                                       <option @selected($claim->history->first()->status === 1) value="1">Submit</option>
                                       <option @selected($claim->history->first()->status === 2) value="2">In Process</option>
                                       <option @selected($claim->history->first()->status === 3) value="3">Approved</option>
                                       <option @selected($claim->history->first()->status === 4) value="4">Completed</option>
                                       <option @selected($claim->history->first()->status === 5) value="5">Reject</option>
                                       <option @selected($claim->history->first()->status === 6) value="6">On Hold</option>
                                     @endif
                                     @if (auth()->user()->type === 'staff')
                                       <option @selected($claim->history->first()->status === 2) value="2">In Process</option>
                                       <option @selected($claim->history->first()->status === 3) value="3">Approved</option>
                                       <option @selected($claim->history->first()->status === 5) value="5">Reject</option>
                                       <option @selected($claim->history->first()->status === 6) value="6">On Hold</option>
                                     @endif
                                   </select>
                                 </div>
                               </div>
                               <!--end col-->
                               @if (auth()->user()->type === 'staff' || auth()->user()->type === 'admin')
                                 <div class="col-lg-4">
                                   <div>
                                     <label for="ifscInput" class="form-label font-normal">Claim Document
                                       Status</label>
                                     <select class="form-select" aria-label="Default select example"
                                       name="claim_document_status">
                                       <option @selected(old('claim_document_status') === 'Form16 Uploaded') value="Form16 Uploaded">Form16 Uploaded
                                       </option>
                                       <option @selected(old('claim_document_status') === 'Form 16A Not Opening') value="Form 16A Not Opening">Form 16A
                                         Not
                                         Opening</option>
                                       <option @selected(old('claim_document_status') === 'Duplicate Claim') value="Duplicate Claim">Duplicate Claim
                                       </option>
                                       <option @selected(old('claim_document_status') === 'In Correct Details') value="In Correct Details">In Correct
                                         Details
                                       </option>
                                       <option @selected(old('claim_document_status') === 'Amount Not Matched / Form16') value="Amount Not Matched / Form16">
                                         Amount
                                         Not
                                         Matched / Form16</option>
                                       <option @selected(old('claim_document_status') === 'Already Processed') value="Already Processed">Already
                                         Processed
                                       </option>
                                     </select>
                                   </div>
                                 </div>
                               @endif

                               <!--end col-->
                               <div class="col-lg-4">
                                 <div>
                                   <label for="ifscInput" class="form-label font-normal">Attachments</label>
                                   <input type="file" class="form-control" placeholder="" name="attachment_file"
                                     accept=".pdf,.jpg,.jpeg,.webp,.png,.doc,.docx,.xlsx,.xls,.csv">
                                 </div>
                               </div>

                               <!--end col-->
                               <div class="col-lg-12">
                                 <div class="mt-3">
                                   <label for="ifscInput" class="form-label font-normal">Remarks</label>
                                   <textarea class="form-control" style="height:100px" name="remark" maxlength="200">{{ old('remark') }}</textarea>
                                 </div>
                               </div>

                               <!--end col-->

                               {{-- <div class="col-lg-6 mt-3">
                                 <div>
                                   <label for="serviceTax" class="form-label"> Total Amount Paid/Credited</label>
                                   <input type="number" min="0" step="0.01" class="form-control"
                                     id="serviceTax" placeholder="Enter" name="paid_amount" />
                                 </div>
                               </div>

                               <div class="col-lg-6 mt-3">
                                 <div>
                                   <label for="serviceTax" class="form-label"> TDS Claim Amount</label>
                                   <input type="number" min="0" step="0.01" class="form-control"
                                     id="serviceTax" placeholder="Enter" name="claim_amount" />
                                 </div>
                              </div> --}}


                             </div>
                           </div>

                           <!--end col-->
                           <div class="col-lg-12">
                             <div class="d-flex align-items-start gap-3 mt-3">
                               @auth('web')
                                 <button type="submit" class="btn btn-primary btn-label  nexttab"
                                   onclick="document.querySelector('.status').value='0'"><i
                                     class="ri-arrow-left-line label-icon align-middle fs-16 ms-2"></i>
                                   Save as Draft</button>
                               @endauth
                               <button type="submit" class="btn btn-primary btn-label right ms-auto nexttab"><i
                                   class="ri-arrow-right-line label-icon align-middle fs-16 ms-2"></i>
                                 Save</button>
                             </div>
                           </div>


                           <!--end col-->
                         </div>
                         <!--end row-->
                         @if (Auth::guard('admin')->check() || Auth::guard('company_staff')->check())
                           <div class="row mt-5">
                             <div class="mb-3">
                               <label for="banknameInput" class="form-label font-normal"><a href=""><i
                                     class="bx bxs-bank"></i>Claim Form 26AS History</a> </label>
                             </div>
                             <div class="table-responsive" style="max-height: 320px;overflow-y: auto;">
                               <table class="table table-striped">
                                 <thead>
                                   <tr>
                                     <th scope="col">#</th>
                                     <th scope="col">Transaction Date</th>
                                     <th scope="col">Date of Booking</th>
                                     <th scope="col">Remarks</th>
                                     <th scope="col">Total Tax Deducted</th>
                                     <th scope="col">Total TDS Deposited</th>
                                     <th scope="col">Type/Category</th>
                                     <th scope="col">Section</th>
                                     <th scope="col">Rate</th>
                                     <th scope="col">Total Amount Paid</th>
                                   </tr>
                                 </thead>
                                 <tbody>
                                   @forelse($form26AS as $key => $form)
                                     <tr>
                                       <th scope="row">{{ ++$key }}</th>
                                       <td>{{ $form->transaction_date->format('d M, Y') }}</td>
                                       <td>{{ $form->date_of_booking->format('d M, Y') }}</td>
                                       <td>{{ $form->remarks }}</td>
                                       <td>₹ {{ number_format($form->total_tax_deducted, 2) }}</td>
                                       <td>₹ {{ number_format($form->total_tds_deposited, 2) }}</td>
                                       <td>{{ $form->category }}</td>
                                       <td>{{ $form->section }}</td>
                                       <td>{{ number_format($form->rate, 2) }}%</td>
                                       <td>₹ {{ number_format($form->total_amount_paid, 2) }}</td>
                                     </tr>
                                   @empty
                                     <tr>
                                       <td colspan="10" class="text-center">No data found</td>
                                     </tr>
                                   @endforelse
                                   <tr>
                                     <td colspan="10"></td>
                                   </tr>
                                   <tr>
                                     <td colspan="5" class="fw-bold">Total</td>
                                     <td colspan="4">
                                       ₹ {{ number_format($grandTotalOfTds, 2) }}
                                     </td>
                                     <td class="text-right">₹
                                       {{ number_format($grandTotalOfForm26AS, 2) }}</td>
                                   </tr>
                                 </tbody>
                               </table>
                             </div>
                           </div>
                         @endif

                       </div>
                       <!-- end tab pane -->
                     </div>
                     <!-- end tab content -->
                   </div>
                   <!--end modal-body-->

                 </div>
               </div>
             </div>
           </div>
         </fieldset>
       </form>
       <!--end card-->
     </div>
     <!--end col-->
     <div class="col-lg-5">
       <div class="checkout-tab">
         <x-merchant.claim-history :histories="$claim->history" />
       </div>
       <!--end card-->
     </div>
   </div>
