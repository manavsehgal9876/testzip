<div class="card">
  <div class="card-body">
    <div class="text-left">
      <div class="row justify-content-center">
        <div class="col-lg-12 text-center">
          <h4 class="mt-4 fw-semibold">CLAIM HISTORY</h4>
        </div>
      </div>

      <div class="row justify-content-center mb-2">
        <!--end modal-body-->
        <div class="mt-3">
          @forelse ($histories as $history)
            <div class="accordion accordion-border-box" id="manageaccount-accordion">
              @switch($history->status)
                @case(0)
                  <div class="accordion-item">
                    <h2 class="accordion-header" id="manageaccount{{ $history->id }}">
                      <button class="accordion-button" type="button" data-bs-toggle="collapse"
                        data-bs-target="#manageaccount-collapse{{ $history->id }}" aria-expanded="true"
                        aria-controls="manageaccount-collapse{{ $history->id }}"
                        style="background: rgba(53, 119, 241, .1);">
                        Status : Draft
                        <span
                          style="position: absolute;right: 60px;">{{ $history->created_at->format('d M, Y, h:i A') }}</span>
                      </button>
                    </h2>
                    <div id="manageaccount-collapse{{ $history->id }}" class="accordion-collapse collapse show"
                      aria-labelledby="manageaccount{{ $history->id }}" data-bs-parent="#manageaccount-accordion">
                      <div @class([
                          'accordion-body',
                          'bg-soft-danger' => $history->updatedBy->type == 'merchant',
                          'bg-soft-primary' => $history->updatedBy->type == 'admin',
                          'bg-soft-info' => $history->updatedBy->type == 'staff',
                      ])>
                        <p class="mb-0"> Claim ID: <span
                            style="color: #2d4187 !important;">{{ $history->claim->claim_id }}</span></p>
                        <p class="mb-0">Merchant : {{ $history->claim->merchant_company_name }} <span
                            style="color: #2d4187 !important;">(SAP Code :
                            {{ $history->claim->merchant->sap_code }})</span></p>
                        <p class="mb-0">Remark:<span style="color: #2d4187 !important;"> {{ $history->remark }}
                          </span></p>
                        {{-- <p class="mb-0">Total Amount Paid/Credited:<span
                            style="color: #2d4187 !important;">{{ $history->total_paid_amount }}</span></p>
                        <p class="mb-0">TDS Claim Amount:<span
                            style="color: #2d4187 !important;">{{ $history->tds_claim_amount }}</span></p> --}}
                        <p class="mb-0">By.:<span style="color: #2d4187 !important;">
                            {{ isset($history->updatedBy->company_name) ? $history->updatedBy->company_name : $history->updatedBy->full_name }}
                            ({{ Str::ucfirst($history->updatedBy->type) }})
                          </span></p>
                        @if ($history->attachment && Storage::disk('appFiles')->exists("claim/{$history->attachment}"))
                          <p class="mb-0">Attachment:
                            <a href="{{ asset('crm/public/uploads/claim') . '/' . $history->attachment }}"
                              target="_blank"><i class="ri-download-2-line fs-17 lh-1 align-middle"></i>
                            </a>
                          </p>
                        @else
                          <p class="mb-0">Attachment:
                            <span style="color: #2d4187 !important;">N/A</span>
                          </p>
                        @endif
                      </div>
                    </div>
                  </div>
                @break

                @case(1)
                  <div class="accordion-item">
                    <h2 class="accordion-header" id="manageaccount{{ $history->id }}">
                      <button class="accordion-button" type="button" data-bs-toggle="collapse"
                        data-bs-target="#manageaccount-collapse{{ $history->id }}" aria-expanded="true"
                        aria-controls="manageaccount-collapse{{ $history->id }}" style="background: #ffa38f;">
                        Status : Submitted
                        <span
                          style="position: absolute;right: 60px;">{{ $history->created_at->format('d M, Y, h:i A') }}</span>
                      </button>
                    </h2>
                    <div id="manageaccount-collapse{{ $history->id }}" class="accordion-collapse collapse show"
                      aria-labelledby="manageaccount{{ $history->id }}" data-bs-parent="#manageaccount-accordion">
                      <div @class([
                          'accordion-body',
                          'bg-soft-danger' => $history->updatedBy->type == 'merchant',
                          'bg-soft-primary' => $history->updatedBy->type == 'admin',
                          'bg-soft-info' => $history->updatedBy->type == 'staff',
                      ])>
                        <p class="mb-0"> Claim ID: <span
                            style="color: #2d4187 !important;">{{ $history->claim->claim_id }}</span></p>
                        <p class="mb-0">Merchant : {{ $history->claim->merchant_company_name }} <span
                            style="color: #2d4187 !important;">(SAP Code :
                            {{ $history->claim->merchant->sap_code }})</span></p>
                        <p class="mb-0">Remark:<span style="color: #2d4187 !important;"> {{ $history->remark }}
                          </span></p>
                        {{-- <p class="mb-0">Total Amount Paid/Credited:<span
                            style="color: #2d4187 !important;">{{ $history->total_paid_amount }}</span></p>
                        <p class="mb-0">TDS Claim Amount:<span
                            style="color: #2d4187 !important;">{{ $history->tds_claim_amount }}</span></p> --}}
                        <p class="mb-0">By.:<span style="color: #2d4187 !important;">
                            {{ isset($history->updatedBy->company_name) ? $history->updatedBy->company_name : $history->updatedBy->full_name }}
                            ({{ Str::ucfirst($history->updatedBy->type) }})
                          </span></p>
                        @if ($history->attachment && Storage::disk('appFiles')->exists("claim/{$history->attachment}"))
                          <p class="mb-0">Attachment:
                            <a href="{{ asset('crm/public/uploads/claim') . '/' . $history->attachment }}" target="_blank">
                              <i class="ri-download-2-line fs-17 lh-1 align-middle"></i>
                            </a>
                          </p>
                        @else
                          <p class="mb-0">Attachment:
                            <span style="color: #2d4187 !important;">N/A</span>
                          </p>
                        @endif
                      </div>
                    </div>
                  </div>
                @break

                @case(2)
                  <div class="accordion-item">
                    <h2 class="accordion-header" id="manageaccount{{ $history->id }}">
                      <button class="accordion-button" type="button" data-bs-toggle="collapse"
                        data-bs-target="#manageaccount-collapse{{ $history->id }}" aria-expanded="true"
                        aria-controls="manageaccount-collapse{{ $history->id }}" style="background: #ffda9a;">
                        Status : In Process
                        <span
                          style="position: absolute;right: 60px;">{{ $history->created_at->format('d M, Y, h:i A') }}</span>
                      </button>
                    </h2>
                    <div id="manageaccount-collapse{{ $history->id }}" class="accordion-collapse collapse show"
                      aria-labelledby="manageaccount{{ $history->id }}" data-bs-parent="#manageaccount-accordion">
                      <div @class([
                          'accordion-body',
                          'bg-soft-danger' => $history->updatedBy->type == 'merchant',
                          'bg-soft-primary' => $history->updatedBy->type == 'admin',
                          'bg-soft-info' => $history->updatedBy->type == 'staff',
                      ])>
                        <p class="mb-0"> Claim ID: <span
                            style="color: #2d4187 !important;">{{ $history->claim->claim_id }}</span></p>
                        <p class="mb-0">Merchant : {{ $history->claim->merchant_company_name }} <span
                            style="color: #2d4187 !important;">(SAP Code :
                            {{ $history->claim->merchant->sap_code }})</span></p>
                        <p class="mb-0">Remark:<span style="color: #2d4187 !important;"> {{ $history->remark }}
                          </span></p>
                        {{-- <p class="mb-0">Total Amount Paid/Credited:<span
                            style="color: #2d4187 !important;">{{ $history->total_paid_amount }}</span></p>
                        <p class="mb-0">TDS Claim Amount:<span
                            style="color: #2d4187 !important;">{{ $history->tds_claim_amount }}</span></p> --}}
                        <p class="mb-0">By.:<span style="color: #2d4187 !important;">
                            {{ isset($history->updatedBy->company_name) ? $history->updatedBy->company_name : $history->updatedBy->full_name }}
                          </span></p>
                        @if ($history->attachment && Storage::disk('appFiles')->exists("claim/{$history->attachment}"))
                          <p class="mb-0">Attachment:
                            <a href="{{ asset('crm/public/uploads/claim') . '/' . $history->attachment }}" target="_blank">
                              <i class="ri-download-2-line fs-17 lh-1 align-middle"></i>
                            </a>
                          </p>
                        @else
                          <p class="mb-0">Attachment:
                            <span style="color: #2d4187 !important;">N/A</span>
                          </p>
                        @endif
                      </div>
                    </div>
                  </div>
                @break

                @case(3)
                  <div class="accordion-item">
                    <h2 class="accordion-header" id="manageaccount{{ $history->id }}">
                      <button class="accordion-button" type="button" data-bs-toggle="collapse"
                        data-bs-target="#manageaccount-collapse{{ $history->id }}" aria-expanded="true"
                        aria-controls="manageaccount-collapse{{ $history->id }}"
                        style="background: #a7bcff !important;">
                        Status : Approved
                        <span
                          style="position: absolute;right: 60px;">{{ $history->created_at->format('d M, Y, h:i A') }}</span>
                      </button>
                    </h2>
                    <div id="manageaccount-collapse{{ $history->id }}" class="accordion-collapse collapse show"
                      aria-labelledby="manageaccount{{ $history->id }}" data-bs-parent="#manageaccount-accordion">
                      <div @class([
                          'accordion-body',
                          'bg-soft-danger' => $history->updatedBy->type == 'merchant',
                          'bg-soft-primary' => $history->updatedBy->type == 'admin',
                          'bg-soft-info' => $history->updatedBy->type == 'staff',
                      ])>
                        <p class="mb-0"> Claim ID: <span
                            style="color: #2d4187 !important;">{{ $history->claim->claim_id }}</span></p>
                        <p class="mb-0">Merchant : {{ $history->claim->merchant_company_name }} <span
                            style="color: #2d4187 !important;">(SAP Code :
                            {{ $history->claim->merchant->sap_code }})</span></p>
                        <p class="mb-0">Remark:<span style="color: #2d4187 !important;"> {{ $history->remark }}
                          </span></p>
                        {{-- <p class="mb-0">Total Amount Paid/Credited:<span
                            style="color: #2d4187 !important;">{{ $history->total_paid_amount }}</span></p>
                        <p class="mb-0">TDS Claim Amount:<span
                            style="color: #2d4187 !important;">{{ $history->tds_claim_amount }}</span></p> --}}
                        <p class="mb-0">By.:<span style="color: #2d4187 !important;">
                            {{ isset($history->updatedBy->company_name) ? $history->updatedBy->company_name : $history->updatedBy->full_name }}
                          </span></p>
                        @if ($history->attachment && Storage::disk('appFiles')->exists("claim/{$history->attachment}"))
                          <p class="mb-0">Attachment:
                            <a href="{{ asset('crm/public/uploads/claim') . '/' . $history->attachment }}"
                              target="_blank">
                              <i class="ri-download-2-line fs-17 lh-1 align-middle"></i>
                            </a>
                          </p>
                        @else
                          <p class="mb-0">Attachment:
                            <span style="color: #2d4187 !important;">N/A</span>
                          </p>
                        @endif
                      </div>
                    </div>
                  </div>
                @break

                @case(4)
                  <div class="accordion-item">
                    <h2 class="accordion-header" id="manageaccount-headingOne">
                      <button class="accordion-button " type="button" data-bs-toggle="collapse"
                        data-bs-target="#manageaccount-collapseOne" aria-expanded="true"
                        aria-controls="manageaccount-collapseOne" style="background: #e4f3df;">
                        Status : Payment Completed
                        <span style="position: absolute;right: 60px;">{{ $history->created_at->format('d M, Y, h:i A') }}
                        </span>
                      </button>
                    </h2>
                    <div id="manageaccount-collapseOne" class="accordion-collapse collapse show"
                      aria-labelledby="manageaccount-headingOne" data-bs-parent="#manageaccount-accordion">
                      <div @class([
                          'accordion-body',
                          'bg-soft-danger' => $history->updatedBy->type == 'merchant',
                          'bg-soft-primary' => $history->updatedBy->type == 'admin',
                          'bg-soft-info' => $history->updatedBy->type == 'staff',
                      ])>

                        <p class="mb-0">Claim ID: <span
                            style="color: #2d4187 !important;">{{ $history->claim->claim_id }}</span></p>
                        <p class="mb-0">Merchant :<span style="color: #2d4187 !important;">
                            {{ $history->claim->merchant_company_name }} (SAP Code :
                            {{ $history->claim->merchant->sap_code }})</span>
                        </p>
                        <p class="mb-0">SAP Document No. :<span style="color: #2d4187 !important;">
                            {{ $history->claim->sap_payment_doc_no }}</span></p>
                        <p class="mb-0">UTR Number :<span style="color: #2d4187 !important;">
                            {{ $history->claim->utr }}</span></p>
                        <p class="mb-0">Payment Date :<span style="color: #2d4187 !important;">
                            {{ $history->claim->payment_date?->format('d M, Y') }}</span></p>
                        <p class="mb-0">Certificate No :
                          <span style="color: #2d4187 !important;">
                            {{ $history->claim->certificate_no }}
                          </span>
                        </p>
                        <p class="mb-0">Last Update :
                          <span style="color: #2d4187 !important;">
                            {{ isset($history->claim->last_updated_on) ? $history->claim->last_updated_on->format('d M, Y') : 'N/A' }}
                          </span>
                        </p>
                        <p class="mb-0">TDS Section :<span style="color: #2d4187 !important;">
                            {{ $history->claim->nature_of_tds }}</span></p>
                        <p class="mb-0">KAM Email :<span style="color: #2d4187 !important;">
                            {{ $history->updatedBy->email }}</span></p>
                        <p class="mb-0">Merchant Email :<span style="color: #2d4187 !important;">
                            {{ $history->claim->merchant->primaryStaff?->email }}</span></p>
                        <p class="mb-0">Remark :<span style="color: #2d4187 !important;">
                            {{ $history->remark }}</span></p>
                        {{-- <p class="mb-0">Total Amount Paid/Credited:<span
                            style="color: #2d4187 !important;">{{ $history->total_paid_amount }}</span></p>
                        <p class="mb-0">TDS Claim Amount:<span
                            style="color: #2d4187 !important;">{{ $history->tds_claim_amount }}</span></p> --}}
                        @if ($history->attachment && Storage::disk('appFiles')->exists("claim/{$history->attachment}"))
                          <p class="mb-0">Attachment:
                            <a href="{{ asset('crm/public/uploads/claim') . '/' . $history->attachment }}"
                              target="_blank">
                              <i class="ri-download-2-line fs-17 lh-1 align-middle"></i>
                            </a>
                          </p>
                        @else
                          <p class="mb-0">Attachment:
                            <span style="color: #2d4187 !important;">N/A</span>
                          </p>
                        @endif
                      </div>
                    </div>
                  </div>
                @break

                @case(5)
                  <div class="accordion-item">
                    <h2 class="accordion-header" id="manageaccount{{ $history->id }}">
                      <button class="accordion-button" type="button" data-bs-toggle="collapse"
                        data-bs-target="#manageaccount-collapse{{ $history->id }}" aria-expanded="true"
                        aria-controls="manageaccount-collapse{{ $history->id }}" style="background:rgb(255 0 0 / 52%);">
                        Status : Rejected
                        <span
                          style="position: absolute;right: 60px;">{{ $history->created_at->format('d M, Y, h:i A') }}</span>
                      </button>
                    </h2>
                    <div id="manageaccount-collapse{{ $history->id }}" class="accordion-collapse collapse show"
                      aria-labelledby="manageaccount{{ $history->id }}" data-bs-parent="#manageaccount-accordion">
                      <div @class([
                          'accordion-body',
                          'bg-soft-danger' => $history->updatedBy->type == 'merchant',
                          'bg-soft-primary' => $history->updatedBy->type == 'admin',
                          'bg-soft-info' => $history->updatedBy->type == 'staff',
                      ])>
                        <p class="mb-0"> Claim ID: <span
                            style="color: #2d4187 !important;">{{ $history->claim->claim_id }}</span></p>
                        <p class="mb-0">Merchant : {{ $history->claim->merchant_company_name }} <span
                            style="color: #2d4187 !important;">(SAP Code :
                            {{ $history->claim->merchant->sap_code }})</span></p>
                        <p class="mb-0">Remark:<span style="color: #2d4187 !important;"> {{ $history->remark }}
                          </span></p>
                        {{-- <p class="mb-0">Total Amount Paid/Credited:<span
                            style="color: #2d4187 !important;">{{ $history->total_paid_amount }}</span></p>
                        <p class="mb-0">TDS Claim Amount:<span
                            style="color: #2d4187 !important;">{{ $history->tds_claim_amount }}</span></p> --}}
                        <p class="mb-0">By.:<span style="color: #2d4187 !important;">
                            {{ isset($history->updatedBy->company_name) ? $history->updatedBy->company_name : $history->updatedBy->full_name }}
                            ({{ Str::ucfirst($history->updatedBy->type) }})
                          </span></p>
                        @if ($history->attachment && Storage::disk('appFiles')->exists("claim/{$history->attachment}"))
                          <p class="mb-0">Attachment:
                            <a href="{{ asset('crm/public/uploads/claim') . '/' . $history->attachment }}"
                              target="_blank"><i class="ri-download-2-line fs-17 lh-1 align-middle"></i>
                            </a>
                          </p>
                        @else
                          <p class="mb-0">Attachment:
                            <span style="color: #2d4187 !important;">N/A</span>
                          </p>
                        @endif
                      </div>
                    </div>
                  </div>
                @break

                @case(6)
                  <div class="accordion-item">
                    <h2 class="accordion-header" id="manageaccount{{ $history->id }}">
                      <button class="accordion-button" type="button" data-bs-toggle="collapse"
                        data-bs-target="#manageaccount-collapse{{ $history->id }}" aria-expanded="true"
                        aria-controls="manageaccount-collapse{{ $history->id }}"
                        style="background: rgba(53, 119, 241, .1);">
                        Status : On Hold
                        <span
                          style="position: absolute;right: 60px;">{{ $history->created_at->format('d M, Y, h:i A') }}</span>
                      </button>
                    </h2>
                    <div id="manageaccount-collapse{{ $history->id }}" class="accordion-collapse collapse show"
                      aria-labelledby="manageaccount{{ $history->id }}" data-bs-parent="#manageaccount-accordion">
                      <div @class([
                          'accordion-body',
                          'bg-soft-danger' => $history->updatedBy->type == 'merchant',
                          'bg-soft-primary' => $history->updatedBy->type == 'admin',
                          'bg-soft-info' => $history->updatedBy->type == 'staff',
                      ])>
                        <p class="mb-0"> Claim ID: <span
                            style="color: #2d4187 !important;">{{ $history->claim->claim_id }}</span></p>
                        <p class="mb-0">Merchant : {{ $history->claim->merchant_company_name }} <span
                            style="color: #2d4187 !important;">(SAP Code :
                            {{ $history->claim->merchant->sap_code }})</span></p>
                        <p class="mb-0">Remark:<span style="color: #2d4187 !important;"> {{ $history->remark }}
                          </span></p>
                        <p class="mb-0">Total Amount Paid/Credited:<span
                            style="color: #2d4187 !important;">{{ $history->paid_amount }}</span></p>
                        <p class="mb-0">TDS Claim Amount:<span
                            style="color: #2d4187 !important;">{{ $history->claim_amount }}</span></p>
                        <p class="mb-0">By.:<span style="color: #2d4187 !important;">
                            {{ isset($history->updatedBy->company_name) ? $history->updatedBy->company_name : $history->updatedBy->full_name }}
                            ({{ Str::ucfirst($history->updatedBy->type) }})
                          </span></p>
                        @if ($history->attachment && Storage::disk('appFiles')->exists("claim/{$history->attachment}"))
                          <p class="mb-0">Attachment:
                            <a href="{{ asset('crm/public/uploads/claim') . '/' . $history->attachment }}"
                              target="_blank"><i class="ri-download-2-line fs-17 lh-1 align-middle"></i>
                            </a>
                          </p>
                        @else
                          <p class="mb-0">Attachment:
                            <span style="color: #2d4187 !important;">N/A</span>
                          </p>
                        @endif
                      </div>
                    </div>
                  </div>
                @break
              @endswitch
              @empty
                <p class="mb-0 text-center">
                  No History Found
                  <lord-icon src="https://cdn.lordicon.com/kpsnbsyj.json" trigger="loop"
                    style="width:16px;height:16px">
                  </lord-icon>
                </p>
              </div>
            @endforelse

            <!--end accordion-->
          </div>
          <!--end modal-body-->

        </div>
      </div>
    </div>
  </div>
