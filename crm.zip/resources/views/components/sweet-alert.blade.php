@if ($message = Session::get('success'))
  <input type="hidden" class="sweet-msg" value="{{ $message }}" />
@endif
@if ($message = Session::get('sweet-alert-error'))
  <input type="hidden" class="sweet-msg-error" value="{{ $message }}" />
@endif
@if (isset($errors) && $errors->any())
  <input type="hidden" class="sweet-msg-error"
    value="@foreach ($errors->all() as $error) {{ $error }}<br/> @endforeach" />
@endif
