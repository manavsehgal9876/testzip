<div class="modal fade" id="staffListModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header p-3">
        <h5 class="modal-title text-uppercase" id="exampleModalLabel">Assign claim to active staff members.
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="table-responsive">
            <table class="table table-hover">
              <thead class="table-dark">
                <tr>
                  <th scope="col">
                    #
                  </th>
                  <th scope="col">Emp ID</th>
                  <th scope="col">Name</th>
                  <th scope="col">Company Name</th>
                  <th scope="col">Email</th>
                </tr>
              </thead>
              <tbody class="staff-list">
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary assign-btn">Assign</button>
      </div>
    </div>
  </div>
</div>
