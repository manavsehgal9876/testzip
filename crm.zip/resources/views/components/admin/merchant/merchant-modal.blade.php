 <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-dialog-centered modal-lg">
     <div class="modal-content">
       <div class="modal-header p-3">
         <h5 class="modal-title text-uppercase" id="exampleModalLabel">Add / Update Merchant Details.
         </h5>
         <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
       </div>
       <form action="{{ route('admin.merchants.store') }}" class="checkout-tab profile-form" method="post"
         enctype="multipart/form-data">
         @csrf
         <div class="modal-body p-0">
           <div class="step-arrow-nav">
             <ul class="nav nav-pills nav-justified custom-nav" role="tablist">
               <li class="nav-item" role="presentation">
                 <button class="nav-link p-3 active" id="pills-bill-info-tab" data-bs-toggle="pill"
                   data-bs-target="#pills-bill-info" type="button" role="tab" aria-controls="pills-bill-info"
                   aria-selected="true">Basic Info</button>
               </li>
               <li class="nav-item" role="presentation">
                 <button class="nav-link p-3" id="pills-bill-address-tab" data-bs-toggle="pill"
                   data-bs-target="#pills-bill-address" type="button" role="tab" aria-controls="pills-bill-address"
                   aria-selected="false">Bank Details</button>
               </li>
               <li class="nav-item" role="presentation">
                 <button class="nav-link p-3" id="pills-payment-tab" data-bs-toggle="pill"
                   data-bs-target="#pills-payment" type="button" role="tab" aria-controls="pills-payment"
                   aria-selected="false">Document Verification</button>
               </li>
               <li class="nav-item" role="presentation">
                 <button class="nav-link p-3" id="pills-finish-tab" data-bs-toggle="pill" data-bs-target="#pills-finish"
                   type="button" role="tab" aria-controls="pills-finish"
                   aria-selected="false">Representatve</button>
               </li>
             </ul>
           </div>
         </div>
         <!--end modal-body-->
         <div class="modal-body">
           <div class="tab-content">
             <div class="tab-pane fade show active" id="pills-bill-info" role="tabpanel"
               aria-labelledby="pills-bill-info-tab">
               <div class="row g-3">
                 <!--end col-->

                 <!--end col-->
                 <div class="col-lg-4">
                   <div>
                     <label for="serviceTax" class="form-label"> SAP Code <span
                         style="color:red;font-weight: normal;font-size: 12px;">(If not found,
                         generate)</span></label>
                     <input type="text" class="form-control" id="serviceTax" name="sap_code" placeholder="Sap code"
                       value="{{ old('sap_code') }}">
                   </div>
                 </div>
                 <div class="col-lg-4">
                   <div>
                     <label for="firstName" class="form-label">Merchant Company Name</label>
                     <input type="text" class="form-control" id="firstName" placeholder="Enter" name="company_name"
                       value="{{ old('company_name') }}" maxlength="100" required>
                   </div>
                 </div>
                 <!--end col-->
                 <div class="col-lg-4">
                   <div>
                     <label for="firstName" class="form-label">Merchant Name</label>
                     <input type="text" class="form-control" id="firstName" placeholder="Enter" name="name"
                       value="{{ old('name') }}" maxlength="100" required>
                   </div>
                 </div>
                 <!--end col-->
                 <div class="col-lg-4">
                   <div>
                     <label for="lastName" class="form-label">Merchant Email</label>
                     <input type="email" class="form-control" id="lastName" placeholder="Enter" name="email"
                       value="{{ old('email') }}" maxlength="100" required>
                   </div>
                 </div>


                 <!--end col-->
                 <div class="col-lg-4">
                   <div>
                     <label for="emailID" class="form-label"> Merchant Phone</label>
                     <input type="number" class="form-control" id="emailID" placeholder="Enter " name="phone"
                       value="{{ old('phone') }}" min="0">
                   </div>
                 </div>
                 <!--end col-->
                 <div class="col-lg-4">
                   <div>
                     <label for="emailID" class="form-label"> Merchant Website </label>
                     <input type="text" class="form-control" id="emailID" placeholder="Enter" name="website"
                       value="{{ old('website') }}" maxlength="1000">
                   </div>
                 </div>


                 <!--end col-->
                 <div class="col-lg-4">
                   <div>
                     <label for="confirmPassword" class="form-label">Business Category</label>
                     <select class="form-select" aria-label="Default select example" name="biz_category">
                       <option value="">Select</option>
                       <option @selected(old('biz_category') == 'Category 1') value="Category 1">Category 1</option>
                       <option @selected(old('biz_category') == 'Category 2') value="Category 2">Category 2</option>
                     </select>
                   </div>
                 </div>

                 <!--end col-->
                 <div class="col-lg-4">
                   <div>
                     <label for="confirmPassword" class="form-label">Business Industry</label>
                     <select class="form-select" aria-label="Default select example" name="biz_industry">
                       <option value="">Select</option>
                       <option @selected(old('biz_industry') === 'Category 1') value="Category 1">Category 1</option>
                       <option @selected(old('biz_industry') === 'Category 2') value="Category 2">Category 2</option>
                     </select>
                   </div>
                 </div>

                 <!--end col-->
                 <div class="col-lg-4">
                   <div class="mb-3">
                     <label for="accountnumberInput" class="form-label">Tan Number</label>
                     <input type="text" class="form-control" id="accountnumberInput" placeholder="Enter "
                       name="tan_number" value="{{ old('tan_number') }}" maxlength="10" required>
                   </div>
                 </div>
                 <!--end col-->
                 <div class="col-lg-4">
                   <div class="mb-3">
                     <label for="accountnumberInput" class="form-label">GST Number</label>
                     <input type="text" class="form-control" id="accountnumberInput" placeholder="Enter "
                       name="gst_number" value="{{ old('gst_number') }}" maxlength="15">
                   </div>
                 </div>
                 <div class="col-lg-4">
                   <div class="mb-3">
                     <label for="accountnumberInput" class="form-label">Pan Number</label>
                     <input type="text" class="form-control" id="accountnumberInput" placeholder="Enter "
                       name="pancard_number" value="{{ old('pancard_number') }}" maxlength="10">
                   </div>
                 </div>
                 <div class="col-lg-4">

                   <div class="mb-3">
                     <label for="accountnumberInput" class="form-label">Password</label>
                     <input type="password" class="form-control" id="accountnumberInput" placeholder="Enter "
                       name="password" value="{{ old('password') }}" minlegth="6" maxlength="30">
                   </div>
                 </div>
                 <div class="col-lg-12 mt-3 mb-3" style="border-top: 1px dashed #cccdcc;">

                 </div>
                 <div class="col-lg-12">
                   <div>
                     <label for="serviceTax" class="form-label">Merchant Address</label>
                     <input type="text" class="form-control" id="serviceTax" placeholder="Enter your Address"
                       name="address" value="{{ old('address') }}" maxlength="150">

                   </div>
                 </div>
                 <div class="col-lg-4">
                   <div>
                     <label for="serviceTax" class="form-label"> Country</label>
                     <select class="form-select " aria-label="Default select example" data-class=".states"
                       name="country" onchange="getStates(this)">
                       <option value="">Select</option>
                       @foreach (getCountries() as $country)
                         <option @selected(old('country') == $country->id) value="{{ $country->id }}">{{ $country->name }}
                         </option>
                       @endforeach
                     </select>
                   </div>
                 </div>
                 <div class="col-lg-4">
                   <div>
                     <label for="serviceTax" class="form-label"> State</label>
                     <select class="form-select states" data-class=".cities" aria-label="Default select example"
                       name="state" onchange="getCities(this)">
                       <option value="">Select</option>
                       @if (old('state') != null)
                         @foreach (getStates(old('country')) as $state)
                           <option @selected(old('state') == $state->id) value="{{ $state->id }}">{{ $state->name }}
                           </option>
                         @endforeach
                       @endif
                     </select>
                   </div>
                 </div>
                 <div class="col-lg-4">
                   <div>
                     <label for="serviceTax" class="form-label"> City</label>
                     <select class="form-select cities" aria-label="Default select example" name="city">
                       <option value="">Select</option>
                       @if (old('city') != null)
                         @foreach (getCities(old('state')) as $city)
                           <option @selected(old('city') == $city->id) value="{{ $city->id }}">{{ $city->name }}
                           </option>
                         @endforeach
                       @endif
                     </select>
                   </div>
                 </div>

                 <!--end col-->
                 <div class="col-lg-12">
                   <div class="d-flex align-items-start gap-3 mt-3">
                     <button type="submit" class="btn btn-primary btn-label right ms-auto nexttab"
                       data-nexttab="pills-bill-address-tab"><i
                         class="ri-arrow-right-line label-icon align-middle fs-16 ms-2"></i>
                       Save</button>
                   </div>
                 </div>
                 <!--end col-->
               </div>
               <!--end row-->
             </div>
             <!-- end tab pane -->

             <div class="tab-pane fade" id="pills-bill-address" role="tabpanel"
               aria-labelledby="pills-bill-address-tab">
               <div class="row">
                 <div class="col-lg-4">
                   <div class="mb-3">
                     <label for="banknameInput" class="form-label">Bank
                       Name</label>
                     <input type="text" class="form-control" id="banknameInput"
                       placeholder="Enter your bank name" name="bank_name" value="{{ old('bank_name') }}"
                       maxlength="50">
                   </div>
                 </div>
                 <!--end col-->
                 <div class="col-lg-4">
                   <div class="mb-3">
                     <label for="branchInput" class="form-label">Branch</label>
                     <input type="text" class="form-control" id="branchInput" placeholder="Branch"
                       name="bank_branch" value="{{ old('bank_branch') }}" maxlength="50">
                   </div>
                 </div>
                 <!--end col-->
                 <div class="col-lg-4">
                   <div class="mb-3">
                     <label for="ifscInput" class="form-label">IFSC</label>
                     <input type="text" class="form-control" id="ifscInput" placeholder="IFSC" name="ifsc_code"
                       value="{{ old('ifsc_code') }}" maxlength="50">
                   </div>
                 </div>
                 <!--end col-->
                 <div class="col-lg-4">
                   <div class="mb-3">
                     <label for="accountnameInput" class="form-label">Account
                       Holder Name</label>
                     <input type="text" class="form-control" id="accountnameInput" name="bank_acc_name"
                       value="{{ old('bank_acc_name') }}" maxlength="100" placeholder="Enter account holder name">
                   </div>
                 </div>
                 <!--end col-->
                 <div class="col-lg-4">
                   <div class="mb-3">
                     <label for="accountnumberInput" class="form-label">Account
                       Number</label>
                     <input type="number" class="form-control" id="accountnumberInput"
                       placeholder="Enter account number" name="bank_acc_no" value="{{ old('bank_acc_no') }}"
                       min="0">
                   </div>
                 </div>
                 <!--end col-->
                 <div class="col-lg-4">
                   <div class="mb-3">
                     <label for="ifscInput" class="form-label">Cancel Cheque</label>
                     <input type="file" class="form-control" name="cancel_cheque"
                       accept=".jpg, .png, .jpeg, .docx, .doc, .pdf">
                   </div>
                 </div>
                 <div class="row">
                   <div class="col-lg-3">
                     <div>
                       <div class="form-check mt-3">
                         <input class="form-check-input" type="checkbox" name="chk_child" value="option1">
                         Validate Data
                       </div>

                     </div>
                   </div>
                   <div class="col-lg-3 " style="margin-top: 11px;"><span style="color:green;"><i
                         class="ri-check-fill fs-16" style="color:green;font-weight: bold;"></i> Information
                       is Valid</span></div>
                 </div>

                 <!--end col-->
                 <div class="col-lg-12">
                   <div class="hstack align-items-start gap-3 mt-4">

                     <button type="button" class="btn btn-primary btn-label right ms-auto nexttab"
                       data-nexttab="pills-payment-tab"><i
                         class="ri-arrow-right-line label-icon align-middle fs-16 ms-2"></i>Save</button>
                   </div>
                 </div>
                 <!--end col-->
               </div>
             </div>
             <!-- end tab pane -->

             <div class="tab-pane fade" id="pills-payment" role="tabpanel" aria-labelledby="pills-payment-tab">
               <h5 class="mb-3">Choose Document Type</h5>

               <div class="d-flex gap-2">
                 <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                   <li class="nav-item" role="presentation">
                     <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill"
                       data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home"
                       aria-selected="true">Pancard</button>
                   </li>
                   <li class="nav-item" role="presentation">
                     <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill"
                       data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile"
                       aria-selected="false">Tan</button>
                   </li>
                   <li class="nav-item" role="presentation">
                     <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill"
                       data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact"
                       aria-selected="false">Gst</button>
                   </li>

                   <li class="nav-item" role="presentation">
                     <button class="nav-link" id="pills-logo-tab" data-bs-toggle="pill" data-bs-target="#pills-logo"
                       type="button" role="tab" aria-controls="pills-logo" aria-selected="false">Logo</button>
                   </li>
                 </ul>
               </div>
               <div class="tab-content" id="pills-tabContent">
                 <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
                   aria-labelledby="pills-home-tab">
                   <div class="dropzone d-flex align-items-center documents_upload_tb">
                     <div class="fallback">
                       <input type="file" name="pancard" accept=".jpg, .png, .jpeg, .docx, .doc, .pdf">
                     </div>
                     <div class="dz-message needsclick text-center">
                       <div class="mb-3">
                         <i class="display-4 text-muted ri-upload-cloud-2-fill"></i>
                       </div>
                       <h4>Drop pancard file here or click to upload.</h4>
                     </div>
                   </div>
                 </div>
                 <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                   <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
                     aria-labelledby="pills-home-tab">
                     <div class="dropzone d-flex align-items-center documents_upload_tb">
                       <div class="fallback">
                         <input type="file" name="tan" accept=".jpg, .png, .jpeg, .docx, .doc, .pdf">
                       </div>
                       <div class="dz-message needsclick text-center">
                         <div class="mb-3">
                           <i class="display-4 text-muted ri-upload-cloud-2-fill"></i>
                         </div>
                         <h4>Drop tan file here or click to upload.</h4>
                       </div>
                     </div>
                   </div>
                 </div>
                 <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                   <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
                     aria-labelledby="pills-home-tab">
                     <div class="dropzone d-flex align-items-center documents_upload_tb">
                       <div class="fallback">
                         <input type="file" name="gst" accept=".jpg, .png, .jpeg, .docx, .doc, .pdf">
                       </div>
                       <div class="dz-message needsclick text-center">
                         <div class="mb-3">
                           <i class="display-4 text-muted ri-upload-cloud-2-fill"></i>
                         </div>
                         <h4>Drop gst file here or click to upload.</h4>
                       </div>
                     </div>
                   </div>
                 </div>
                 <div class="tab-pane fade" id="pills-logo" role="tabpanel" aria-labelledby="pills-logo-tab">
                   <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
                     aria-labelledby="pills-home-tab">
                     <div class="dropzone d-flex align-items-center documents_upload_tb">
                       <div class="fallback">
                         <input type="file" name="logo_file" accept=".jpg, .png, .jpeg, .webp, .gif">
                       </div>
                       <div class="dz-message needsclick text-center">
                         <div class="mb-3">
                           <i class="display-4 text-muted ri-upload-cloud-2-fill"></i>
                         </div>
                         <h4>Drop logo file here or click to upload.</h4>
                       </div>
                     </div>
                   </div>
                 </div>
               </div>


               <ul class="list-unstyled mb-0" id="dropzone-preview">
                 <li class="mt-2" id="dropzone-preview-list">
                   <div class="border rounded">
                     <div class="d-flex p-2">
                       {{-- files --}}
                       <div class="flex-shrink-0 ms-3">
                         {{-- <button data-dz-remove class="btn btn-sm btn-danger">Delete</button> --}}
                       </div>
                     </div>
                   </div>
                 </li>

               </ul>
               <div class="row">
                 <div class="col-lg-3">
                   <div>
                     <div class="form-check mt-3">
                       <input class="form-check-input" type="checkbox" name="chk_child" value="option1">
                       Validate Data
                     </div>

                   </div>
                 </div>
                 <div class="col-lg-3 " style="margin-top: 11px;"><span style="color:green;"><i
                       class="ri-check-fill fs-16" style="color:green;font-weight: bold;"></i> Information is
                     Valid</span></div>
               </div>
               <!-- end dropzon-preview -->
               <div class="d-flex align-items-start gap-3 mt-4">

                 <button type="button" class="btn btn-primary btn-label right ms-auto nexttab"
                   data-nexttab="pills-finish-tab"><i
                     class="ri-save-line label-icon align-middle fs-16 ms-2"></i>Save</button>
               </div>
             </div>
             <!-- end tab pane -->

             <div class="tab-pane fade" id="pills-finish" role="tabpanel" aria-labelledby="pills-finish-tab">
               <div class="row g-3">

                 <div class="col-lg-6">
                   <label for="firstName" class="form-label mb-3">Photo Upload</label>
                   <div class="dropzone d-flex align-items-center documents_upload_tb">
                     <div class="fallback">
                       <input type="file" name="representative_photo" accept=".jpg, .png, .jpeg, .gif, .webp" />
                     </div>
                     <div class="dz-message needsclick text-center">
                       <div class="mb-3">
                         <i class="display-4 text-muted ri-upload-cloud-2-fill"></i>
                       </div>

                       <h4>Photo upload</h4>
                     </div>
                   </div>
                 </div>
                 <div class="col-lg-6">
                   <div class="row">
                     <!--end col-->
                     <div class="col-lg-12">
                       <div>
                         <label for="firstName" class="form-label">Full Name</label>
                         <input type="text" class="form-control mb-3" id="firstName" placeholder="Enter"
                           name="representative_name" value="{{ old('representative_name') }}" maxlength="100">
                       </div>
                     </div>
                     <!--end col-->
                     <div class="col-lg-12">
                       <div>
                         <label for="phoneNumber" class="form-label">Email ID</label>
                         <input type="email" class="form-control mb-3" id="phoneNumber" placeholder="Enter"
                           name="representative_email" value="{{ old('representative_email') }}" maxlength="150">
                       </div>
                     </div>

                     <!--end col-->
                     <div class="col-lg-12">
                       <div>
                         <label for="emailID" class="form-label"> Mobile No </label>
                         <input type="tel" class="form-control mb-3" id="emailID" placeholder="Enter"
                           name="representative_phone" value="{{ old('representative_phone') }}" min="0"
                           title="Please use a 10 digit telephone number with no dashes or dots"
                           pattern="[0-9]{10}" />
                       </div>
                     </div>
                     <!--end col-->
                     <div class="col-lg-6">
                       <div>
                         <label for="confirmPassword" class="form-label">Department</label>
                         <select class="form-select mb-3" aria-label="Default select example"
                           name="representative_department">

                           <option @selected(old('representative_department') === 'sales') value="sales">Sales</option>
                           <option @selected(old('representative_department') === 'marketing') value="marketing">Marketing</option>
                           <option @selected(old('representative_department') === 'development') value="development">Development</option>
                         </select>
                       </div>
                     </div>
                     <!--end col-->
                     <div class="col-lg-6">
                       <div>
                         <label for="vatNo" class="form-label">Designations</label>
                         <select class="form-select mb-3" aria-label="Default select example"
                           name="representative_designation">

                           <option @selected(old('representative_designation') === 'Executive') value="Executive">Executive </option>
                           <option @selected(old('representative_designation') === 'Manager') value="Manager">Manager</option>
                           <option @selected(old('representative_designation') === 'VP') value="VP">VP</option>
                         </select>
                       </div>
                     </div>

                   </div>

                 </div>

                 <!--end col-->
                 <div class="col-lg-12">
                   <div class="d-flex align-items-start gap-3 mt-3">
                     <button type="button" class="btn btn-primary btn-label right ms-auto nexttab"
                       data-nexttab="pills-bill-address-tab"><i
                         class="ri-arrow-right-line label-icon align-middle fs-16 ms-2"></i>
                       Save</button>
                   </div>
                 </div>
                 <!--end col-->
               </div>
             </div>
             <!-- end tab pane -->
           </div>
           <!-- end tab content -->
         </div>
         <!--end modal-body-->
       </form>
     </div>
   </div>
 </div>
