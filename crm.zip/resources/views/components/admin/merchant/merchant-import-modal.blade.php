<div class="modal fade" id="exampleModal11" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-md">
    <div class="modal-content">
      <div class="modal-header p-3">
        <h5 class="modal-title text-uppercase" id="exampleModalLabel">Upload Merchant Excel File.
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="{{ $route }}" class="checkout-tab profile-form" method="post" enctype="multipart/form-data">
        @csrf
        <!--end modal-body-->
        <div class="modal-body">
          <div class="tab-content">

            <div class="tab-pane fade show active" id="pills-finish" role="tabpanel" aria-labelledby="pills-finish-tab">
              <div class="row g-3">
                <div class="col-lg-1"></div>
                <div class="col-lg-10">
                  <label for="firstName" class="form-label mb-3">Excel Upload</label>
                  <div class="dropzone d-flex align-items-center documents_upload_tb">
                    <div class="fallback">
                      <input name="excelSheet" type="file" accept=".xls, .xlsx" onchange="fileNameShow(this)"
                        data-class=".file-name">
                    </div>
                    <div class="dz-message needsclick text-center">
                      <div class="mb-3">
                        <i class="display-4 text-muted ri-upload-cloud-2-fill"></i>
                      </div>

                      <h4 class="file-name">File upload</h4>
                    </div>
                  </div>
                </div>


                <!--end col-->
                <div class="col-lg-12">
                  <div class="d-flex align-items-start gap-3 mt-3">
                    <button type="submit" data-bs-dismiss="modal" aria-label="Close"
                      class="btn btn-primary btn-label right ms-auto nexttab" data-nexttab="pills-bill-address-tab"><i
                        class="ri-arrow-right-line label-icon align-middle fs-16 ms-2"></i>
                      Upload</button>
                  </div>
                </div>
                <!--end col-->
              </div>
            </div>
            <!-- end tab pane -->
          </div>
          <!-- end tab content -->
        </div>
        <!--end modal-body-->
      </form>
    </div>
  </div>
</div>
