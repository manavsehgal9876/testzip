<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header p-3">
        <h5 class="modal-title text-uppercase" id="exampleModalLabel">Add / Update Staff Details.
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="{{ route('admin.company-staff.store') }}" class="checkout-tab company-staff-form"
        enctype="multipart/form-data" method="post">
        @csrf
        <div class="modal-body p-0">
          <div class="step-arrow-nav">
            <ul class="nav nav-pills nav-justified custom-nav" role="tablist">
              <li class="nav-item" role="presentation">
                <button class="nav-link p-3 active" id="pills-bill-info-tab" data-bs-toggle="pill"
                  data-bs-target="#pills-bill-info" type="button" role="tab" aria-controls="pills-bill-info"
                  aria-selected="true">Basic Info</button>
              </li>
            </ul>
          </div>
        </div>
        <!--end modal-body-->
        <div class="modal-body">
          <div class="tab-content">
            <div class="tab-pane fade show active" id="pills-bill-info" role="tabpanel"
              aria-labelledby="pills-bill-info-tab">
              <div class="row g-3">
                <!--end col-->
                <div class="col-lg-4">
                  <div>
                    <label for="phoneNumber" class="form-label">Emp ID</label>
                    <input type="text" maxlength="20" class="form-control" id="phoneNumber" placeholder="Enter"
                      name="emp_id" value="{{ old('emp_id') }}">
                  </div>
                </div>

                <!--end col-->
                <div class="col-lg-4">
                  <div>
                    <label for="firstName" class="form-label">First Name</label>
                    <input type="text" class="form-control" id="firstName" placeholder="Enter" name="first_name"
                      value="{{ old('first_name') }}" maxlength="50" required>
                  </div>
                </div>
                <!--end col-->
                <div class="col-lg-4">
                  <div>
                    <label for="lastName" class="form-label">Last Name</label>
                    <input type="text" class="form-control" id="lastName" placeholder="Enter" name="last_name"
                      value="{{ old('last_name') }}" maxlength="50">
                  </div>
                </div>
                <!--end col-->
                <div class="col-lg-4">
                  <div>
                    <label for="phoneNumber" class="form-label">Email ID </label>
                    <input type="email" class="form-control" id="phoneNumber" placeholder="Enter" name="email"
                      value="{{ old('email') }}" maxlength="100" required>
                  </div>
                </div>

                <!--end col-->
                <div class="col-lg-4">
                  <div>
                    <label for="emailID" class="form-label"> Mobile No </label>
                    <input type="tel" class="form-control" id="emailID" placeholder="Enter" name="phone"
                      value="{{ old('phone') }}" title="Please use a 10 digit telephone number with no dashes or dots"
                      pattern="[0-9]{10}">
                  </div>
                </div>

                <div class="col-lg-4">
                  <div>
                    <label for="serviceTax" class="form-label">Assign Entity</label>
                    <select class="form-select assign-entity" aria-label="Default select example" name="assign_entity">
                      @foreach ($companies as $company)
                        <option @selected(old('assign_entity') == $company->id) value="{{ $company->id }}">{{ $company->name }}
                        </option>
                      @endforeach
                    </select>

                  </div>
                </div>

                <!--end col-->
                <div class="col-lg-4">
                  <div>
                    <label for="serviceTax" class="form-label"> Assign Branch office</label>
                    <select class="form-select branch" aria-label="Default select example" name="branch">
                      <option @selected(old('branch') === 'gurgaon') value="gurgaon">Gurgaon</option>
                      <option @selected(old('branch') === 'noida') value="noida">Noida</option>
                      <option @selected(old('branch') === 'delhi') value="delhi">Delhi</option>
                    </select>

                  </div>
                </div>
                <!--end col-->
                <div class="col-lg-4">
                  <div>
                    <label for="confirmPassword" class="form-label">Assign Department</label>
                    <select class="form-select departmentt" aria-label="Default select example" name="department">

                      <option @selected(old('department') === 'Merchant') value="Merchant Onboarding">Merchant Onboarding</option>
                      <option @selected(old('department') === 'Claim Settlements') value="Claim Settlements">Claim Settlements </option>
                      <option @selected(old('department') === 'Management') value="Management">Management</option>
                    </select>
                  </div>
                </div>
                <!--end col-->
                <div class="col-lg-4">
                  <div>
                    <label for="vatNo" class="form-label">Assign Designation</label>
                    <select class="form-select mb-3 designation" aria-label="Default select example"
                      name="designation">
                      <option @selected(old('designation') === 'Executive') value="Executive">Executive </option>
                      <option @selected(old('designation') === 'Manager') value="Manager">Manager</option>
                      <option @selected(old('designation') === 'Account Manager') value="Account Manager">Account Manager</option>
                    </select>
                  </div>
                </div>
                <div class="col-lg-4 mt-0">
                  <div class="mb-0">
                    <label for="ifscInput" class="form-label">Profile Photo</label>
                    <input type="file" class="form-control" name="photo"
                      accept="image/x-png,image/gif,image/jpeg, image/jpg, image/webp">
                  </div>
                </div>
                @if (Request::segment(3) !== 'create')
                  <div class="col-lg-4 mt-0">
                    <div>
                      <label for="emailID" class="form-label"> Password </label>
                      <input type="password" class="form-control" id="emailID" placeholder="Enter"
                        name="password" value="{{ old('password') }}" min="8" required maxlength="30">
                    </div>
                  </div>
                @endif

                <!--end col-->

                <!--end col-->
                <div class="col-lg-12">
                  <div class="d-flex align-items-start gap-3 mt-3">
                    <button type="submit" class="btn btn-primary btn-label right ms-auto nexttab"
                      data-nexttab="pills-bill-address-tab"><i
                        class="ri-arrow-right-line label-icon align-middle fs-16 ms-2"></i>
                      Save</button>
                  </div>
                </div>
                <!--end col-->
              </div>
              <!--end row-->
            </div>
            <!-- end tab pane -->


          </div>
          <!-- end tab content -->
        </div>
        <!--end modal-body-->
      </form>
    </div>
  </div>
</div>
