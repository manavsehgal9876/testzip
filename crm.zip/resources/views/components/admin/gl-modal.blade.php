<div class="modal fade" id="showModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" style="max-width: 802px;">
    <div class="modal-content border-0">
      <div class="modal-header bg-soft-info p-3">
        <h5 class="modal-title" id="exampleModalLabel"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" id="close-modal"></button>
      </div>
      <form action="{{ route('admin.gl-account.store') }}" class="checkout-tab gl-form" method="post"
        enctype="multipart/form-data">
        @csrf
        @method('PATCH')
        <div class="modal-body p-0">
          <div class="step-arrow-nav">
            <ul class="nav nav-pills nav-justified custom-nav" role="tablist">
              <li class="nav-item" role="presentation">
                <button class="nav-link p-3 active" id="pills-bill-info-tab" data-bs-toggle="pill"
                  data-bs-target="#pills-bill-info" type="button" role="tab" aria-controls="pills-bill-info"
                  aria-selected="true">GL Info</button>
              </li>
            </ul>
          </div>
        </div>
        <!--end modal-body-->
        <div class="modal-body">
          <div class="tab-content">
            <div class="tab-pane fade show active" id="pills-bill-info" role="tabpanel"
              aria-labelledby="pills-bill-info-tab">
              <div class="row g-3">
                <div class="col-lg-6">
                  <div>
                    <label for="glNumber" class="form-label">GL Account Number</label>
                    <input type="text" class="form-control" id="glNumber" placeholder="Enter your GL Number"
                      minlength="0" maxlength="50" name="gl_number" value="{{ old('gl_number') }}" required>
                  </div>
                </div>

                <div class="col-lg-6">
                  <div>
                    <label for="serviceTax" class="form-label"> Financial Year</label>
                    <select class="form-select financial-year" aria-label="Default select example"
                      name="financial_year">
                      <option value="">Select</option>
                      @for ($i = 2010; $i <= 2040; $i++)
                        @php
                          $newYear = substr($i, 2);
                          $newYear = ++$newYear;
                        @endphp
                        <option value="{{ $i }}-{{ $newYear }}">{{ $i }}-{{ $newYear }}
                        </option>
                      @endfor
                    </select>
                  </div>
                </div>

                <div class="col-lg-12">
                  <div>
                    <label for="glDesc" class="form-label">GL Account Description</label>
                    <input type="text" class="form-control" id="glDesc"
                      placeholder="Enter your GL Account Description" maxlength="500" name="gl_description"
                      value="{{ old('gl_description') }}">
                  </div>
                </div>
                <!--end col-->

                <div class="col-lg-12">
                  <div class="d-flex align-items-start gap-3 mt-3">
                    <button type="submit" class="btn btn-primary btn-label right ms-auto nexttab"
                      data-nexttab="pills-bill-address-tab"><i
                        class="ri-arrow-right-line label-icon align-middle fs-16 ms-2"></i>
                      Submit</button>
                  </div>
                </div>
                <!--end col-->
              </div>
              <!--end row-->
            </div>
            <!-- end tab pane -->

          </div>
          <!-- end tab content -->
        </div>
        <!--end modal-body-->
      </form>
    </div>
  </div>
</div>
