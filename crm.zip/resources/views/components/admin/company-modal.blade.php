<div class="modal fade" id="showModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" style="max-width: 802px;">
    <div class="modal-content border-0">
      <div class="modal-header bg-soft-info p-3">
        <h5 class="modal-title" id="exampleModalLabel"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" id="close-modal"></button>
      </div>
      <form action="{{ route('admin.companies.store') }}" class="checkout-tab company-form" method="post"
        enctype="multipart/form-data">
        @csrf
        <div class="modal-body p-0">
          <div class="step-arrow-nav">
            <ul class="nav nav-pills nav-justified custom-nav" role="tablist">
              <li class="nav-item" role="presentation">
                <button class="nav-link p-3 active" id="pills-bill-info-tab" data-bs-toggle="pill"
                  data-bs-target="#pills-bill-info" type="button" role="tab" aria-controls="pills-bill-info"
                  aria-selected="true">Company Info</button>
              </li>
              {{-- <li class="nav-item" role="presentation">
                <button class="nav-link p-3" id="pills-bill-address-tab" data-bs-toggle="pill"
                  data-bs-target="#pills-bill-address" type="button" role="tab"
                  aria-controls="pills-bill-address" aria-selected="false">Bank Details</button>
              </li>
              <li class="nav-item" role="presentation">
                <button class="nav-link p-3" id="pills-payment-tab" data-bs-toggle="pill"
                  data-bs-target="#pills-payment" type="button" role="tab" aria-controls="pills-payment"
                  aria-selected="false">Document Verification</button>
              </li>
              <li class="nav-item" role="presentation">
                <button class="nav-link p-3" id="pills-finish-tab" data-bs-toggle="pill"
                  data-bs-target="#pills-finish" type="button" role="tab" aria-controls="pills-finish"
                  aria-selected="false">Verified</button>
              </li> --}}
            </ul>
          </div>
        </div>
        <!--end modal-body-->
        <div class="modal-body">
          <div class="tab-content">
            <div class="tab-pane fade show active" id="pills-bill-info" role="tabpanel"
              aria-labelledby="pills-bill-info-tab">
              <div class="row g-3">
                <div class="col-lg-6">
                  <div>
                    <label for="CompanyName" class="form-label">Company Name</label>
                    <input type="text" class="form-control" id="CompanyName" placeholder="Enter your Company Name"
                      maxlength="100" name="name" value="{{ old('name') }}" required>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div>
                    <label for="phoneNumber" class="form-label">Company Email ID</label>
                    <input type="email" class="form-control" id="phoneNumber"
                      placeholder="Enter your Company Email ID" maxlength="100" name="email"
                      value="{{ old('email') }}" required>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div>
                    <label for="emailID" class="form-label">Company Mobile No </label>
                    <input type="tel" min="0" class="form-control" id="emailID"
                      placeholder="Enter your Company Mobile No" name="phone" value="{{ old('phone') }}"  title="Please use a 10 digit telephone number with no dashes or dots"
                           pattern="[0-9]{10}">
                  </div>
                </div>

                <div class="col-lg-6">
                  <div>
                    <label for="serviceTax" class="form-label"> Country</label>
                    <select class="form-select country" aria-label="Default select example" data-class=".states"
                      name="country" onchange="getStates(this)">
                      <option value="">Select</option>
                      @foreach (getCountries() as $country)
                        <option @selected(old('country') == $country->id) value="{{ $country->id }}">
                          {{ $country->name }}
                        </option>
                      @endforeach
                    </select>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div>
                    <label for="serviceTax" class="form-label"> State</label>
                    <select class="form-select states" data-class=".cities" aria-label="Default select example"
                      name="state" onchange="getCities(this)">
                      <option value="">Select</option>
                      @if (old('state') != null)
                        @foreach (getStates(old('country')) as $state)
                          <option @selected(old('state') == $state->id) value="{{ $state->id }}">
                            {{ $state->name }}
                          </option>
                        @endforeach
                      @endif
                    </select>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div>
                    <label for="serviceTax" class="form-label"> City</label>
                    <select class="form-select cities" aria-label="Default select example" name="city">
                      <option value="">Select</option>
                      @if (old('city') != null)
                        @foreach (getCities(old('state')) as $city)
                          <option @selected(old('city') == $city->id) value="{{ $city->id }}">
                            {{ $city->name }}
                          </option>
                        @endforeach
                      @endif
                    </select>
                  </div>
                </div>
                <div class="col-lg-12">
                  <div>
                    <label for="serviceTax" class="form-label"> Address</label>
                    <input type="text" class="form-control" id="serviceTax" placeholder="Enter your Address"
                      name="address" value="{{ old('address') }}" maxlength="150">

                  </div>
                </div>

                <!--end col-->

                <!--end col-->
                {{-- <div class="col-lg-6">
                  <div>
                    <label for="serviceTax" class="form-label"> Gender</label>
                    <select class="form-select mb-3" aria-label="Default select example" name="gender">
                      <option @selected(old('gender') === 'male') value="male">Male </option>
                      <option @selected(old('gender') === 'female') value="female"> Female</option>
                      <option @selected(old('gender') === 'other') value="other"> Other</option>
                    </select>
                  </div>
                </div> --}}

                <!--end col-->

                <!--end col-->
                {{-- <div class="col-lg-6">
                  <div>
                    <label for="serviceTax" class="form-label"> Date of Birth</label>
                    <input type="date" class="form-control" id="serviceTax" placeholder="Enter your Address"
                      name="dob" value="{{ old('dob') }}">
                  </div>
                </div> --}}

                <div class="col-lg-12">
                  <div>
                    <label for="serviceTax" class="form-label"> Company Logo</label>
                    <input type="file" class="form-control" id="serviceTax" placeholder="Enter your Address"
                      name="logo_image" accept=".jpg,.jpeg,.png,.gif,.webp">
                  </div>
                </div>

                <!--end col-->
                <div class="col-lg-12">
                  <div class="d-flex align-items-start gap-3 mt-3">
                    <button type="submit" class="btn btn-primary btn-label right ms-auto nexttab"
                      data-nexttab="pills-bill-address-tab"><i
                        class="ri-arrow-right-line label-icon align-middle fs-16 ms-2"></i>
                      Submit</button>
                  </div>
                </div>
                <!--end col-->
              </div>
              <!--end row-->
            </div>
            <!-- end tab pane -->

            {{-- <div class="tab-pane fade" id="pills-bill-address" role="tabpanel"
                              aria-labelledby="pills-bill-address-tab">
                              <div class="row">
                                <div class="col-lg-6">
                                  <div class="mb-3">
                                    <label for="banknameInput" class="form-label">Bank
                                      Name</label>
                                    <input type="text" class="form-control" id="banknameInput"
                                      placeholder="Enter your bank name">
                                  </div>
                                </div>
                                <!--end col-->
                                <div class="col-lg-6">
                                  <div class="mb-3">
                                    <label for="branchInput" class="form-label">Branch</label>
                                    <input type="text" class="form-control" id="branchInput" placeholder="Branch">
                                  </div>
                                </div>
                                <!--end col-->
                                <div class="col-lg-12">
                                  <div class="mb-3">
                                    <label for="accountnameInput" class="form-label">Account
                                      Holder Name</label>
                                    <input type="text" class="form-control" id="accountnameInput"
                                      placeholder="Enter account holder name">
                                  </div>
                                </div>
                                <!--end col-->
                                <div class="col-lg-6">
                                  <div class="mb-3">
                                    <label for="accountnumberInput" class="form-label">Account
                                      Number</label>
                                    <input type="number" class="form-control" id="accountnumberInput"
                                      placeholder="Enter account number">
                                  </div>
                                </div>
                                <!--end col-->
                                <div class="col-lg-6">
                                  <div class="mb-3">
                                    <label for="ifscInput" class="form-label">IFSC</label>
                                    <input type="number" class="form-control" id="ifscInput" placeholder="IFSC">
                                  </div>
                                </div>
                                <!--end col-->
                                <div class="col-lg-12">
                                  <div class="hstack align-items-start gap-3 mt-4">
                                    <button type="button" class="btn btn-light btn-label previestab"
                                      data-previous="pills-bill-info-tab"><i
                                        class="ri-arrow-left-line label-icon align-middle fs-16 me-2"></i>Back
                                      to Personal Info</button>
                                    <button type="button" class="btn btn-primary btn-label right ms-auto nexttab"
                                      data-nexttab="pills-payment-tab"><i
                                        class="ri-arrow-right-line label-icon align-middle fs-16 ms-2"></i>Next
                                      Step</button>
                                  </div>
                                </div>
                                <!--end col-->
                              </div>
                            </div>
                            <!-- end tab pane -->

                            <div class="tab-pane fade" id="pills-payment" role="tabpanel"
                              aria-labelledby="pills-payment-tab">
                              <h5 class="mb-3">Choose Document Type</h5>

                              <div class="d-flex gap-2">
                                <div>
                                  <input type="radio" class="btn-check" id="passport" checked=""
                                    name="choose-document">
                                  <label class="btn btn-outline-info" for="passport">Passport</label>
                                </div>
                                <div>
                                  <input type="radio" class="btn-check" id="aadhar-card" name="choose-document">
                                  <label class="btn btn-outline-info" for="aadhar-card">Aadhar
                                    Card</label>
                                </div>
                                <div>
                                  <input type="radio" class="btn-check" id="pan-card" name="choose-document">
                                  <label class="btn btn-outline-info" for="pan-card">Pan
                                    Card</label>
                                </div>
                                <div>
                                  <input type="radio" class="btn-check" id="Cancel-Cheque" name="choose-document">
                                  <label class="btn btn-outline-info" for="Cancel-Cheque">Cancel Cheque</label>
                                </div>
                                <div>
                                  <input type="radio" class="btn-check" id="resume" name="choose-document">
                                  <label class="btn btn-outline-info" for="resume">Resume</label>
                                </div>
                                <div>
                                  <input type="radio" class="btn-check" id="profile-photo" name="choose-document">
                                  <label class="btn btn-outline-info" for="profile-photo">Profile Photo</label>
                                </div>
                                <div>
                                  <input type="radio" class="btn-check" id="other" name="choose-document">
                                  <label class="btn btn-outline-info" for="other">Other</label>
                                </div>
                              </div>

                              <div class="dropzone d-flex align-items-center">
                                <div class="fallback">
                                  <input name="file" type="file" multiple="multiple">
                                </div>
                                <div class="dz-message needsclick text-center">
                                  <div class="mb-3">
                                    <i class="display-4 text-muted ri-upload-cloud-2-fill"></i>
                                  </div>

                                  <h4>Drop files here or click to upload.</h4>
                                </div>
                              </div>

                              <ul class="list-unstyled mb-0" id="dropzone-preview">
                                <li class="mt-2" id="dropzone-preview-list">
                                  <div class="border rounded">
                                    <div class="d-flex p-2">
                                      <div class="flex-shrink-0 me-3">
                                        <div class="avatar-sm bg-light rounded">
                                          <img src="#" alt="" data-dz-thumbnail="" class="img-fluid rounded d-block">
                                        </div>
                                      </div>
                                      <div class="flex-grow-1">
                                        <div class="pt-1">
                                          <h5 class="fs-14 mb-1" data-dz-name="">&nbsp;</h5>
                                          <p class="fs-13 text-muted mb-0" data-dz-size="">
                                          </p>
                                          <strong class="error text-danger" data-dz-errormessage=""></strong>
                                        </div>
                                      </div>
                                      <div class="flex-shrink-0 ms-3">
                                        <button data-dz-remove="" class="btn btn-sm btn-danger">Delete</button>
                                      </div>
                                    </div>
                                  </div>
                                </li>
                              </ul>
                              <!-- end dropzon-preview -->
                              <div class="d-flex align-items-start gap-3 mt-4">
                                <button type="button" class="btn btn-light btn-label previestab"
                                  data-previous="pills-bill-address-tab"><i
                                    class="ri-arrow-left-line label-icon align-middle fs-16 me-2"></i>Back
                                  to Bank Details</button>
                                <button type="button" class="btn btn-primary btn-label right ms-auto nexttab"
                                  data-nexttab="pills-finish-tab"><i
                                    class="ri-save-line label-icon align-middle fs-16 ms-2"></i>Submit</button>
                              </div>
                            </div>
                            <!-- end tab pane -->

                            <div class="tab-pane fade" id="pills-finish" role="tabpanel"
                              aria-labelledby="pills-finish-tab">
                              <div class="row text-center justify-content-center py-4">
                                <div class="col-lg-11">
                                  <!-- <div class="mb-4">
                                                                                          <lord-icon src="https://cdn.lordicon.com/lupuorrc.json"
                                                                                              trigger="loop"
                                                                                              colors="primary:#0ab39c,secondary:#405189"
                                                                                              style="width:120px;height:120px"></lord-icon>
                                                                                      </div> -->
                                  <div class="card">
                                    <div class="row g-0">
                                      <div class="col-md-2" style="display: flex; align-items: center;">
                                        <img class=" img-fluid object-cover"
                                          src="{{ asset('assets/adminAssets/images/user_icon.png') }}" alt=" Card image"
                                          style="width: 100px; height: 100px; border-radius: 50%;">
                                      </div>
                                      <div class="col-md-10">
                                        <!-- <div class="card-header">
                                                                                                      <h5 class="card-title mb-0">Give your text a good structure</h5>
                                                                                                  </div> -->
                                        <div class="card-body">
                                          <div class="row">
                                            <div class="col-12">
                                              <p>Gajendra Singh</p>
                                            </div>
                                            <div class="col-12">
                                              <p>gajendra.connect@gmail.com / g@w.com</p>
                                            </div>
                                            <div class="col-12">
                                              <p>8130352808 / 813032808 </p>
                                            </div>
                                            <div class="col-12">
                                              <p>Management / CEO </p>
                                            </div>
                                            <div class="col-12">
                                              <p>Add : H-140, Sector 7, Noida, UP, India 201301 </p>
                                            </div>
                                            <div class="col-12">
                                              <p>Male | 28 Aug 1986</p>
                                            </div>
                                          </div>



                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <h5>Verification Completed</h5>
                                  <p class="text-muted mb-4">To stay verified, don't remove the
                                    meta tag form your site's home page. To avoid losing
                                    verification, you may want to add multiple methods form the
                                    <span class="fw-medium">Crypto &gt; KYC Application.</span>
                                  </p>

                                  <div class="hstack justify-content-center gap-2">
                                    <button type="button" class="btn btn-ghost-success" data-bs-dismiss="modal">Done <i
                                        class="ri-thumb-up-fill align-bottom me-1"></i></button>
                                    <button type="button" class="btn btn-primary"><i
                                        class="ri-home-4-line align-bottom ms-1"></i> Back
                                      to Home</button>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!-- end tab pane --> --}}
          </div>
          <!-- end tab content -->
        </div>
        <!--end modal-body-->
      </form>
    </div>
  </div>
</div>
