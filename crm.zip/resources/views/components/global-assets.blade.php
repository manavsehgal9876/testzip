{{-- sweet alerts --}}
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
{{-- global js file for all users --}}
<script src="{{ asset('assets/global.js') }}"></script>
