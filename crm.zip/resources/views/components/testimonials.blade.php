<div class="single-client">
  <div class="client-bottom">
    <span class="client-author">
      <img @isset($icon) src="{{ $path }}/{{ $icon }}" @endisset
        alt="{{ $name }}">
    </span>
  </div>
  <div class="client-content">
    <span class="client-title">{{ $name }}</span>
    <p>
      {{ $content }}
    </p>
    {{-- <div class="testimonial__ratings">
        <em class="icon_star"></em>
        <em class="icon_star"></em>
        <em class="icon_star"></em>
        <em class="icon_star"></em>
        <em class="icon_star_alt"></em>
        <span><em>4.9</em> (14 Reviews)</span>
      </div> --}}
    {{-- <img class="comma" src="{{ asset('allUsers/customer/images/testimonial/coma.png') }}" alt="image"> --}}
  </div>
</div>
