<div class="single-studies col-lg-12 grid-item plan__care_course">
  <div class="inner-course">
    <div class="case-img" style="height:  @if ($progressBar) 310px @else 290px @endif;width: 100%;">
      <img @isset($thumbnail) src="{{ $path }}/{{ $thumbnail }}" @endisset
        alt="{{ $title }}" style="height: 100%;width: 100%;object-fit: cover;">
    </div>
    <div class="case-content" @if ($progressBar) style="padding: 30px 20px 20px 20px;" @endif>
      <h4 class="case-title"> <a href="{{ route('care-plan-detail', $slug) }}">{{ $title }}</a>
      </h4>
      <p>
        {{ $shortDesc }}
      </p>
      <div class="react__user">
        <img src="{{ asset('allUsers/user/images/avatar/user_img1.png') }}" alt="{{ $title }}">
        {{ env('APP_NAME') }}
      </div>
      <ul class="react-ratings ">
        <li><i data-feather="star"></i> 4.5 review </li>
        <li><i data-feather="eye"></i> {{ $viewCount }} Views </li>
        <li class="price">{{ $fees === 'Free' ? $fees : "₹{$fees}" }}</li>
      </ul>
      @if ($progressBar)
        <div class="progress" style="margin-bottom:0">
          <div class="progress-bar bg-warning progress-bar-striped progress-bar-animated" role="progressbar"
            style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
      @endif
    </div>
  </div>
</div>
