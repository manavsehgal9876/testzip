@component('mail::message')
  # Hi, this is to notify you that the claim with the claim ID: <i>{{ $data->claim_id }}</i> has been resubmitted by the merchant.

  Please click on the button below to login

  @component('mail::button', ['url' => route('adminStaff.login'), 'color' => 'primary'])
    Login
  @endcomponent

  Thanks,<br>
  {{ config('app.name') }}
@endcomponent
