@component('mail::message')
  # Hello, your account ({{ $data['staff']->email }}) have been registered as a merchant.

  You can find the details below.

  @component('mail::panel')
    Merchant Name: {{ $data['merchant']->company_name }} <br />
    Merchant Tan Number: {{ $data['merchant']->tan_number }}
  @endcomponent

  You can use your email & password to login into your merchant panel from <a target="_blank"
    href="{{ route('login') }}">here</a>.

  Also if in case you don't remember the password can request to reset your password <a target="_blank"
    href="{{ route('password-reset-request') }}">here</a>.

  Or you can reset it by yourself from <a target="_blank" href="{{ route('forgot-password') }}">here</a>

  Thanks,<br>
  {{ config('app.name') }}
@endcomponent
