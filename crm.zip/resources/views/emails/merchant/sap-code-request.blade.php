@component('mail::message')
  <style type="text/css">
    tr:nth-child(even) {
      background-color: #f2f2f2;
    }
  </style>
  # Hello
  {{ $data['body'] }}

  <hr />
  <div style="overflow-x:auto;">
    <table style="width:100%; margin: 20px 0px 20px 0px;font-size: smaller;">
      <thead>
        <tr style="text-align: left;">
          <th style="width: 150px!important;color: black;border-radius: 6px;padding: 5px;">Merchant Name</th>
          <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['merchant']->company_name }}</td>
        </tr>
        <tr style="text-align: left;">
          <th style="width: 150px!important;color: black;border-radius: 6px;padding: 5px;">Tan Number</th>
          <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['merchant']->tan_number }}</td>
        </tr>
        <tr style="text-align: left;">
          <th style="width: 150px!important;color: black;border-radius: 6px;padding: 5px;">SAP Code</th>
          <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['merchant']->sap_code }}</td>
        </tr>
        <tr style="text-align: left;">
          <th style="width: 150px!important;color: black;border-radius: 6px;padding: 5px;">Merchant Address</th>
          <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['merchant']->address }}</td>
        </tr>
        <tr style="text-align: left;">
          <th style="width: 150px!important;color: black;border-radius: 6px;padding: 5px;">City</th>
          <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['merchant']?->myCity?->name }}</td>
        </tr>
        <tr style="text-align: left;">
          <th style="width: 150px!important;color: black;border-radius: 6px;padding: 5px;">State</th>
          <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['merchant']->myState?->name }}</td>
        </tr>
        <tr style="text-align: left;">
          <th style="width: 150px!important;color: black;border-radius: 6px;padding: 5px;">Country</th>
          <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['merchant']->myCountry?->name }}</td>
        </tr>
        <tr style="text-align: left;">
          <th style="width: 150px!important;color: black;border-radius: 6px;padding: 5px;">Phone</th>
          <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['merchant']->phone }}</td>
        </tr>
        <tr style="text-align: left;">
          <th style="width: 150px!important;color: black;border-radius: 6px;padding: 5px;">Email ID</th>
          <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['merchant']->website }}</td>
        </tr>
        <tr style="text-align: left;">
          <th style="width: 150px!important;color: black;border-radius: 6px;padding: 5px;">GST</th>
          <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['merchant']->gst_number }}</td>
        </tr>
        <tr style="text-align: left;">
          <th style="width: 150px!important;color: black;border-radius: 6px;padding: 5px;">PAN</th>
          <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['merchant']->pancard_number }}</td>
        </tr>
        <tr style="text-align: left;">
          <th style="width: 150px!important;color: black;border-radius: 6px;padding: 5px;">IFSC Code</th>
          <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['merchant']->activeBankAccount?->ifsc }}
          </td>
        </tr>
        <tr style="text-align: left;">
          <th style="width: 150px!important;color: black;border-radius: 6px;padding: 5px;">Bank Account No</th>
          <td style="color: #231F20;border-radius: 6px;padding: 5px;">
            {{ $data['merchant']->activeBankAccount?->account_number }}</td>
        </tr>
        <tr style="text-align: left;">
          <th style="width: 150px!important;color: black;border-radius: 6px;padding: 5px;">A/c Holder Name</th>
          <td style="color: #231F20;border-radius: 6px;padding: 5px;">
            {{ $data['merchant']->activeBankAccount?->acc_holder_name }}</td>
        </tr>
        <tr style="text-align: left;">
          <th style="width: 150px!important;color: black;border-radius: 6px;padding: 5px;">Minority Indication</th>
          <td style="color: #231F20;border-radius: 6px;padding: 5px;">NA</td>
        </tr>
        <tr style="text-align: left;">
          <th style="width: 150px!important;color: black;border-radius: 6px;padding: 5px;">Payment Term</th>
          <td style="color: #231F20;border-radius: 6px;padding: 5px;">Z000</td>
        </tr>
        <tr style="text-align: left;">
          <th style="width: 150px!important;color: black;border-radius: 6px;padding: 5px;">WHT Type</th>
          <td style="color: #231F20;border-radius: 6px;padding: 5px;">W4</td>
        </tr>
        <tr style="text-align: left;">
          <th style="width: 150px!important;color: black;border-radius: 6px;padding: 5px;">WHT Code</th>
          <td style="color: #231F20;border-radius: 6px;padding: 5px;">WK</td>
        </tr>
        <tr style="text-align: left;">
          <th style="width: 150px!important;color: black;border-radius: 6px;padding: 5px;">Liable</th>
          <td style="color: #231F20;border-radius: 6px;padding: 5px;">Untick</td>
        </tr>
      </thead>
    </table>
  </div>
  <hr />

  Thanks,<br>
  {{ config('app.name') }}
@endcomponent
