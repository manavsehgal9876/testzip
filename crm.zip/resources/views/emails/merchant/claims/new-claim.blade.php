@component('mail::message')
  # Hello, this is to notify you that a new claim has been added by merchant ({{ $data['merchant']->company_name }}).

  Claim ID: {{ $data['claim']->claim_id }}

  Click on the button below to view the claims.

  @component('mail::button', ['url' => route('admin.claim.index')])
    View claims
  @endcomponent

  Thanks,<br>
  {{ config('app.name') }}
@endcomponent
