@component('mail::message')
  # Hello

  {{ $data['title'] }}

  @component('mail::panel')
    {{ $data['body'] }}
  @endcomponent

  Thanks,<br>
  {{ config('app.name') }}
@endcomponent
