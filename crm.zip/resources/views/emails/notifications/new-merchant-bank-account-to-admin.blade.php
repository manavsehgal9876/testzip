@component('mail::message')
  # New notification

  {{ $data['message'] }}

  @component('mail::panel')
    <p><span> Merchant Name </span>:<span> {{ $data['merchantDetails']->company_name }} </span></p>
    <p>Merchant Tan Number: {{ $data['merchantDetails']->tan_number }}</p>
  @endcomponent

  @component('mail::panel')
    Click the button below to view the merchants.
  @endcomponent

  @component('mail::button', ['url' => route('adminStaff.merchants.index'), 'color' => 'primary'])
    View Merchants
  @endcomponent

  Thanks,<br>
  {{ config('app.name') }}
@endcomponent
