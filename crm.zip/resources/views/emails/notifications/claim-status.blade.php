@component('mail::message')
  <style type="text/css">
    tr:nth-child(even) {
      background-color: #f2f2f2;
    }
  </style>
  # Hello your claim ({{ $data['history']->claim->claim_id }}) status has been changed to "{{ $data['history']->claimStatus }}"

  <hr />
  <div style="overflow-x:auto;">
    <table style="width:100%; margin: 20px 0px 20px 0px;font-size: smaller;">
      @switch($data['history']->status)
        @case(3)
          <thead>
            <tr style="text-align: left;">
              <th style="width: 180px!important;color: black;border-radius: 6px;padding: 5px;">Claim ID</th>
              <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['history']->claim->claim_id }}</td>
            </tr>
            <tr style="text-align: left;">
              <th style="width: 180px!important;color: black;border-radius: 6px;padding: 5px;">Merchant</th>
              <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['history']->claim->merchant_company_name }}
              </td>
            </tr>
            <tr style="text-align: left;">
              <th style="width: 180px!important;color: black;border-radius: 6px;padding: 5px;">Remark</th>
              <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['history']->remark }}</td>
            </tr>
            <tr style="text-align: left;">
              <th style="width: 180px!important;color: black;border-radius: 6px;padding: 5px;">By</th>
              <td style="color: #231F20;border-radius: 6px;padding: 5px;">
                {{ isset($data['history']->updatedBy->company_name) ? $data['history']->updatedBy->company_name : $data['history']->updatedBy->full_name }}
                ({{ Str::ucfirst($data['history']->updatedBy->type) }}) </td>
            </tr>
            <tr style="text-align: left;">
              <th style="width: 180px!important;color: black;border-radius: 6px;padding: 5px;">Attachment</th>
              <td style="color: #231F20;border-radius: 6px;padding: 5px;">
                @if ($data['history']->attachment && Storage::disk('appFiles')->exists("claim/{$data['history']->attachment}"))
                  <a href="{{ asset('crm/public/uploads/claim') . '/' . $data['history']->attachment }}"
                    target="_blank">Download
                  </a>
                @else
                  N/A
                @endif
              </td>
            </tr>
          @break

          @case(4)
            <tr style="text-align: left;">
              <th style="width: 180px!important;color: black;border-radius: 6px;padding: 5px;">Claim ID</th>
              <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['history']->claim->claim_id }}</td>
            </tr>
            <tr style="text-align: left;">
              <th style="width: 180px!important;color: black;border-radius: 6px;padding: 5px;">Merchant</th>
              <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['history']->claim->merchant_company_name }}
              </td>
            </tr>
            <tr style="text-align: left;">
              <th style="width: 180px!important;color: black;border-radius: 6px;padding: 5px;">SAP Document No. :</th>
              <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['history']->claim->sap_payment_doc_no }}
              </td>
            </tr>
            <tr style="text-align: left;">
              <th style="width: 180px!important;color: black;border-radius: 6px;padding: 5px;">UTR Number :</th>
              <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['history']->claim->utr }}</td>
            </tr>
            <tr style="text-align: left;">
              <th style="width: 180px!important;color: black;border-radius: 6px;padding: 5px;">Payment Date :</th>
              <td style="color: #231F20;border-radius: 6px;padding: 5px;">
                {{ $data['history']->claim->payment_date?->format('d M, Y') }}</td>
            </tr>
            <tr style="text-align: left;">
              <th style="width: 180px!important;color: black;border-radius: 6px;padding: 5px;">Certificate No :</th>
              <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['history']->claim->certificate_no }}</td>
            </tr>
            <tr style="text-align: left;">
              <th style="width: 180px!important;color: black;border-radius: 6px;padding: 5px;">Last Update :</th>
              <td style="color: #231F20;border-radius: 6px;padding: 5px;">
                {{ isset($data['history']->claim->last_updated_on) ? $data['history']->claim->last_updated_on->format('d M, Y') : 'N/A' }}
              </td>
            </tr>
            <tr style="text-align: left;">
              <th style="width: 180px!important;color: black;border-radius: 6px;padding: 5px;">TDS Section :</th>
              <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['history']->claim->nature_of_tds }}</td>
            </tr>
            <tr style="text-align: left;">
              <th style="width: 180px!important;color: black;border-radius: 6px;padding: 5px;">KAM Email :</th>
              <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['history']->updatedBy->email }}</td>
            </tr>
            <tr style="text-align: left;">
              <th style="width: 180px!important;color: black;border-radius: 6px;padding: 5px;">Merchant Email :</th>
              <td style="color: #231F20;border-radius: 6px;padding: 5px;">
                {{ $data['history']->claim->merchant->primaryStaff?->email }}</td>
            </tr>
            <tr style="text-align: left;">
              <th style="width: 180px!important;color: black;border-radius: 6px;padding: 5px;">Remark</th>
              <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['history']->remark }}</td>
            </tr>
            <tr style="text-align: left;">
              <th style="width: 180px!important;color: black;border-radius: 6px;padding: 5px;">Attachment</th>
              <td style="color: #231F20;border-radius: 6px;padding: 5px;">
                @if ($data['history']->attachment && Storage::disk('appFiles')->exists("claim/{$data['history']->attachment}"))
                  <a href="{{ asset('crm/public/uploads/claim') . '/' . $data['history']->attachment }}"
                    target="_blank">Download
                  </a>
                @else
                  N/A
                @endif
              </td>
            </tr>
          @break

          @case(5)
            <tr style="text-align: left;">
              <th style="width: 180px!important;color: black;border-radius: 6px;padding: 5px;">Claim ID</th>
              <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['history']->claim->claim_id }}</td>
            </tr>
            <tr style="text-align: left;">
              <th style="width: 180px!important;color: black;border-radius: 6px;padding: 5px;">Merchant</th>
              <td style="color: #231F20;border-radius: 6px;padding: 5px;">
                {{ $data['history']->claim->merchant_company_name }}
              </td>
            </tr>
            <tr style="text-align: left;">
              <th style="width: 180px!important;color: black;border-radius: 6px;padding: 5px;">Remark</th>
              <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ $data['history']->remark }}</td>
            </tr>
            <tr style="text-align: left;">
              <th style="width: 180px!important;color: black;border-radius: 6px;padding: 5px;">By</th>
              <td style="color: #231F20;border-radius: 6px;padding: 5px;">{{ isset($data['history']->updatedBy->company_name) ? $data['history']->updatedBy->company_name : $data['history']->updatedBy->full_name }} ({{ Str::ucfirst($data['history']->updatedBy->type) }}) </td>
            </tr>
            <tr style="text-align: left;">
              <th style="width: 180px!important;color: black;border-radius: 6px;padding: 5px;">Attachment</th>
              <td style="color: #231F20;border-radius: 6px;padding: 5px;">
                @if ($data['history']->attachment && Storage::disk('appFiles')->exists("claim/{$data['history']->attachment}"))
                  <a href="{{ asset('crm/public/uploads/claim') . '/' . $data['history']->attachment }}"
                    target="_blank">Download
                  </a>
                @else
                  N/A
                @endif
              </td>
            </tr>
          </thead>
        @break
      @endswitch
    </table>
  </div>
  <hr />

  Thanks,<br>
  {{ config('app.name') }}
@endcomponent
