@component('mail::message')
  # Hello there

  This mail contains your settlement report please download it from attachment.

  Thanks,<br>
  {{ config('app.name') }}
@endcomponent
