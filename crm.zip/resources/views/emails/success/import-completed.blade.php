@component('mail::message')
  # Hi

  {{ $data['message'] }}

  Thanks,<br>
  {{ config('app.name') }}
@endcomponent
