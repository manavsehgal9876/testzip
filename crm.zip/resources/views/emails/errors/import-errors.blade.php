@component('mail::message')
  # Errors on import of "{{ $data['errorSheet'] }}"

  @component('mail::panel')
    @foreach ($data['errors'] as $error)
      Row {{ $error['row'] }}: {{ $error['error'] }} <br />
    @endforeach
  @endcomponent


  Thanks,<br>
  {{ config('app.name') }}
@endcomponent
