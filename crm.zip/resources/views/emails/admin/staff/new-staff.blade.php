@component('mail::message')
  # Hi "{{ $data['staff']->fullName }}" we have a notification for you.

  Your details for the company staff account has been added by the admin.

  Your new details are as follows:

  @component('mail::panel')
    <p><span> EMP-ID </span>:<span> {{ $data['staff']->emp_id }} </span></p>
    <p><span> First Name </span>:<span> {{ $data['staff']->first_name }} </span></p>
    <p><span> Last Name </span>:<span> {{ $data['staff']->last_name }} </span></p>
    <p><span> Email </span>:<span> {{ $data['staff']->email }} </span></p>
    <p><span> Password </span>:<span> {{ $data['password'] }} </span></p>
    <p><span> Phone </span>:<span> {{ $data['staff']->phone }} </span></p>
    <p><span> Department </span>:<span> {{ $data['staff']->department }} </span></p>
    <p><span> Designation </span>:<span> {{ $data['staff']->designation }} </span></p>
    <p><span> Branch </span>:<span> {{ $data['staff']->branch }} </span></p>
  @endcomponent

  @component('mail::button', ['url' => route('adminStaff.login'), 'color' => 'primary'])
    Login
  @endcomponent

  Thanks,<br>
  {{ config('app.name') }}
@endcomponent
