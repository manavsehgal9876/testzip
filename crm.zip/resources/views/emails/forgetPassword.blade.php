@component('mail::message')
  # Hello
  You are receiving this email because we received a password reset request for

  @component('mail::panel')
    Name: {{ $data['merchantCompanyName'] }}<br />
    Tan Number: {{ $data['merchantTan'] }}
  @endcomponent

  @component('mail::button',
      [
          'url' => route('password.reset', [
              'token' => $data['token'],
              'staffEmail' => $data['staffEmail'],
              'merchantTan' => $data['merchantTan'],
          ]),
      ])
    Reset password
  @endcomponent
  This password reset link will expire in 60 minutes.

  If you did not request a password reset, no further action is required.

  Regards,<br>
  {{ config('app.name') }}

  <hr />
  <small>
    If you're having trouble clicking the "Reset Password" button, copy and paste the URL below into your web browser:
    <span> <a
        href="{{ route('password.reset', ['token' => $data['token'], 'staffEmail' => $data['staffEmail'], 'merchantTan' => $data['merchantTan']]) }}">{{ route('password.reset', ['token' => $data['token'], 'staffEmail' => $data['staffEmail'], 'merchantTan' => $data['merchantTan']]) }}</a></span>
  </small>
@endcomponent
