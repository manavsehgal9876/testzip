<x-mail::message>
  # Hello

  Merchant '{{ $data['merchant']->company_name }}' (TAN: {{ $data['merchant']->tan_number }}) has enabled his old bank account. The bank account has been sent for approval to staff.

  <x-mail::button :url="route('adminStaff.modified-bank-detail-report')">
    Click here to view 
  </x-mail::button>

  Thanks,<br>
  {{ config('app.name') }}
</x-mail::message>
