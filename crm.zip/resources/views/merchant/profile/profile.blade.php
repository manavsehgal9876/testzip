@extends('merchant.header')
@section('merchantContent')
  <!-- Vertical Overlay-->
  <div class="page-content">

    <!-- start page title -->

    <!-- end page title -->
    <div class="container-fluid">
      <div class="team-list row list-view-filter">

        <div class="col-lg-12">
          <h5 class="mt-3">Merchant Company Detail</h5>
          <div class="card team-box">
            <div class="card-body">
              <div>
                <div class="table-responsive table-card border_lin0">
                  <table class="table align-middle mb-0 pb-0" id="customerTable">

                    <tbody class="list form-check-all">

                      <tr>
                        <th scope="row">
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="chk_child" value="option1">
                          </div>
                        </th>
                        <td>
                          <div class="team-profile-img">
                            <div class="avatar-lg img-thumbnail rounded-circle flex-shrink-0">
                              <img
                                src="@if ($merchant->logo && Storage::disk('appFiles')->exists("merchant/{$merchant->logo}")) {{ asset('crm/public/uploads/merchant') . '/' . $merchant->logo }} @endif"
                                alt="" class="img-fluid h-100 w-100 d-block rounded-circle">
                            </div>
                            <div class="team-content">
                              <a href="javascript:;" aria-controls="offcanvasExample">
                                <h5 class="fs-16 mb-1">{{ $merchant->company_name }} </h5>
                              </a>
                              <p class="text-muted mb-0">TAN: {{ $merchant->tan_number }} </p>

                              <p class="text-muted mb-0" style="color: #2d4187 !important;">SAP Code:
                                {{ $merchant->sap_code }}</p>
                              <p class="text-muted mb-0">{{ $merchant->email }}</p>
                              <p class="text-muted mb-0">{{ $merchant->phone }}</p>
                              <p class="text-muted mb-0">{{ $merchant->website }}</p>
                            </div>
                          </div>
                        </td>
                        <td class="name">
                          <a href="javascript:;" aria-controls="offcanvasExample">
                            <h5 class="fs-16 mb-1">Address</h5>
                          </a>
                          <p class="text-muted mb-0">{{ @$merchant->myCountry->name }}</p>
                          <p class="text-muted mb-0">{{ @$merchant->myState->name }}</p>
                          <p class="text-muted mb-0">{{ @$merchant->myCity->name }}</p>
                          <p class="text-muted mb-0">{{ @$merchant->address }}</p>
                        </td>
                        <td class="name">
                          <a href="javascript:;" aria-controls="offcanvasExample">
                            <h5 class="fs-16 mb-1">Documents </h5>
                          </a>


                          <div class="row">
                            <div class="col-5 ">
                              <p class="text-muted mb-0">Pancard:</p>
                            </div>
                            <div class="col-7 ">
                              <a
                                @if ($merchant->pan_document && Storage::disk('appFiles')->exists("merchant/{$merchant->pan_document}")) href="{{ asset('crm/public/uploads/merchant') . '/' . $merchant->pan_document }}" target="_blank" @endif>
                                <p>
                                  <lord-icon src="https://cdn.lordicon.com/xhdhjyqy.json" trigger="loop"
                                    style="width:16px;height:16px">
                                  </lord-icon>
                                </p>
                              </a>
                            </div>
                            <div class="col-5 ">
                              <p class="text-muted mb-0">Tan:</p>
                            </div>
                            <div class="col-7 ">
                              <a
                                @if ($merchant->tan_document && Storage::disk('appFiles')->exists("merchant/{$merchant->tan_document}")) href="{{ asset('crm/public/uploads/merchant') . '/' . $merchant->tan_document }}" target="_blank" @endif>
                                <p>
                                  <lord-icon src="https://cdn.lordicon.com/xhdhjyqy.json" trigger="loop"
                                    style="width:16px;height:16px">
                                  </lord-icon>
                                </p>
                              </a>
                            </div>
                            <div class="col-5">
                              <p class="text-muted mb-0">Gst:</p>
                            </div>
                            <div class="col-7">
                              <a
                                @if ($merchant->gst_document && Storage::disk('appFiles')->exists("merchant/{$merchant->gst_document}")) href="{{ asset('crm/public/uploads/merchant') . '/' . $merchant->gst_document }}" target="_blank" @endif>
                                <p>
                                  <lord-icon src="https://cdn.lordicon.com/xhdhjyqy.json" trigger="loop"
                                    style="width:16px;height:16px">
                                  </lord-icon>
                                </p>
                              </a>
                            </div>
                          </div>

                        </td>
                        <td class="name" align="center">
                          <h5 class="mb-1">{{ auth()->user()->ClaimsCount }}</h5>
                          <p class="text-muted mb-0">Claims Posted</p>
                        </td>
                        <td align="center">
                          <h5 class="mb-1">{{ auth()->user()->ClosedClaimsCount }}</h5>
                          <p class="text-muted mb-0">Closed claims</p>
                        </td>

                        <td>
                          <ul class="list-inline hstack gap-2 mb-0">
                            {{-- <li class="list-inline-item edit" data-bs-toggle="tooltip" data-bs-trigger="hover"
                              data-bs-placement="top" title="Enable">
                              <a href="javascript:void(0);" class="text-muted d-inline-block">
                                <i class="ri-check-fill fs-16" style="color:green;font-weight: bold;"></i>
                              </a>
                            </li> --}}

                            <li class="list-inline-item">
                              <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#exampleModal"><i
                                  class="ri-eye-fill align-bottom text-muted"></i></a>
                            </li>
                            <li class="list-inline-item">

                              <a class="edit-item-btn" href="javascript:void(0)" data-bs-toggle="modal"
                                data-bs-target="#exampleModal"><i class="ri-pencil-fill align-bottom text-muted"></i></a>
                            </li>


                          </ul>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
          <p style="color:red">Note : Click on pencil icon to update the merchant company information </p>

        </div>
      </div>

      <svg class="bookmark-hide">
        <symbol viewBox="0 0 24 24" stroke="currentColor" fill="var(--color-svg)" id="icon-star">
          <path stroke-width=".4"
            d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z">
          </path>
        </symbol>
      </svg>
      <x-merchant.merchant-profile-modal :merchant="$merchant" />
      <!--end modal-->
    </div><!-- container-fluid -->
  </div><!-- End Page-content -->
  <!--end offcanvas-->
@endsection
