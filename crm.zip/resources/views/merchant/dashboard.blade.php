@extends('merchant.header')
@section('merchantContent')
  <div class="page-content">
    <div class="container-fluid">

      <!-- start page title -->
      <div class="row">
        <div class="col-12">
          <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Merchant Dashboard</h4>
            <a href="{{ asset('assets/PayUMerchantPanel-SOP.pdf') }}" target="_blank" class="align-items-center btn btn-success btn-rounded d-flex w-auto">
              Click here too see how it works <i class="mx-1 ri-send-plane-2-line ri-lg"></i>
            </a>
          </div>
        </div>
      </div>
      <!-- end page title -->

      <div class="row">
        <div class="col-xxl-7">
          <div class="d-flex flex-column">
            <div class="row h-100">
              <div class="col-12">
                <div class="card">
                  <div class="card-body p-0">
                    <div class="alert alert-warning border-0 rounded-0 m-0 d-flex align-items-center" role="alert">
                      <i data-feather="alert-triangle" class="text-warning me-2 icon-sm"></i>
                      <div class="flex-grow-1 text-truncate">
                        Hello {{ auth()->user()->company_name }}
                      </div>
                      <div class="flex-shrink-0">
                        <a href="javascript:;" class="text-reset text-decoration-underline">Last Login on :
                          {{ $lastLogin?->created_at?->format('d M, Y h:i a') }}
                        </a>
                      </div>
                    </div>

                    <div class="row align-items-end">
                      <div class="col-sm-8">
                        <div class="p-3">
                          <p class="fs-16 lh-base">This is your claim management portal with Payu. <i
                              class="mdi mdi-arrow-right"></i></p>
                          <div class="mt-3">
                            <a href="{{ route('merchant.logout') }}" class="btn btn-success">Logout</a>
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="px-3">
                          {{-- <img
                            src="@if (auth()->user()->logo && Storage::disk('appFiles')->exists('merchant' . '/' . auth()->user()->logo)) {{ asset('crm/public/uploads/merchant') . '/' . auth()->user()->logo }} @else {{ asset('assets/merchantAssets/images/users/avatar-1.jpg') }} @endif"
                            class="img-fluid" alt="" style="width: 100px;float: right;"> --}}
                        </div>
                      </div>
                    </div>
                  </div> <!-- end card-body-->
                </div>
              </div> <!-- end col-->
            </div> <!-- end row-->

            <div class="row">
              <div class="col-md-3">
                <div class="card card-animate">
                  <a href="{{ route('merchant.claim.index', ['status' => 4]) }}">
                    <div class="card-body">
                      <div class="d-flex justify-content-between">
                        <div>
                          <p class="fw-medium text-muted mb-0">Completed Claims</p>
                          <h2 class="mt-4 ff-secondary fw-semibold">
                            <span class="counter-value" data-target="{{ auth()->user()->ClosedClaimsCount }}">
                              {{ auth()->user()->ClosedClaimsCount }}
                            </span>
                          </h2>

                        </div>
                        <div>
                          <div class="avatar-sm flex-shrink-0">
                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                              <i data-feather="users" class="text-info"></i>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div><!-- end card body -->
                  </a>
                </div> <!-- end card-->
              </div> <!-- end col-->

              <div class="col-md-3">
                <div class="card card-animate">
                  <a href="{{ route('merchant.claim.index', ['status' => 2]) }}">
                    <div class="card-body">
                      <div class="d-flex justify-content-between">
                        <div>
                          <p class="fw-medium text-muted mb-0">In Process Claims </p>
                          <h2 class="mt-4 ff-secondary fw-semibold">
                            <span class="counter-value" data-target="{{ auth()->user()->InProcessClaimsCount }}">
                              {{ auth()->user()->InProcessClaimsCount }}
                            </span>
                          </h2>

                        </div>
                        <div>
                          <div class="avatar-sm flex-shrink-0">
                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                              <i data-feather="activity" class="text-info"></i>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div><!-- end card body -->
                  </a>
                </div>
              </div> <!-- end card-->

              <div class="col-md-3">
                <div class="card card-animate">
                  <a href="{{ route('merchant.claim.index', ['status' => 3]) }}">
                    <div class="card-body">
                      <div class="d-flex justify-content-between">
                        <div>
                          <p class="fw-medium text-muted mb-0">Approved Claims</p>
                          <h2 class="mt-4 ff-secondary fw-semibold">
                            <span class="counter-value" data-target="{{ auth()->user()->ApprovedClaimsCount }}">
                              {{ auth()->user()->ApprovedClaimsCount }}
                            </span>
                          </h2>

                        </div>
                        <div>
                          <div class="avatar-sm flex-shrink-0">
                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                              <i data-feather="clock" class="text-info"></i>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div><!-- end card body -->
                  </a>
                </div> <!-- end card-->
              </div> <!-- end col-->

              <div class="col-md-3">
                <div class="card card-animate">
                  <a href="{{ route('merchant.claim.index', ['status' => 6]) }}">
                    <div class="card-body">
                      <div class="d-flex justify-content-between">
                        <div>
                          <p class="fw-medium text-muted mb-0">On Hold Claims</p>
                          <h2 class="mt-4 ff-secondary fw-semibold">
                            <span class="counter-value" data-target="{{ auth()->user()->OnHoldClaimsCount }}">
                              {{ auth()->user()->OnHoldClaimsCount }}
                            </span>
                          </h2>

                        </div>
                        <div>
                          <div class="avatar-sm flex-shrink-0">
                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                              <i data-feather="clock" class="text-info"></i>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div><!-- end card body -->
                  </a>
                </div> <!-- end card-->
              </div> <!-- end col-->

              <div class="col-md-3">
                <div class="card card-animate">
                  <a href="{{ route('merchant.claim.index', ['status' => 1]) }}">
                    <div class="card-body">
                      <div class="d-flex justify-content-between">
                        <div>
                          <p class="fw-medium text-muted mb-0">Submitted Claims</p>
                          <h2 class="mt-4 ff-secondary fw-semibold">
                            <span class="counter-value" data-target="{{ auth()->user()->PendingClaimsCount }}">
                              {{ auth()->user()->PendingClaimsCount }}
                            </span>
                          </h2>
                        </div>
                        <div>
                          <div class="avatar-sm flex-shrink-0">
                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                              <i data-feather="external-link" class="text-info"></i>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div><!-- end card body -->
                  </a>
                </div> <!-- end card-->
              </div> <!-- end col-->

              <div class="col-md-3">
                <div class="card card-animate">
                  <a href="{{ route('merchant.claim.index', ['status' => 0]) }}">
                    <div class="card-body">
                      <div class="d-flex justify-content-between">
                        <div>
                          <p class="fw-medium text-muted mb-0">Drafted Claims</p>
                          <h2 class="mt-4 ff-secondary fw-semibold">
                            <span class="counter-value" data-target="{{ auth()->user()->DraftedClaimsCount }}">
                              {{ auth()->user()->DraftedClaimsCount }}
                            </span>
                          </h2>

                        </div>
                        <div>
                          <div class="avatar-sm flex-shrink-0">
                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                              <i data-feather="clock" class="text-info"></i>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div><!-- end card body -->
                  </a>
                </div> <!-- end card-->
              </div> <!-- end col-->

              <div class="col-md-3">
                <div class="card card-animate">
                  <a href="{{ route('merchant.claim.index', ['status' => 5]) }}">
                    <div class="card-body">
                      <div class="d-flex justify-content-between">
                        <div>
                          <p class="fw-medium text-muted mb-0">Rejected Claims</p>
                          <h2 class="mt-4 ff-secondary fw-semibold">
                            <span class="counter-value" data-target="{{ auth()->user()->RejectedClaimsCount }}">
                              {{ auth()->user()->RejectedClaimsCount }}
                            </span>
                          </h2>

                        </div>
                        <div>
                          <div class="avatar-sm flex-shrink-0">
                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                              <i data-feather="clock" class="text-info"></i>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div><!-- end card body -->
                  </a>
                </div> <!-- end card-->
              </div> <!-- end col-->

              <div class="col-md-3">
                <div class="card card-animate">
                  <a href="{{ route('merchant.claim.index') }}">
                    <div class="card-body">
                      <div class="d-flex justify-content-between">
                        <div>
                          <p class="fw-medium text-muted mb-0">Total Claims</p>
                          <h2 class="mt-4 ff-secondary fw-semibold">
                            <span class="counter-value" data-target="{{ auth()->user()->ClaimsCount }}">
                              {{ auth()->user()->ClaimsCount }}
                            </span>
                          </h2>
                        </div>
                        <div>
                          <div class="avatar-sm flex-shrink-0">
                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                              <i data-feather="external-link" class="text-info"></i>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div><!-- end card body -->
                  </a>
                </div> <!-- end card-->
              </div> <!-- end col-->
            </div> <!-- end row-->
          </div>
        </div> <!-- end col-->

        <div class="col-xxl-5">
          <div class="card card-height-100">
            <div class="card-header align-items-center d-flex">
              <h4 class="card-title mb-0 flex-grow-1"> Notifications </h4>

            </div><!-- end card header -->

            <div class="card-body p-0">

              <div class="align-items-center p-3 justify-content-between d-flex">
                <div class="flex-shrink-0">
                  {{-- <div class="text-muted"><span class="fw-semibold">4</span> of <span class="fw-semibold">10</span>
                    remaining</div> --}}
                </div>

              </div><!-- end card header -->

              <div data-simplebar style="max-height: 350px;">
                <ul class="list-group list-group-flush border-dashed px-3">

                  @forelse ($claimHistory as $history)
                    <x-claim-history-list :history="$history" :viewLink="route('merchant.claim.show', Crypt::encryptString($history->claim->id))" />
                  @empty
                    <li class="list-group-item ps-0">
                      <div class="d-flex align-items-start">
                        <div class="flex-grow-1 text-center">
                          <label class="form-check-label mb-0 ps-2" for="task_one">No Claim History</label>
                        </div>
                      </div>
                    </li>
                  @endforelse

                </ul><!-- end ul -->
              </div>
              <div class="p-3">
                <a href="{{ route('merchant.claim-notifications') }}" class="btn btn-sm btn-success"> View All</a>
              </div>
            </div><!-- end card body -->
          </div><!-- end card -->
        </div><!-- end col -->
      </div> <!-- end row-->
    </div>
    <!-- container-fluid -->
  </div>
  <!-- End Page-content -->
  @if (Auth::user()->created_at->diffInDays(now()) <= 30)
    <x-merchant.merchant-tutorial-modal />
  @endif
@endsection
