@extends('merchant.header')
@section('merchantContent')
  <div class="page-content">
    <div class="">
      <!-- start page title -->
      <div class="row">
        <div class="col-12">
          <div class="page-title-box d-sm-flex align-items-center justify-content-between"
            style="padding: 10px 1.5rem;
            background-color: var(--vz-card-bg) !important;
            -webkit-box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
            box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
            border-bottom: 1px solid none;
            border-top: 1px solid none;
            margin: -23px -1.5rem 1.5rem -1.5rem;">
            <h4 class="mb-sm-0" style="margin-left: 106px;">ADD CLAIM MANUALLY</h4>

            <div class="page-title-right" style="margin-right: 106px;">
              <ol class="breadcrumb m-0">
                {{-- <li class="breadcrumb-item"><a href="javascript: void(0);">Crypto</a></li> --}}
                <li class="breadcrumb-item active">ADD CLAIMS</li>
              </ol>
            </div>

          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-8 offset-md-2">
          <form action="{{ route('merchant.claim.store') }}" method="post" class="checkout-tab claim-form validity-form"
            enctype="multipart/form-data">
            @csrf
            <input type="hidden" name="ltdc_file" class="file-name" value="" />
            <input type="hidden" name="is_manually_added" class="" value="1" />
            <input type="hidden" name="status" class="status" value="1" />
            <input type="hidden" name="bank_id" value="{{ auth()->user()->activeBankAccount->id }}" />
            <!--end modal-body-->
            <div class="modal-body">
              <div class="tab-content">
                <div class="tab-pane fade show active" id="pills-bill-info" role="tabpanel"
                  aria-labelledby="pills-bill-info-tab">
                  <div class="row g-3 bg-white">
                    <!--end col-->
                    <div class="col-lg-4">
                      <div>
                        <label for="phoneNumber" class="form-label">Claim on TAN</label>
                        <input type="text" class="form-control tan-number" id="phoneNumber"
                          placeholder="{{ auth()->user()->tan_number }}" readonly>
                      </div>
                    </div>
                    <div class="col-lg-4">
                      <div>
                        <label for="phoneNumber" class="form-label">Merchant Company Name</label>
                        <input type="text" class="form-control" id="phoneNumber"
                          placeholder="{{ auth()->user()->company_name }}" readonly>
                      </div>
                    </div>
                    <div class="col-lg-4 d-none">
                      <div>
                        <label for="phoneNumber" class="form-label">Added By(Merchant Staff)</label>
                        <input type="text" class="form-control" id="phoneNumber"
                          placeholder="{{ auth()->user()->name }}" readonly>
                      </div>
                    </div>
                    <div class="col-lg-4">
                      <div>
                        <label for="accountnumberInput" class="form-label">Pan Number</label>
                        <input type="text" class="form-control" id="accountnumberInput"
                          placeholder="{{ auth()->user()->pancard_number }}" readonly>
                      </div>
                    </div>
                    <div class="col-lg-12" style="border-top:1px solid #eee"></div>
                    <!--end col-->
                    <div class="col-lg-5">
                      <div>
                        <label for="serviceTax" class="form-label">Upload: Form 16A(Only PDF)</label>
                        <input type="file" class="form-control tds-form" id="serviceTax" placeholder=""
                          name="form16_file" accept=".pdf" required />
                      </div>
                    </div>
                    <div class="col-lg-12" style="border-top:1px solid #eee"></div>

                    <!--end col-->
                    <div class="col-lg-3 ">
                      <div>
                        <label for="serviceTax" class="form-label"> Asst.Year <a title="Click to view an example."
                            target="_blank" href="{{ asset('assets/merchantAssets/sample-form16a.pdf') }}">
                            <i class="text-danger ri-information-line ms-2"></i>
                          </a></label>
                        <select class="form-select asst-year basic-form-16-data" name="asst_year">
                          <option value="">Select</option>
                          @for ($i = 2016; $i <= 2022; $i++)
                            {{-- @if (now()->addYear()->year > $i + 1) --}}
                            <option data-financial-year="{{ $i }}-{{ $i + 1 }}"
                              value="{{ $i + 1 }}-{{ $i + 2 }}">{{ $i + 1 }}-{{ $i + 2 }}
                            </option>
                            {{-- @endif --}}
                          @endfor
                        </select>
                      </div>
                    </div>
                    <!--end col-->
                    <div class="col-lg-3 ">
                      <div>
                        <label for="serviceTax" class="form-label"> Period From/To</label>
                        <select class="form-select period-from-to basic-form-16-data" name="period_from_to">
                          <option value="">Select</option>
                          <option data-quarter="1" value="Apr-June">Apr-June</option>
                          <option data-quarter="2" value="July-Sept">July-Sept</option>
                          <option data-quarter="3" value="Oct-Dec">Oct-Dec</option>
                          <option data-quarter="4" value="Jan-Mar">Jan-Mar</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-lg-3 ">
                      <div>
                        <label for="serviceTax" class="form-label"> Quarter</label>
                        <input type="text" name="quarter" value="{{ old('quarter') }}" readonly
                          class="quarter form-control basic-form-16-data" required placeholder="Quarter" />

                      </div>
                    </div>
                    <!--end col-->
                    <div class="col-lg-3 ">
                      <div>
                        <label for="serviceTax" class="form-label"> Financial Year</label>
                        <input type="text" name="financial_year" value="{{ old('financial_year') }}" readonly
                          class="form-control financial-year basic-form-16-data" required
                          placeholder="Financial Year" />

                      </div>
                    </div>
                    <!--end col-->

                    <!--end col-->
                    <div class="col-lg-3 ">
                      <div>
                        <label for="serviceTax" class="form-label"> Total Amount
                          Paid/Credited
                          <a title="Click to view an example." target="_blank"
                            href="{{ asset('assets/merchantAssets/sample-form16a.pdf') }}">
                            <i class="text-danger ri-information-line ms-2"></i>
                          </a>
                        </label>
                        <input type="number" min="0" step="0.01"
                          class="form-control amount-credited basic-form-16-data" id="serviceTax" placeholder="Enter"
                          name="amount_credited" value="{{ old('amount_credited') }}" required
                          placeholder="Total Amount Paid/Credited" />

                      </div>
                    </div>

                    <div class="col-lg-3 ">
                      <div>
                        <label for="serviceTax" class="form-label">TDS Claim Amount
                          <a title="Click to view an example." target="_blank"
                            href="{{ asset('assets/merchantAssets/sample-form16a.pdf') }}">
                            <i class="text-danger ri-information-line ms-2"></i>
                          </a>
                        </label>
                        <input type="number" min="0" step="0.01"
                          class="form-control tds-claim-amount basic-form-16-data" id="serviceTax"
                          name="tds_claim_amount" value="{{ old('tds_claim_amount') }}" required
                          placeholder="TDS Claim Amount" />

                      </div>
                    </div>
                    <!--end col-->
                    <div class="col-lg-3 ">
                      <div>
                        <label for="serviceTax" class="form-label">Rate of TDS in %</label>
                        <input type="number" min="0" max="100" step="0.01"
                          class="form-control rate-of-tds basic-form-16-data" readonly id="serviceTax"
                          name="rate_of_tds" value="{{ old('rate_of_tds') }}" required
                          placeholder="Rate of TDS in %" />

                      </div>
                    </div>
                    <!--end col-->
                    <div class="col-lg-3 ">
                      <div>
                        <label for="serviceTax" class="form-label"> Nature of payment(TDS Sec)</label>
                        <select class="form-select nature-of-payment basic-form-16-data" name="nature_of_tds">
                          <option value="">Select</option>
                          <option value="194A">194A</option>
                          <option value="194C">194C</option>
                          <option value="194G">194G</option>
                          <option value="194H">194H</option>
                          <option value="194I(b)">194I(b)</option>
                          <option value="194J">194J</option>
                          <option value="194JA">194JA</option>
                          <option value="194JB">194JB</option>
                          <option value="194O">194O</option>
                          <option value="194Q">194Q</option>
                        </select>
                      </div>
                    </div>
                    <!--end col-->
                    <div class="col-lg-3 ">
                      <div>
                        <label for="serviceTax" class="form-label">Certificate No.</label>
                        <input type="text" class="form-control certificate-no basic-form-16-data" id="serviceTax"
                          name="certificate_no" maxlength="100" value="{{ old('certificate_no') }}" required
                          placeholder="Certificate No." />

                      </div>
                    </div>
                    <!--end col-->
                    <div class="col-lg-3 ">
                      <div>
                        <label for="serviceTax" class="form-label">Last updated on</label>
                        <input type="date" class="form-control last-updated-on basic-form-16-data" id="serviceTax"
                          name="last_updated_on"
                          value="{{ old('last_updated_on') != null ? old('last_updated_on') : '' }}" required
                          placeholder="Last updated on" />

                      </div>
                    </div>


                    <div class="col-lg-12">
                      <button type="button"
                        class="d-flex align-items-center btn btn-sm btn-outline-success calculate-ltdc">
                        Calculate LTDC
                      </button>
                    </div>
                    <!--end col-->
                    <div class="col-lg-12" style="border:1px solid #eee;background: #fafafa;padding: 20px;">

                      <div class="row">
                        <div class="col-lg-12">
                          <div class="mt-2">
                            <label for="banknameInput" class="form-label font-normal d-none ltdc-file">
                              <a href="javascript:;" target="_blank" class="ltdc-file-path">
                                <i class=" bx bxs-file-pdf"></i>
                                View Merchant Lower TAX Deduction Certificate(
                                LTDC) : (Click to View).
                              </a>
                            </label>
                            <label for="banknameInput" class="form-label font-normal d-none revised-ltdc">
                              <a href="javascript:;" target="_blank" class="ltdc-file-path-revised">
                                <i class=" bx bxs-file-pdf"></i>
                                View Revised Merchant Lower TAX Deduction Certificate(
                                LTDC) : (Click to View).
                              </a>
                            </label>
                          </div>
                        </div>
                        <!--end col-->
                        <div class="col-lg-3">
                          <div class="mt-3">
                            <label for="branchInput" class="form-label font-normal">LTDC available</label>
                            <input type="text" class="form-control ltdc" id="ltdc" name="ltdc"
                              maxlength="100" value="{{ old('ltdc') }}" required readonly
                              placeholder="Certificate No." />
                          </div>
                        </div>
                        <!--end col-->
                        <div class="col-lg-3">
                          <div class="mt-3">
                            <label for="ifscInput" class="form-label font-normal">LTDC Total limit</label>
                            <input type="number" class="form-control ltdc-total-limit" min="0" step="0.01"
                              id="ifscInput" placeholder="Enter" name="ltdc_total_limit"
                              value="{{ old('ltdc_total_limit') }}" readonly>
                          </div>
                        </div>
                        <!--end col-->
                        <div class="col-lg-3">
                          <div class="mt-3">
                            <label for="accountnameInput" class="form-label font-normal">LTDC Rate</label>
                            <input type="number" class="form-control ltdc-rate" id="accountnameInput"
                              placeholder="Enter" min="0" step="0.01" name="ltdc_rate"
                              value="{{ old('ltdc_rate') }}" readonly>
                          </div>
                        </div>
                        <!--end col-->
                        <div class="col-lg-3">
                          <div class="mt-3">
                            <label for="accountnumberInput" class="form-label font-normal">
                              TDC limit available
                            </label>
                            <input type="number" class="form-control tds-limit-available" id="accountnumberInput"
                              placeholder="Enter" min="0" step="0.01" name="tdc_limit"
                              value="{{ old('tdc_limit') }}" readonly>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!--end col-->
                    <div class="col-lg-12 mb-4">
                      <div class="d-flex align-items-start gap-3 mt-3">
                        <button type="submit" class="btn btn-primary btn-label  nexttab save-btn disabled"
                          data-nexttab="pills-bill-address-tab" onclick="document.querySelector('.status').value='0'">
                          <i class="ri-arrow-left-line label-icon align-middle fs-16 ms-2"></i>
                          Save as Draft Claim
                        </button>
                        <button type="submit" class="btn btn-primary btn-label right ms-auto nexttab save-btn disabled"
                          data-nexttab="pills-bill-address-tab">
                          <i class="ri-arrow-right-line label-icon align-middle fs-16 ms-2"></i>
                          Submit Claim
                        </button>
                      </div>
                    </div>
                    <!--end col-->
                  </div>
                  <!--end row-->
                </div>
                <!-- end tab pane -->


              </div>
              <!-- end tab content -->
            </div>
            <!--end modal-body-->
          </form>
        </div>
      </div>

    </div>
  </div>
  <script src="{{ asset('assets/validate.js') }}"></script>
  <script type="module" src="{{ asset('assets/merchantAssets/manual-claim.js') }}"></script>
@endsection
