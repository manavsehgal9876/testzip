@extends('merchant.header')
@section('merchantContent')
  <div class="page-content">
    <div class="">
      <x-merchant.claim-form :claim="$claim" :route="$route" :form26AS="$form26AS" :grandTotalOfForm26AS="$grandTotalOfForm26AS" :grandTotalOfTds="$grandTotalOfTds"
        :ltdcs="$ltdcs" />
    </div>
    <!-- container-fluid -->
  </div>
  <!-- End Page-content -->
  <script type="module" src="{{ asset('assets/merchantAssets/claim.js') }}"></script>
@endsection
