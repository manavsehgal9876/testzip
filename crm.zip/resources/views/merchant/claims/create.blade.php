@extends('merchant.header')
@section('merchantContent')
  <input type="hidden" class="hidden-string" value="{{ session('randomString') }}" />
  <div class="page-content">
    <div class="">
      <!-- start page title -->
      <div class="row">
        <div class="col-12">
          <div class="page-title-box d-sm-flex align-items-center justify-content-between"
            style="padding: 10px 1.5rem;
            background-color: var(--vz-card-bg) !important;
            -webkit-box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
            box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
            border-bottom: 1px solid none;
            border-top: 1px solid none;
            margin: -23px -1.5rem 1.5rem -1.5rem;">
            <h4 class="mb-sm-0" style="margin-left: 106px;">ADD CLAIMS</h4>

            <div class="page-title-right" style="margin-right: 106px;">
              <ol class="breadcrumb m-0">
                {{-- <li class="breadcrumb-item"><a href="javascript: void(0);">Crypto</a></li> --}}
                <li class="breadcrumb-item active">ADD CLAIMS</li>
              </ol>
            </div>

          </div>
        </div>
      </div>
      <!-- end page title -->


      <div class="row justify-content-center">
        <div class="col-lg-6">
          <div class="card">
            <div class="card-body">
              <div class="text-center">
                <div class="row justify-content-center">
                  <div class="col-lg-9">
                    <h4 class="mt-4 fw-semibold">ADD CLAIMS</h4>

                    <div class="mt-4">
                      <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                        data-bs-target="#exampleModal">
                        Add Claims Details
                      </button>
                    </div>

                    <div class="row justify-content-center">
                      <lottie-player src="https://assets6.lottiefiles.com/packages/lf20_ijgxlbh7.json"
                        background="transparent" speed="1" style="width: 400px; height: 400px;" loop autoplay>
                      </lottie-player>
                    </div>

                  </div>
                </div>

                <div class="row justify-content-center mt-5 mb-2">
                  <div class="col-sm-7 col-8">
                    <img src="assets/images/verification-img.png" alt="" class="img-fluid" />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!--end card-->
        </div>
        <!--end col-->
      </div>
      <!--end row-->


      <!--end modal-->

    </div>
    <!-- container-fluid -->
  </div>
  <!-- End Page-content -->
  <x-merchant.claim-modal />
@endsection
