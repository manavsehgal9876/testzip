@extends('merchant.header')
@section('merchantContent')
  <div class="page-content">
    <div class="">

      <div class="row">
        <div class="col-12">
          <div class="page-title-box d-sm-flex align-items-center justify-content-between"
            style="padding: 10px 1.5rem;
            background-color: var(--vz-card-bg) !important;
            -webkit-box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
            box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
            border-bottom: 1px solid none;
            border-top: 1px solid none;
            margin: -23px -1.5rem 1.5rem -1.5rem;">
            <h4 class="mb-sm-0" style="margin-left: 106px;">View Event</h4>

            <div class="page-title-right" style="margin-right: 106px;">
              <ol class="breadcrumb m-0">
                <li class="breadcrumb-item"><a href="javascript: void(0);">{{ Str::ucfirst(Request::segment(1)) }}</a>
                </li>
                <li class="breadcrumb-item active">View Event</li>
              </ol>
            </div>

          </div>
        </div>
      </div>


      <div class="container-fluid">
        <div class="row">
          <!--end col-->
          <div class="col-xxl-12">
            <div class="card" id="companyList">
              <div class="card-body">
                <div>
                  <div class="table-responsive table-card mb-3">
                    <table class="table align-middle table-nowrap mb-0" id="customerTable">
                      <thead class="table-light">
                        <tr>
                          <th class="sort" scope="col">#</th>
                          <th class="sort" scope="col">Event Name</th>
                          <th class="sort" scope="col">Event Description</th>
                          <th class="sort" scope="col">Event Date/Time</th>
                          <th class="sort" scope="col">Created On</th>
                        </tr>
                      </thead>
                      <tbody class="list form-check-all">
                        @foreach ($events as $key => $event)
                          <tr>
                            <td class="location">
                              {{ ++$key }}
                            </td>
                            <td class="location">
                              {{ $event->name }}
                            </td>
                            <td class="location">
                              {{ $event->description }}
                            </td>
                            <td class="location">
                              {{ $event->date_time->format('d M, Y h:i A') }}
                            </td>
                            <td class="location">
                              {{ $event->created_at->format('d M, Y') }}
                            </td>
                          </tr>
                        @endforeach
                      </tbody>
                    </table>
                  </div>

                </div>
                <x-event-modal />
                <!--end add modal-->

              </div>
            </div>
            <!--end card-->
          </div>
          <!--end col-->
        </div>
      </div>
      <!--end modal-->

    </div>
    <!-- container-fluid -->
  </div>
  <!-- End Page-content -->
@endsection
