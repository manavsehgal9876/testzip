@extends('merchant.header')
@section('merchantContent')
  <div class="page-content">
    <div class="">
      <!-- start page title -->
      <!-- end page title -->
      <div class="container-fluid">
        <div class="team-list row list-view-filter">

          <div class="col-lg-12">
            <div class="row">
              <div class="col-md-4">
                <h5 class="mt-3">Bank Account</h5>
              </div>
              <div class="col-md-8 text-end my-auto">
                @if (!$anyActiveBankDetail)
                  <p style="margin:0;color:red;font-weight: normal;">To add new bank account, Please disable
                    the existing active bank account. </p>
                @endif
              </div>
            </div>
            <div class="card team-box">
              <div class="card-body">
                <div>
                  <div class="table-responsive table-card border_lin0">
                    <table class="table align-middle mb-0 pb-0" id="customerTable">

                      <tbody class="list form-check-all">
                        @forelse($bankDetails as $bank)
                          <tr>
                            <td>
                              <div class="team-profile-img">
                                <div class="avatar-lg img-thumbnail rounded-circle flex-shrink-0">
                                  <img
                                    src="@if ($bank->merchant->logo && Storage::disk('appFiles')->exists("merchant/{$bank->merchant->logo}")) {{ asset('crm/public/uploads/merchant') . '/' . $bank->merchant->logo }} @else {{ defaultProfileImage() }} @endif"
                                    alt="{{ $bank->merchant->company_name }}"
                                    class="img-fluid d-block rounded-circle w-100 h-100">
                                </div>
                                <div class="team-content">
                                  <a href="javascript:;" aria-controls="offcanvasExample">
                                    <h5 class="fs-16 mb-1">{{ $bank->merchant->company_name }} </h5>
                                  </a>
                                  <p class="text-muted mb-0">TAN: {{ $bank->merchant->tan_number }} </p>
                                  <p class="text-muted mb-0">Email: {{ $bank->merchant->email }} </p>
                                  <p class="text-muted mb-0">Phone: {{ $bank->merchant->phone }} </p>

                                  <p class="text-muted mb-0" style="color: #2d4187 !important;">SAP Code:
                                    {{ $bank->merchant->sap_code }}</p>

                                </div>
                              </div>
                            </td>

                            <td class="name">
                              <a href="javascript:;" aria-controls="offcanvasExample">
                                <h5 class="fs-16 mb-1">Bank Detail </h5>
                              </a>
                              <p class="text-muted mb-0">{{ $bank->name }}</p>
                              <p class="text-muted mb-0">Branch: {{ $bank->branch }} </p>
                              <p class="text-muted mb-0">Acc No: {{ $bank->account_number }}</p>
                              <p class="text-muted mb-0">IFSC: {{ $bank->ifsc }}</p>
                              <p class="text-muted mb-0">Acc Holder Name: {{ $bank->acc_holder_name }}</p>
                              @if ($bank->cancel_cheque && Storage::disk('appFiles')->exists("merchant/{$bank->cancel_cheque}"))
                                <a href="{{ asset('crm/public/uploads/merchant') . '/' . $bank->cancel_cheque }}"
                                  target="_blank">
                                  <p class="text-muted mb-0">Cheque
                                    <lord-icon src="https://cdn.lordicon.com/biwxmlnf.json" trigger="loop"
                                      style="width:20px;height:20px">
                                    </lord-icon>
                                  </p>
                                </a>
                              @endif
                            </td>

                            <td class="name">
                              <a href="javascript:;" aria-controls="offcanvasExample">
                                <h5 class="fs-16 mb-1">Date & Status </h5>
                              </a>
                              <p class="text-muted mb-0">Created On: {{ $bank->created_at->format('d M, Y, H:i a') }}
                              </p>
                              <p class="text-muted mb-0">Disabled On:
                                {{ isset($bank->disabled_at) ? $bank->disabled_at->format('d M, Y, H:i a') : '' }} </p>
                              <p class="text-muted mb-0">Enabled On:
                                {{ isset($bank->enabled_at) ? $bank->enabled_at->format('d M, Y, H:i a') : '' }} </p>
                              <p class="text-muted mb-0">Status:
                                @if ($bank->status)
                                  <span class="badge bg-success">Active</span>
                                @else
                                  <span class="badge bg-danger">Inactive</span>
                                @endif
                              </p>
                            </td>

                            <td></td>
                            <td class="name">
                              @if ($loop->first && $anyActiveBankDetail)
                                <p style="margin:0">
                                  <a href="javascript:;" class="btn btn-light view-btn mt-2" data-bs-toggle="modal"
                                    data-bs-target="#exampleModal" onclick="updateBankInfoModal()">
                                    Add New Account
                                    <lord-icon src="https://cdn.lordicon.com/diyeocup.json" trigger="loop"
                                      style="width:16px;height:16px">
                                    </lord-icon>
                                  </a>
                                </p>
                              @endif
                              <p style="margin:0">
                                <a href="{{ route('merchant.bank-details.toggle', $bank->id) }}"
                                  class="btn btn-soft-secondary waves-effect waves-light view-btn mt-2">
                                  @if ($bank->status)
                                    Disable Account
                                    <lord-icon src="https://cdn.lordicon.com/vfzqittk.json" trigger="loop"
                                      style="width:16px;height:16px">
                                    </lord-icon>
                                  @else
                                    Enable Account
                                    <lord-icon src="https://cdn.lordicon.com/hjeefwhm.json" trigger="loop"
                                      style="width:16px;height:16px">
                                    </lord-icon>
                                  @endif
                                </a>
                              </p>
                              {{-- <p style="margin:0">
                                <a href="javascript:;" class="btn btn-soft-info waves-effect waves-light view-btn mt-2"
                                  data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="setBankInfo(this)"
                                  data-bank-details="{{ $bank->toJson() }}">Edit Details
                                  <lord-icon src="https://cdn.lordicon.com/oclwxpmm.json" trigger="loop"
                                    style="width:16px;height:16px">
                                  </lord-icon>
                                </a>
                              </p> --}}

                              {{-- <p style="margin:0">
                                <a href="javascript:;" class="btn btn-soft-danger view-btn mt-2"
                                  data-url="{{ route('merchant.bank-details.destroy', $bank->id) }}"
                                  onclick="handleDelete(this)">
                                  Delete
                                  <lord-icon src="https://cdn.lordicon.com/dovoajyj.json" trigger="loop"
                                    style="width:16px;height:16px">
                                  </lord-icon>
                                </a>
                              </p> --}}
                            </td>
                          </tr>
                        @empty
                          <tr>
                            <td>
                              <div class="team-profile-img">
                                <div class="avatar-lg img-thumbnail rounded-circle flex-shrink-0">
                                  <img src="{{ defaultProfileImage() }}" alt="{{ 'Add new bank account' }}"
                                    class="img-fluid d-block rounded-circle">
                                </div>
                                <div class="team-content">
                                  <a href="javascript:;" aria-controls="offcanvasExample">
                                    <h5 class="fs-16 mb-1">---------------------</h5>
                                  </a>
                                  <p class="text-muted mb-0">TAN: --------------------- </p>
                                  <p class="text-muted mb-0">Email: --------------------- </p>
                                  <p class="text-muted mb-0">Phone: --------------------- </p>

                                  <p class="text-muted mb-0" style="color: #2d4187 !important;">SAP Code:
                                    ---------------------</p>

                                </div>
                              </div>
                            </td>

                            <td class="name">
                              <a href="javascript:;" aria-controls="offcanvasExample">
                                <h5 class="fs-16 mb-1">Bank Detail </h5>
                              </a>
                              <p class="text-muted mb-0">---------------------</p>
                              <p class="text-muted mb-0">Branch: --------------------- </p>
                              <p class="text-muted mb-0">Acc No: ---------------------</p>
                              <p class="text-muted mb-0">IFSC: ---------------------</p>
                              <p class="text-muted mb-0">Acc Holder Name: ---------------------</p>
                            </td>

                            <td class="name">
                              <a href="javascript:;" aria-controls="offcanvasExample">
                                <h5 class="fs-16 mb-1">Date & Status </h5>
                              </a>
                              <p class="text-muted mb-0">Created On: --------------------- </p>
                              <p class="text-muted mb-0">Status:
                                ---------------------
                              </p>
                            </td>

                            <td></td>
                            <td class="name">
                              <p style="margin:0">
                                <a href="javascript:;" class="btn btn-light view-btn mt-2" data-bs-toggle="modal"
                                  data-bs-target="#exampleModal" onclick="updateBankInfoModal()">
                                  Add New Account
                                  <lord-icon src="https://cdn.lordicon.com/diyeocup.json" trigger="loop"
                                    style="width:16px;height:16px">
                                  </lord-icon>
                                </a>
                              </p>
                            </td>
                          </tr>
                        @endforelse
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
            </div>
          </div>


        </div>
      </div>

      <svg class="bookmark-hide">
        <symbol viewBox="0 0 24 24" stroke="currentColor" fill="var(--color-svg)" id="icon-star">
          <path stroke-width=".4"
            d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z">
          </path>
        </symbol>
      </svg>
      <x-merchant.bank-detail-modal :merchantId="auth()->user()->id" />
      <!--end modal-->
    </div><!-- container-fluid -->
  </div><!-- End Page-content -->
  <!--end offcanvas-->
  <script src="{{ asset('assets/merchantAssets/bank-details.js') }}"></script>
@endsection
