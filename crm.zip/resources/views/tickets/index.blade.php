@extends($headers['extends'])
@section($headers['section'])
  <div class="page-content">
    <div class="">

      <div class="row">
        <div class="col-12">
          <div class="page-title-box d-sm-flex align-items-center justify-content-between"
            style="padding: 10px 1.5rem;
            background-color: var(--vz-card-bg) !important;
            -webkit-box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
            box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
            border-bottom: 1px solid none;
            border-top: 1px solid none;
            margin: -23px -1.5rem 1.5rem -1.5rem;">
            <h4 class="mb-sm-0" style="margin-left: 106px;">View Tickets</h4>

            <div class="page-title-right" style="margin-right: 106px;">
              <ol class="breadcrumb m-0">
                <li class="breadcrumb-item"><a href="javascript: void(0);">{{ Str::ucfirst(Request::segment(1)) }}</a>
                </li>
                <li class="breadcrumb-item active">View Tickets</li>
              </ol>
            </div>

          </div>
        </div>
      </div>


      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12">
            <div class="card">
              <div class="card-header">
                <div class="d-flex align-items-center flex-wrap gap-2">
                  @auth('web')
                    <div class="flex-grow-1">
                      <button class="btn btn-info add-btn" data-bs-toggle="modal" data-bs-target="#newTicketModal"
                        data-user-type="{{ Request::segment(1) }}"><i class="ri-add-fill me-1 align-bottom"></i> Add
                        Ticket</button>
                    </div>
                  @endauth
                  <div class="flex-shrink-0">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!--end col-->
          <div class="col-xxl-12">
            <div class="card" id="companyList">
              <div class="card-body">
                <div>
                  <div class="table-responsive table-card mb-3">
                    <table class="table align-middle table-nowrap mb-0" id="customerTable">
                      <thead class="table-light">
                        <tr>
                          <th class="sort" scope="col">#</th>
                          <th class="sort" scope="col">Ticket By Merchant</th>
                          <th class="sort" scope="col">Ticket Title</th>
                          <th class="sort" scope="col">Ticket Description</th>
                          <th class="sort" scope="col">Ticket Reply</th>
                          <th class="sort" scope="col">Created On</th>
                          <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody class="list form-check-all">
                        @foreach ($tickets as $key => $ticket)
                          <tr>
                            <td class="location">
                              {{ ++$key }}
                            </td>
                            <td class="location">
                              <span>Name: {{ $ticket->merchant->company_name }}</span><br />
                              <span>Tan No.: {{ $ticket->merchant->tan_number }}</span><br />
                            </td>
                            <td class="location">
                              {{ $ticket->title }}
                            </td>
                            <td class="location">
                              {{ $ticket->description }}
                            </td>
                            <td class="location">
                              {{ $ticket->reply }}
                            </td>
                            <td class="location">
                              {{ $ticket->created_at->format('d M, Y') }}
                            </td>
                            <td>
                              @empty($ticket->reply)
                                @auth('company_staff')
                                  <ul class="list-inline hstack gap-2 mb-0">
                                    <li class="list-inline-item" data-bs-toggle="tooltip" data-bs-trigger="hover"
                                      data-bs-placement="top" title="Reply">
                                      <a class="edit-item-btn" href="#replyModal" data-bs-toggle="modal"
                                        onclick="setTicketInfo(this)" data-user-type="{{ Request::segment(1) }}"
                                        data-event="{{ $ticket->toJson() }}">
                                        <lord-icon src="https://cdn.lordicon.com/wloilxuq.json" trigger="loop"
                                          style="width:16px;height:16px">
                                        </lord-icon>
                                      </a>
                                    </li>
                                  </ul>
                                @endauth
                              @endempty
                            </td>
                          </tr>
                        @endforeach
                      </tbody>
                    </table>
                    <div class="noresult" style="display: none">
                      <div class="text-center">
                        <lord-icon src="https://cdn.lordicon.com/msoeawqm.json" trigger="loop"
                          colors="primary:#121331,secondary:#08a88a" style="width:75px;height:75px">
                        </lord-icon>
                        <h5 class="mt-2">Sorry! No Result Found</h5>
                        <p class="text-muted mb-0">We've searched more than 150+ companies
                          We did not find any
                          companies for you search.</p>
                      </div>
                    </div>
                  </div>

                </div>
                <x-ticket-modal />
                <x-ticket-reply-modal />
                <!--end add modal-->

              </div>
            </div>
            <!--end card-->
          </div>
          <!--end col-->
        </div>
      </div>
      <!--end modal-->

    </div>
    <!-- container-fluid -->
  </div>
  <!-- End Page-content -->
  <script src="{{ asset('assets/ticket.js') }}"></script>
@endsection
