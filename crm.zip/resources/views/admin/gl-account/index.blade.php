@extends('admin.header')
@section('adminContent')
  <div class="page-content">
    <div class="">

      <div class="row">
        <div class="col-12">
          <div class="page-title-box d-sm-flex align-items-center justify-content-between"
            style="padding: 10px 1.5rem;
                  background-color: var(--vz-card-bg) !important;
                  -webkit-box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
                  box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
                  border-bottom: 1px solid none;
                  border-top: 1px solid none;
                  margin: -23px -1.5rem 1.5rem -1.5rem;">
            <h4 class="mb-sm-0" style="margin-left: 106px;">Add Gl Account</h4>

            <div class="page-title-right" style="margin-right: 106px;">
              <ol class="breadcrumb m-0">
                <li class="breadcrumb-item"><a href="javascript: void(0);">Admin</a></li>
                <li class="breadcrumb-item active">Add Gl Account</li>
              </ol>
            </div>

          </div>
        </div>
      </div>


      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12">
            <div class="card">
              <div class="card-header">
                <div class="d-flex align-items-center flex-wrap gap-2">
                  <div class="flex-grow-1">
                    <button class="btn btn-info add-btn" data-bs-toggle="modal" data-bs-target="#showModal"
                      onclick="updateGlInfoModal()"><i class="ri-add-fill me-1 align-bottom"></i> Add
                      GL Number</button>
                  </div>
                  <div class="flex-shrink-0">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!--end col-->
          <div class="col-xxl-12">
            <div class="card" id="companyList">
              <div class="card-body">
                <div>
                  <div class="table-responsive table-card mb-3">
                    <table class="table align-middle table-nowrap mb-0" id="customerTable">
                      <thead class="table-light">
                        <tr>
                          <th class="sort" scope="col">Financial Year</th>
                          <th class="sort" scope="col">GL Number</th>
                          <th class="sort" scope="col">GL Description</th>
                          <th class="sort" scope="col">Created On</th>
                          <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody class="list form-check-all">
                        @foreach ($glAccounts as $glAccount)
                          <tr>
                            <td class="location">
                              {{ $glAccount->financial_year }}
                            </td>
                            <td class="location">
                              {{ $glAccount->gl_number }}
                            </td>
                            <td class="location">
                              {{ $glAccount->gl_description }}
                            </td>
                            <td class="location">
                              {{ $glAccount->created_at->format('d M, Y') }}
                            </td>
                            <td>
                              <ul class="list-inline hstack gap-2 mb-0">
                                <li class="list-inline-item" data-bs-toggle="tooltip" data-bs-trigger="hover"
                                  data-bs-placement="top" title="Edit">
                                  <a class="edit-item-btn" href="#showModal" data-bs-toggle="modal"
                                    onclick="setGlInfo(this)" data-gl-details="{{ $glAccount->toJson() }}">
                                    <lord-icon src="https://cdn.lordicon.com/oclwxpmm.json" trigger="loop"
                                      style="width:16px;height:16px">
                                    </lord-icon>
                                  </a>
                                </li>
                                {{-- <li class="list-inline-item" data-bs-toggle="tooltip" data-bs-trigger="hover"
                                  data-bs-placement="top" title="Delete">
                                  <a class="remove-item-btn" href="javascript:;"
                                    data-url="{{ route('admin.gl-account.destroy', $glAccount->id) }}"
                                    onclick="handleDelete(this)">
                                    <lord-icon src="https://cdn.lordicon.com/dovoajyj.json" trigger="loop"
                                      style="width:16px;height:16px">
                                    </lord-icon>
                                    </i>
                                  </a>
                                </li> --}}
                              </ul>
                            </td>
                          </tr>
                        @endforeach
                      </tbody>
                    </table>
                    <div class="noresult" style="display: none">
                      <div class="text-center">
                        <lord-icon src="https://cdn.lordicon.com/msoeawqm.json" trigger="loop"
                          colors="primary:#121331,secondary:#08a88a" style="width:75px;height:75px">
                        </lord-icon>
                        <h5 class="mt-2">Sorry! No Result Found</h5>
                        <p class="text-muted mb-0">We've searched more than 150+ companies
                          We did not find any
                          companies for you search.</p>
                      </div>
                    </div>
                  </div>

                </div>
                <x-admin.gl-modal />
                <!--end add modal-->

              </div>
            </div>
            <!--end card-->
          </div>
          <!--end col-->
        </div>
      </div>
      <!--end modal-->

    </div>
    <!-- container-fluid -->
  </div>
  <!-- End Page-content -->
  <script src="{{ asset('assets/adminAssets/gl-account.js') }}"></script>
@endsection
