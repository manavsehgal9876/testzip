@extends('admin.header')
@section('adminContent')
  <div class="page-content">
    <div class="">

      <!-- start page title -->
      <div class="row">
        <div class="col-12">
          <div class="page-title-box d-sm-flex align-items-center justify-content-between"
            style="padding: 10px 1.5rem;
            background-color: var(--vz-card-bg) !important;
            -webkit-box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
            box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
            border-bottom: 1px solid none;
            border-top: 1px solid none;
            margin: -23px -1.5rem 1.5rem -1.5rem;">
            <h4 class="mb-sm-0" style="margin-left: 106px;">All password reset requests</h4>
          </div>
        </div>
      </div>
      <!-- end page title -->
      <div class="container-fluid">

        <div class="team-list row list-view-filter">

          <div class="col-lg-12">
            <div class="card team-box">
              <div class="card-body">
                <div>
                  <div class="live-preview">
                    <div class="table-responsive">
                      <table class="table align-middle table-striped table-nowrap mb-0 data-table" id="customerTable">
                        <thead>
                          <tr>
                            <th scope="col" class=" text-center">Merchant Company</th>
                            <th scope="col" class=" text-center">Merchant Tan</th>
                            <th scope="col" class=" text-center">Requested Email</th>
                            {{-- <th scope="col" class=" text-center">Merchant Phone</th> --}}
                            <th scope="col" class=" text-center">Requested On</th>
                            <th scope="col" class=" text-center">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          @foreach ($requests as $request)
                            <tr
                              @isset($request->merchant->id) 
                                style="cursor:pointer";
                                onclick="window.open('{{ route('admin.merchant.staff.index', ['id' => @$request->merchant->id]) }}').focus()"
                              @endisset>
                              <td class="name ">
                                <p class=" text-center text-muted mb-0"><span
                                    style="color: #2d4187 !important;">{{ @$request->merchant->company_name }}</span>
                                </p>
                              </td>
                              <td class="name ">
                                <p class=" text-center text-muted mb-0"><span
                                    style="color: #2d4187 !important;">{{ @$request->merchant->tan_number }}</span>
                                </p>
                              </td>
                              <td class="name ">
                                <p class=" text-center text-muted mb-0"><span
                                    style="color: #2d4187 !important;">{{ $request->email }}</span>
                                </p>
                              </td>
                              <td class="name ">
                                <p class=" text-center text-muted mb-0"><span
                                    style="color: #2d4187 !important;">{{ @$request->merchant->phone }}</span>
                                </p>
                              </td>
                              <td class="name">
                                <p class=" text-center text-muted mb-0"><span
                                    style="color: #2d4187 !important;">{{ $request->created_at->format('d M, Y, h:i A') }}</span>
                                </p>
                              </td>
                              <td>
                                @if (!$request->is_completed)
                                  <ul class="list-inline hstack gap-2 mb-0 d-flex justify-content-center">
                                    <li class="list-inline-item" title="Mark as completed">
                                      <a
                                        href="{{ route('admin.merchant.toggle-password-reset-requests', [$request->id, 1]) }}">
                                        <i class="ri-check-line align-bottom text-muted"></i>
                                      </a>
                                    </li>
                                  </ul>
                                @endif
                              </td>
                            </tr>
                          @endforeach
                        </tbody>
                      </table>
                    </div>
                  </div>

                </div>
              </div>


            </div>
            {{ $requests->links() }}
          </div>

        </div>
      </div>


    </div><!-- container-fluid -->
  </div><!-- End Page-content -->
@endsection
