@extends('admin.header')
@section('adminContent')
  <div class="page-content">
    <div class="">

      <!-- start page title -->
      <div class="row">
        <div class="col-12">
          <div class="page-title-box d-sm-flex align-items-center justify-content-between"
            style="padding: 10px 1.5rem;
              background-color: var(--vz-card-bg) !important;
              -webkit-box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
              box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
              border-bottom: 1px solid none;
              border-top: 1px solid none;
              margin: -23px -1.5rem 1.5rem -1.5rem;">
            <h4 class="mb-sm-0" style="margin-left: 106px;">All Form 26AS</h4>
          </div>
        </div>
      </div>
      <!-- end page title -->
      <div class="container-fluid">

        <div class="team-list row list-view-filter">

          <div class="col-lg-12">
            <div class="card team-box">
              <div class="card-body">

                <form class="row g-2 mb-2" action="{{ route('admin.form-twenty-six.index') }}" method="get">
                  <div class="col-sm-auto">
                    <select class="form-control form-26-financial-year" name="financial_year" required>
                      <option disabled selected>Financial year</option>
                      <option value="">All</option>
                      @foreach ($financialYears as $financialYear)
                        <option @selected(Request('financial_year') === $financialYear) value="{{ $financialYear }}">{{ $financialYear }}</option>
                      @endforeach
                    </select>
                  </div>
                  <div class="col-sm-auto">
                    <input name="search" class="form-control" value="{{ Request('search') }}"
                      placeholder="Tan or Name" />
                  </div>
                  <div class="col-sm-auto">
                    <select class="form-control form-26-financial-year" name="quarter" required>
                      <option disabled selected>Quarter</option>
                      <option value="">All</option>
                      @foreach ($quarters as $quarter)
                        <option @selected(Request('quarter') === $quarter) value="{{ $quarter }}">{{ $quarter }}</option>
                      @endforeach
                    </select>
                  </div>
                  <div class="col-sm-auto">
                    <button type="submit" class="btn btn-soft-primary waves-effect waves-light form-26-filter">
                      Filter
                    </button>
                    <a href="{{ route('admin.form-twenty-six.index') }}"
                      class="btn btn-soft-secondary waves-effect waves-light form-26-filter">
                      Reset
                    </a>
                    @if (Request('financial_year') !== null)
                      <a href="{{ route('admin.form-26-as-report', Request('financial_year')) }}"
                        class="btn btn-soft-success waves-effect waves-light form-26-filter">
                        TDS Liability Report
                      </a>
                    @endif
                  </div>

                  <!--end col-->
                </form>

                <div>
                  <div class="live-preview">
                    <x-form26as-table :form26as="$form26as" />
                  </div>

                </div>
              </div>
            </div>
          </div>

        </div>
      </div>

      <svg class="bookmark-hide">
        <symbol viewBox="0 0 24 24" stroke="currentColor" fill="var(--color-svg)" id="icon-star">
          <path stroke-width=".4"
            d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z">
          </path>
        </symbol>
      </svg>

    </div><!-- container-fluid -->
  </div><!-- End Page-content -->
  <script type="module" src="{{ asset('assets/merchantAssets/ltds.js') }}"></script>
@endsection
