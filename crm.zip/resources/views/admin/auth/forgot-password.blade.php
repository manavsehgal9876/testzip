@extends('admin.auth.header')
@section('adminAuthContent')
  <!-- auth page content -->
  <div class="auth-page-content">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="text-center mt-sm-5 mb-4 text-white-50">
            <div>
              <a href="{{ route('admin.home') }}" class="d-inline-block auth-logo">
                <img src="{{ asset('assets/adminAssets/images/logo-dark.png') }}" alt="" height="70">
              </a>
            </div>
            <p class="mt-3 fs-15 fw-medium"> Admin Forgot Password </p>
          </div>
        </div>
      </div>
      <!-- end row -->

      <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6 col-xl-5">
          <div class="card mt-4">

            <div class="card-body p-4">
              <div class="text-center mt-2">
                <h5 class="text-primary">Welcome Back !</h5>
                <p class="text-muted">Enter your email to get password reset link</p>
              </div>
              <div class="p-2 mt-4">
                <form action="{{ route('admin.forgot-password') }}" method="post">
                  @csrf
                  <div class="mb-3">
                    <label for="username" class="form-label">Enter Email</label>
                    <input type="email" class="form-control" id="username" placeholder="Email" name="email" required
                      value="{{ old('email') }}" maxlength="100">
                  </div>

                  <div class="mt-4">
                    <button class="btn btn-success w-100" type="submit">Send Password Reset Link</button>
                  </div>


                </form>
              </div>
            </div>
            <!-- end card body -->
          </div>
          <!-- end card -->

        </div>
      </div>
      <!-- end row -->
    </div>
    <!-- end container -->
  </div>
  <!-- end auth page content -->
@endsection
