@extends('admin.header')
@section('adminContent')
  <div class="page-content">
    <div class="">

      <div class="row">
        <div class="col-12">
          <div class="page-title-box d-sm-flex align-items-center justify-content-between"
            style="padding: 10px 1.5rem;
                  background-color: var(--vz-card-bg) !important;
                  -webkit-box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
                  box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
                  border-bottom: 1px solid none;
                  border-top: 1px solid none;
                  margin: -23px -1.5rem 1.5rem -1.5rem;">
            <h4 class="mb-sm-0" style="margin-left: 106px;">Add Company</h4>

            <div class="page-title-right" style="margin-right: 106px;">
              <ol class="breadcrumb m-0">
                <li class="breadcrumb-item"><a href="javascript: void(0);">Admin</a></li>
                <li class="breadcrumb-item active">Add Company</li>
              </ol>
            </div>

          </div>
        </div>
      </div>


      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12">
            <div class="card">
              <div class="card-header">
                <div class="d-flex align-items-center flex-wrap gap-2">
                  <div class="flex-grow-1">
                    <button class="btn btn-info add-btn" data-bs-toggle="modal" data-bs-target="#showModal"
                      onclick="updateCompanyInfoModal()"><i class="ri-add-fill me-1 align-bottom"></i> Add
                      Company</button>
                  </div>
                  <div class="flex-shrink-0">
                    {{-- <div class="hstack text-nowrap gap-2">
                      <button class="btn btn-soft-danger" onClick="deleteMultiple()"><i
                          class="ri-delete-bin-2-line"></i></button>
                      <button type="button" class="btn btn-info" data-bs-toggle="offcanvas" href="#offcanvasExample"><i
                          class="ri-filter-3-line align-bottom me-1"></i>
                        Fliters</button>
                      <button class="btn btn-soft-success">Import</button>
                      <button type="button" id="dropdownMenuLink1" data-bs-toggle="dropdown" aria-expanded="false"
                        class="btn btn-soft-info"><i class="ri-more-2-fill"></i></button>
                      <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink1">
                        <li><a class="dropdown-item" href="#">All</a></li>
                        <li><a class="dropdown-item" href="#">Last Week</a></li>
                        <li><a class="dropdown-item" href="#">Last Month</a></li>
                        <li><a class="dropdown-item" href="#">Last Year</a></li>
                      </ul>
                    </div> --}}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!--end col-->
          <div class="col-xxl-12">
            <div class="card" id="companyList">
              <div class="card-header">
                <div class="row g-2">
                  <div class="col-md-3">
                    <div class="search-box">
                      <input type="text" class="form-control search" placeholder="Search for company...">
                      <i class="ri-search-line search-icon"></i>
                    </div>
                  </div>

                </div>
              </div>
              <div class="card-body">
                <div>
                  <div class="table-responsive table-card mb-3">
                    <table class="table align-middle table-nowrap mb-0" id="customerTable">
                      <thead class="table-light">
                        <tr>
                          <th scope="col" style="width: 50px;">
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" id="checkAll" value="option">
                            </div>
                          </th>
                          <th class="sort" data-sort="name" scope="col">Company Name</th>
                          <th class="sort" data-sort="owner" scope="col">Contact</th>
                          <th class="sort" data-sort="location" scope="col">Location</th>
                          <th class="sort" data-sort="industry_type" scope="col">Address</th>
                          <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody class="list form-check-all">
                        @foreach ($companies as $company)
                          <tr>
                            <th scope="row">
                              <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="chk_child" value="option1">
                              </div>
                            </th>
                            <td class="id" style="display:none;"><a href="javascript:void(0);"
                                class="fw-medium link-primary">#VZ001</a></td>
                            <td>
                              <div class="d-flex align-items-center">
                                <div class="flex-shrink-0">
                                  <img
                                    src="@if ($company->logo && Storage::disk('appFiles')->exists("company/{$company->logo}")) {{ asset('crm/public/uploads/company') . '/' . $company->logo }} @else {{ defaultProfileImage() }} @endif"
                                    alt="{{ $company->name }}" class="avatar-xxs rounded-circle image_src">
                                </div>
                                <div class="flex-grow-1 ms-2 name">{{ $company->name }}
                                </div>
                              </div>
                            </td>
                            <td class="owner">
                              <p>E: {{ $company->email }}</p>
                              <p>M: {{ $company->phone }}</p>
                            </td>
                            <td class="industry_type">
                              @isset($company->myCountry)
                                {{ $company->myCountry->name }}<br />
                              @endisset
                              @isset($company->myState)
                                {{ $company->myState->name }}<br />
                              @endisset
                              @isset($company->myCity)
                                {{ $company->myCity->name }}.
                              @endisset
                            </td>

                            <td class="location">
                              {{ $company->address }}
                            </td>
                            <td>
                              <ul class="list-inline hstack gap-2 mb-0">

                                {{-- <li class="list-inline-item" data-bs-toggle="tooltip" data-bs-trigger="hover"
                                  data-bs-placement="top" title="View">
                                  <a href="javascript:void(0);" class="view-item-btn"><i
                                      class="ri-eye-fill align-bottom text-muted"></i></a>
                                </li> --}}
                                <li class="list-inline-item" data-bs-toggle="tooltip" data-bs-trigger="hover"
                                  data-bs-placement="top" title="Edit">
                                  <a class="edit-item-btn" href="#showModal" data-bs-toggle="modal"
                                    onclick="setCompanyInfo(this)" data-company-details="{{ $company->toJson() }}">
                                    <lord-icon src="https://cdn.lordicon.com/oclwxpmm.json" trigger="loop"
                                      style="width:16px;height:16px">
                                    </lord-icon>
                                  </a>
                                </li>
                                {{-- <li class="list-inline-item" data-bs-toggle="tooltip" data-bs-trigger="hover"
                                  data-bs-placement="top" title="Delete">
                                  <a class="remove-item-btn" href="javascript:;"
                                    data-url="{{ route('admin.companies.destroy', $company->id) }}"
                                    onclick="handleDelete(this)">
                                    <lord-icon src="https://cdn.lordicon.com/dovoajyj.json" trigger="loop"
                                      style="width:16px;height:16px">
                                    </lord-icon>
                                    </i>
                                  </a>
                                </li> --}}
                              </ul>
                            </td>
                          </tr>
                        @endforeach
                      </tbody>
                    </table>
                    <div class="noresult" style="display: none">
                      <div class="text-center">
                        <lord-icon src="https://cdn.lordicon.com/msoeawqm.json" trigger="loop"
                          colors="primary:#121331,secondary:#08a88a" style="width:75px;height:75px">
                        </lord-icon>
                        <h5 class="mt-2">Sorry! No Result Found</h5>
                        <p class="text-muted mb-0">We've searched more than 150+ companies
                          We did not find any
                          companies for you search.</p>
                      </div>
                    </div>
                  </div>

                </div>
                <x-admin.company-modal />
                <!--end add modal-->

              </div>
            </div>
            <!--end card-->
          </div>
          <!--end col-->
          {{-- <div class="col-xxl-3">
            <div class="card" id="company-view-detail">
              <div class="card-body text-center">
                <div class="position-relative d-inline-block">
                  <div class="avatar-md">
                    <div class="avatar-title bg-light rounded-circle">
                      <img src="{{ asset('assets/adminAssets/images/logo-dark.png') }}" alt="" class="avatar-xs"
                        style=" width: 3rem; height:auto !important">
                    </div>
                  </div>
                </div>
                <h5 class="mt-3 mb-1">PayU</h5>


                <ul class="list-inline mb-0">
                  <li class="list-inline-item avatar-xs">
                    <a href="javascript:void(0);" class="avatar-title bg-soft-success text-success fs-15 rounded">
                      <i class="ri-global-line"></i>
                    </a>
                  </li>
                  <li class="list-inline-item avatar-xs">
                    <a href="javascript:void(0);" class="avatar-title bg-soft-danger text-danger fs-15 rounded">
                      <i class="ri-mail-line"></i>
                    </a>
                  </li>
                  <li class="list-inline-item avatar-xs">
                    <a href="javascript:void(0);" class="avatar-title bg-soft-warning text-warning fs-15 rounded">
                      <i class="ri-question-answer-line"></i>
                    </a>
                  </li>

                </ul>
              </div>
              <div class="card-body">
                <h6 class="text-muted text-uppercase fw-semibold mb-3">Information</h6>
                <p class="text-muted mb-4">A company incurs fixed and variable costs such as the
                  purchase of raw materials, salaries and overhead, as explained by
                  AccountingTools, Inc. Business owners have the discretion to determine the
                  actions.</p>
                <div class="table-responsive table-card">
                  <table class="table table-borderless mb-0">
                    <tbody>
                      <tr>
                        <td class="fw-medium" scope="row">Industry </td>
                        <td>Fintech Industries</td>
                      </tr>
                      <tr>
                        <td class="fw-medium" scope="row">Location</td>
                        <td>Gurgaon</td>
                      </tr>
                      <tr>
                        <td class="fw-medium" scope="row">Employee</td>
                        <td>2000-2500</td>
                      </tr>

                      <tr>
                        <td class="fw-medium" scope="row">Website</td>
                        <td>
                          <a href="javascript:void(0);" class="link-primary text-decoration-underline">www.payu.com</a>
                        </td>
                      </tr>
                      <tr>
                        <td class="fw-medium" scope="row">Email</td>
                        <td>info@payu.com</td>
                      </tr>
                      <tr>
                        <td class="fw-medium" scope="row">Contact</td>
                        <td>9999999999</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <!--end card-->
          </div> --}}
          <!--end col-->
        </div>
      </div>
      <!--end modal-->

      <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasExample"
        aria-labelledby="offcanvasExampleLabel">
        <div class="offcanvas-header bg-light">
          <h5 class="offcanvas-title" id="offcanvasExampleLabel">Leads Fliters</h5>
          <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <!--end offcanvas-header-->
        <form action="#" class="d-flex flex-column justify-content-end h-100">
          <div class="offcanvas-body">
            <div class="mb-4">
              <label for="datepicker-range" class="form-label text-muted text-uppercase fw-semibold mb-3">Date</label>
              <input type="date" class="form-control" id="datepicker-range" data-provider="flatpickr"
                data-range="true" placeholder="Select date">
            </div>
            <div class="mb-4">
              <label for="country-select" class="form-label text-muted text-uppercase fw-semibold mb-3">Country</label>
              <select class="form-control" data-choices data-choices-multiple-remove="true" name="country-select"
                id="country-select" multiple>
                <option value="">Select country</option>
                <option value="Argentina">Argentina</option>
                <option value="Belgium">Belgium</option>
                <option value="Brazil" selected>Brazil</option>
                <option value="Colombia">Colombia</option>
                <option value="Denmark">Denmark</option>
                <option value="France">France</option>
                <option value="Germany">Germany</option>
                <option value="Mexico">Mexico</option>
                <option value="Russia">Russia</option>
                <option value="Spain">Spain</option>
                <option value="Syria">Syria</option>
                <option value="United Kingdom" selected>United Kingdom</option>
                <option value="United States of America">United States of
                  America</option>
              </select>
            </div>
            <div class="mb-4">
              <label for="status-select" class="form-label text-muted text-uppercase fw-semibold mb-3">Status</label>
              <div class="row g-2">
                <div class="col-lg-6">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
                    <label class="form-check-label" for="inlineCheckbox1">New Leads</label>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2">
                    <label class="form-check-label" for="inlineCheckbox2">Old Leads</label>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="inlineCheckbox3" value="option3">
                    <label class="form-check-label" for="inlineCheckbox3">Loss Leads</label>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="inlineCheckbox4" value="option4">
                    <label class="form-check-label" for="inlineCheckbox4">Follow Up</label>
                  </div>
                </div>
              </div>
            </div>
            <div class="mb-4">
              <label for="leadscore" class="form-label text-muted text-uppercase fw-semibold mb-3">Lead
                Score</label>
              <div class="row g-2 align-items-center">
                <div class="col-lg">
                  <input type="number" class="form-control" id="leadscore" placeholder="0">
                </div>
                <div class="col-lg-auto">
                  To
                </div>
                <div class="col-lg">
                  <input type="number" class="form-control" id="leadscore" placeholder="0">
                </div>
              </div>
            </div>
            <div>
              <label for="leads-tags" class="form-label text-muted text-uppercase fw-semibold mb-3">Tags</label>
              <div class="row g-3">
                <div class="col-lg-6">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="marketing" value="marketing">
                    <label class="form-check-label" for="marketing">Marketing</label>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="management" value="management">
                    <label class="form-check-label" for="management">Management</label>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="business" value="business">
                    <label class="form-check-label" for="business">Business</label>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="investing" value="investing">
                    <label class="form-check-label" for="investing">Investing</label>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="partner" value="partner">
                    <label class="form-check-label" for="partner">Partner</label>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="lead" value="lead">
                    <label class="form-check-label" for="lead">Leads</label>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="sale" value="sale">
                    <label class="form-check-label" for="sale">Sale</label>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="owner" value="owner">
                    <label class="form-check-label" for="owner">Owner</label>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="banking" value="banking">
                    <label class="form-check-label" for="banking">Banking</label>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="banking" value="banking">
                    <label class="form-check-label" for="banking">Exiting</label>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="banking" value="banking">
                    <label class="form-check-label" for="banking">Finance</label>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="banking" value="banking">
                    <label class="form-check-label" for="banking">Fashion</label>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!--end offcanvas-body-->
          <div class="offcanvas-footer border-top p-3 text-center hstack gap-2">
            <button class="btn btn-light w-100">Clear Filter</button>
            <button type="submit" class="btn btn-success w-100">Filters</button>
          </div>
          <!--end offcanvas-footer-->
        </form>
      </div>
      <!--end offcanvas-->

    </div>
    <!-- container-fluid -->
  </div>
  <!-- End Page-content -->
  <script src="{{ asset('assets/adminAssets/company.js') }}"></script>
@endsection
