@extends('admin.header')
@section('adminContent')
  <div class="page-content">
    <div class="">

      <!-- start page title -->
      <div class="row">
        <div class="col-12">
          <div class="page-title-box d-sm-flex align-items-center justify-content-between"
            style="padding: 10px 1.5rem;
                                                background-color: var(--vz-card-bg) !important;
                                                -webkit-box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
                                                box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
                                                border-bottom: 1px solid none;
                                                border-top: 1px solid none;
                                                margin: -23px -1.5rem 1.5rem -1.5rem;">
            <h4 class="mb-sm-0" style="margin-left: 106px;">All Staff</h4>

            <div class="page-title-right" style="margin-right: 106px;">
              <ol class="breadcrumb m-0">
                <li class="breadcrumb-item"><a href="javascript: void(0);">Staff</a></li>
                <li class="breadcrumb-item active">All Staff</li>
              </ol>
            </div>

          </div>
        </div>
      </div>
      <!-- end page title -->
      <div class="container-fluid">

        <div class="card">
          <div class="card-body">
            <div class="row g-2">
              <div class="col-auto">
                <a class="btn btn-info add-btn" href="{{ route('admin.company-staff.create') }}">
                  <i class="ri-add-fill me-1 align-bottom"></i> Add Company Staff
                </a>
              </div>
              {{-- <div class="col-sm-auto">
                <div class="search-box">
                  <input type="text" class="form-control"
                    placeholder="Search for name, tasks, projects or something...">
                  <i class="ri-search-line search-icon"></i>
                </div>
              </div> --}}
              <div class="col-sm-auto">
                <select class="form-control company-staff-status">
                  <option disabled selected>Status</option>
                  <option value="1">Active</option>
                  <option value="0">In Active</option>
                </select>
              </div>
              {{-- <div class="col-sm-auto">
                <select class="form-control">
                  <option disabled selected>Staff</option>
                  @foreach ($companyStaffs as $staff)
                    <option value="{{ $staff->id }}">{{ $staff->fullName }}</option>
                  @endforeach
                </select>
              </div> --}}
              <!--end col-->
              <div class="col-sm-auto ms-auto">
                <div class="list-grid-nav hstack gap-1">
                  {{-- <button type="button" id="dropdownMenuLink1" data-bs-toggle="dropdown" aria-expanded="false"
                    class="btn btn-soft-info btn-icon fs-14"><i class="ri-more-2-fill"></i></button>
                  <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink1">
                    <li><a class="dropdown-item" href="#">All</a></li>
                    <li><a class="dropdown-item" href="#">Last Week</a></li>
                    <li><a class="dropdown-item" href="#">Last Month</a></li>
                    <li><a class="dropdown-item" href="#">Last Year</a></li>
                  </ul> --}}
                  <button type="button" class="btn btn-info" data-bs-toggle="offcanvas" href="#offcanvasExample"><i
                      class="ri-filter-3-line align-bottom me-1"></i> Fliters</button>
                </div>
              </div>
              <!--end col-->
            </div>
            <!--end row-->
          </div>
        </div>


        <div class="team-list row list-view-filter">

          <div class="col-lg-12">
            <div class="card team-box">
              <div class="card-body">
                <div>
                  <div class="table-responsive table-card">
                    <table class="table align-middle" id="customerTable">

                      <tbody class="list form-check-all">
                        @foreach ($companyStaffs as $staff)
                          <tr>
                            <th scope="row">
                              <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="chk_child"
                                  value="{{ $staff->id }}">
                              </div>
                            </th>
                            <td>
                              <div class="team-profile-img">
                                <div class="avatar-lg img-thumbnail rounded-circle flex-shrink-0">
                                  <img
                                    src="@if ($staff->image && Storage::disk('appFiles')->exists("company/{$staff->image}")) {{ asset('crm/public/uploads/company') . '/' . $staff->image }} @else {{ defaultProfileImage() }} @endif"
                                    alt="{{ $staff->name }}" class="img-fluid d-block w-100 h-100 rounded-circle">
                                </div>
                                <div class="team-content">
                                  <a href="javascript:;" aria-controls="offcanvasExample">
                                    <h5 class="fs-16 mb-1">{{ $staff->FullName }} </h5>
                                  </a>
                                  <p class="text-muted mb-0">{{ $staff->department }} </p>
                                  <p class="text-muted mb-0">{{ @$staff->company->name }}</p>
                                </div>
                              </div>
                            </td>
                            <td class="name">
                              <p class="text-muted mb-0">{{ $staff->designation }}</p>
                              <p class="text-muted mb-0">{{ $staff->email }}</p>
                              <p class="text-muted mb-0">{{ $staff->phone }} </p>
                            </td>
                            <td class="name">
                              <p class="text-muted mb-0"> Branch:<br>
                                {{ Str::ucfirst($staff->branch) }}
                              </p>
                            </td>
                            <td class="name" align="center">
                              <h5 class="mb-1">{{ $staff->AssignedClaimsCount }}</h5>
                              <p class="text-muted mb-0">Assigned claims</p>
                            </td>
                            <td align="center">
                              <h5 class="mb-1">{{ $staff->ClosedClaimsCount }}</h5>
                              <p class="text-muted mb-0">Closed claims</p>
                            </td>
                            <td>
                              <ul class="list-inline hstack gap-2 mb-0">
                                <li class="list-inline-item edit">
                                  <p style="margin:0">
                                    @if ($staff->status)
                                      <a href="{{ route('admin.company-staff.toggle', $staff->id) }}"
                                        class="btn btn-sm btn-success" data-bs-toggle="tooltip" data-bs-trigger="hover"
                                        data-bs-placement="top" title="Click to disable">
                                        Enabled
                                        <lord-icon src="https://cdn.lordicon.com/hjeefwhm.json" trigger="loop"
                                          style="width:16px;height:16px">
                                        </lord-icon>
                                      </a>
                                    @else
                                      <a href="{{ route('admin.company-staff.toggle', $staff->id) }}"
                                        class="btn btn-sm btn-danger" data-bs-toggle="tooltip" data-bs-trigger="hover"
                                        data-bs-placement="top" title="Click to enable">
                                        Disabled
                                        <lord-icon src="https://cdn.lordicon.com/vfzqittk.json" trigger="loop"
                                          style="width:16px;height:16px">
                                        </lord-icon>
                                      </a>
                                    @endif
                                  </p>
                                </li>
                                {{-- <li class="list-inline-item edit" data-bs-toggle="tooltip" data-bs-trigger="hover"
                                  data-bs-placement="top" title="Assign Claim">
                                  <a href="javascript:void(0);" class="text-muted d-inline-block">
                                    <i class="ri-file-fill fs-16"></i>
                                  </a>
                                </li>
                                <li class="list-inline-item" data-bs-toggle="tooltip" data-bs-trigger="hover"
                                  data-bs-placement="top" title="View">
                                  <a href="javascript:void(0);"><i class="ri-eye-fill align-bottom text-muted"></i></a>
                                </li> --}}
                                <li class="list-inline-item" data-bs-toggle="tooltip" data-bs-trigger="hover"
                                  data-bs-placement="top" title="Edit">
                                  <a class="edit-item-btn" href="#exampleModal" data-bs-toggle="modal"
                                    onclick="setCompanyStaffInfo(this)"
                                    data-company-staff-details="{{ $staff->toJson() }}">
                                    <lord-icon src="https://cdn.lordicon.com/oclwxpmm.json" trigger="loop"
                                      style="width:16px;height:16px">
                                    </lord-icon>
                                  </a>
                                </li>
                                {{-- <li class="list-inline-item" data-bs-toggle="tooltip" data-bs-trigger="hover"
                                  data-bs-placement="top" title="Delete">
                                  <a class="remove-item-btn"
                                    data-url="{{ route('admin.company-staff.destroy', $staff->id) }}"
                                    onclick="handleDelete(this)">
                                    <lord-icon src="https://cdn.lordicon.com/dovoajyj.json" trigger="loop"
                                      style="width:16px;height:16px">
                                    </lord-icon>
                                    </i>
                                  </a>
                                </li> --}}
                              </ul>
                            </td>


                          </tr>
                        @endforeach

                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
            </div>
          </div>


          {{-- <div class="col-lg-12">
              <div class="text-center mb-3">
                <a href="javascript:void(0);" class="text-success"><i
                    class="mdi mdi-loading mdi-spin fs-20 align-middle me-2"></i> Load More </a>
              </div>
            </div> --}}
        </div>
      </div>

      <svg class="bookmark-hide">
        <symbol viewBox="0 0 24 24" stroke="currentColor" fill="var(--color-svg)" id="icon-star">
          <path stroke-width=".4"
            d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z">
          </path>
        </symbol>
      </svg>

    </div><!-- container-fluid -->
  </div><!-- End Page-content -->

  <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
    <div class="offcanvas-header bg-light">
      <h5 class="offcanvas-title" id="offcanvasExampleLabel">Employee Fliters</h5>
      <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <!--end offcanvas-header-->
    <form action="#" class="d-flex flex-column justify-content-end h-100">
      <div class="offcanvas-body">
        <div class="mb-3">
          <div class="col-lg-12">
            <div>
              <label for="serviceTax" class="form-label">Company</label>
              <select class="form-select" aria-label="Default select example">
                <option value="1">PayU Private Limited</option>
              </select>

            </div>
          </div>
        </div>
        <div class="mb-3">
          <div class="col-lg-12">
            <div>
              <label for="serviceTax" class="form-label">Branch office</label>
              <select class="form-select" aria-label="Default select example">
                <option value="1">Gurgaon</option>
                <option value="2">Noida</option>
                <option value="3">Delhi</option>
              </select>

            </div>
          </div>
        </div>
        <div class="mb-3">
          <div class="col-lg-12">
            <div>
              <label for="confirmPassword" class="form-label"> Department</label>
              <select class="form-select" aria-label="Default select example">

                <option value="1">Merchant Onboarding</option>
                <option value="2">Claim Settlements </option>
                <option value="3">Management</option>
              </select>
            </div>
          </div>
        </div>
        <div class="mb-3">
          <div class="col-lg-12">
            <div>
              <label for="vatNo" class="form-label"> Designation</label>
              <select class="form-select mb-3" aria-label="Default select example">

                <option value="1">Executive </option>
                <option value="2">Manager</option>
                <option value="3">Account Manager</option>
              </select>
            </div>
          </div>
        </div>
        <div class="mb-3">
          <div class="col-lg-12">
            <div>
              <label for="confirmPassword" class="form-label">Gender</label>
              <select class="form-select " aria-label="Default select example">

                <option value="1">Male</option>
                <option value="2">Female</option>
              </select>
            </div>
          </div>
        </div>

      </div>
      <!--end offcanvas-body-->
      <div class="offcanvas-footer border-top p-3 text-center hstack gap-2">
        <button class="btn btn-light w-100">Clear Filter</button>
        <button type="submit" class="btn btn-success w-100">Filters</button>
      </div>
      <!--end offcanvas-footer-->
    </form>
  </div>
  <!--end offcanvas-->
  <script src="{{ asset('assets/adminAssets/company-staff.js') }}"></script>
  <x-admin.company-staff-modal />
@endsection
