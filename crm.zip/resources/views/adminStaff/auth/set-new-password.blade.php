@extends('adminStaff.auth.header')
@section('adminStaffContent')
  <!-- auth page content -->
  <div class="auth-page-content">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="text-center mt-sm-5 mb-4 text-white-50">
            <div>
              <a href="{{ route('adminStaff.home') }}" class="d-inline-block auth-logo">
                <img src="{{ asset('assets/adminAssets/images/logo-dark.png') }}" alt="" height="70">
              </a>
            </div>
            <p class="mt-3 fs-15 fw-medium"> Set new staff password </p>
          </div>
        </div>
      </div>
      <!-- end row -->

      <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6 col-xl-5">
          <div class="card mt-4">

            <div class="card-body p-4">
              <div class="text-center mt-2">
                <h5 class="text-primary">Change your password</h5>
                <p class="text-muted">Set a new password to continue to PayU.</p>
              </div>
              <div class="p-2 mt-4">
                <form action="{{ route('adminStaff.set-new-password') }}" method="post">
                  @csrf
                  <input type="hidden" name="token" value="{{ $request->token }}">
                  <input type="hidden" name="email" value="{{ $request->email }}">
                  <div class="mb-2"> <label for="userpassword" class="form-label">Password <span
                        class="text-danger">*</span></label>
                    <input type="password" class="form-control" id="userpassword" placeholder="Password" required
                      name="password" minlegth="8" maxlength="30">
                  </div>
                  <div class="mb-2"> <label for="userpassword" class="form-label">Confirm Password <span
                        class="text-danger">*</span></label>
                    <input type="password" class="form-control" id="userpassword" placeholder="Confirm password"
                      required name="password_confirmation" minlegth="8" maxlength="30">
                  </div>

                  <div class="mt-4">
                    <button class="btn btn-success w-100" type="submit">Change password</button>
                  </div>


                </form>
              </div>
            </div>
            <!-- end card body -->
          </div>
          <!-- end card -->

          <div class="mt-4 text-center">
            <p class="mb-0">Don't have an account ? <a href="{{ route('register') }}"
                class="fw-semibold text-primary text-decoration-underline"> Signup </a> </p>
          </div>

        </div>
      </div>
      <!-- end row -->
    </div>
    <!-- end container -->
  </div>
  <!-- end auth page content -->
@endsection
