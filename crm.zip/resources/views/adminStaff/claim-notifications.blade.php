@extends('adminStaff.header')
@section('adminStaffContent')
  <div class="page-content">
    <div class="container-fluid">

      <!-- start page title -->
      <div class="row">
        <div class="col-12">
          <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Claim Notifications</h4>
          </div>
        </div>
      </div>
      <!-- end page title -->

      <div class="row">

        <div class="col-md-12">
          <div class="card card-height-100">
            <div class="card-header align-items-center d-flex">
              <h4 class="card-title mb-0 flex-grow-1"> Notifications </h4>

            </div><!-- end card header -->

            <div class="card-body p-0">

              <div class="align-items-center p-3 justify-content-between d-flex">
                <div class="flex-shrink-0">
                  {{-- <div class="text-muted"><span class="fw-semibold">4</span> of <span class="fw-semibold">10</span>
                    remaining</div> --}}
                </div>

              </div><!-- end card header -->

              <div data-simplebar>
                <ul class="list-group list-group-flush border-dashed px-3">

                  @forelse ($claimHistory as $history)
                    <x-claim-history-list :history="$history" :viewLink="route('adminStaff.claim.show', Crypt::encryptString($history->claim->id))" />
                  @empty
                    <li class="list-group-item ps-0">
                      <div class="d-flex align-items-start">
                        <div class="flex-grow-1 text-center">
                          <label class="form-check-label mb-0 ps-2" for="task_one">No Claim History</label>
                        </div>
                      </div>
                    </li>
                  @endforelse

                </ul><!-- end ul -->
              </div>
            </div><!-- end card body -->
          </div><!-- end card -->
          {{ $claimHistory->links() }}
        </div><!-- end col -->
      </div> <!-- end row-->





    </div>
    <!-- container-fluid -->
  </div>
  <!-- End Page-content -->
@endsection
