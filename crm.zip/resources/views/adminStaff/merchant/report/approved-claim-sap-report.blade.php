@extends('adminStaff.header')
@section('adminStaffContent')
  <div class="page-content">
    <div class="">

      <!-- start page title -->
      <div class="row">
        <div class="col-12">
          <div class="page-title-box d-sm-flex align-items-center justify-content-between"
            style="padding: 10px 1.5rem;
                        background-color: var(--vz-card-bg) !important;
                        -webkit-box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
                        box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
                        border-bottom: 1px solid none;
                        border-top: 1px solid none;
                        margin: -23px -1.5rem 1.5rem -1.5rem;">
            <h4 class="mb-sm-0" style="margin-left: 106px;">All Claims</h4>
          </div>
        </div>
      </div>
      <!-- end page title -->
      <div class="container-fluid">

        <div class="card">
          <div class="card-body">
            <div class="row g-2">
              <div class="col-sm-auto">
                <button type="button" class="btn btn-soft-success waves-effect waves-light export-claims">Export
                  Claims</button>
              </div>
              <!--end col-->
            </div>
            <!--end row-->
          </div>
        </div>

        <div class="team-list row list-view-filter">

          <div class="col-lg-12">
            <div class="card team-box">
              <div class="card-body">
                <div>

                  <div class="live-preview">
                    <div class="table-responsive">
                      <table class="table align-middle table-striped table-nowrap mb-0 data-table" id="customerTable">
                        <thead>
                          <tr>
                            <th scope="col" class=" text-center">
                              <input class="form-check-input check-all" type="checkbox" id="checkAll"
                                data-class=".claims" onchange="checkAll(this)">
                            </th>
                            <th scope="col" class=" text-center">Merchant Company</th>
                            <th scope="col" class=" text-center">Assigned To</th>
                            <th scope="col" class=" text-center">TAN</th>
                            <th scope="col" class=" text-center">SAP Code</th>
                            <th scope="col" class=" text-center">Claim Date</th>
                            <th scope="col" class=" text-center">Claim ID</th>
                            <th scope="col" class=" text-center">Asst.Year </th>
                            <th scope="col" class=" text-center">Period From/To</th>
                            <th scope="col" class=" text-center">Quarter</th>
                            <th scope="col" class=" text-center">Financial Year </th>
                            <th scope="col" class=" text-center">Total AMT Paid/Credited </th>
                            <th scope="col" class=" text-center">TDS Claim Amount </th>
                            <th scope="col" class=" text-center">Rate of TDS </th>
                            <th scope="col" class=" text-center">TDS Section</th>
                            <th scope="col" class=" text-center">Certificate</th>
                            <th scope="col" class=" text-center">Download Form </th>
                            <th scope="col" class=" text-center">Claim Status</th>
                            <th scope="col" class=" text-center">UTR Number</th>
                            <th scope="col" class=" text-center">SAP Invoice Doc No.</th>
                            <th scope="col" class=" text-center">SAP Payment Doc No.</th>
                            <th scope="col" class=" text-center">Payment Amount</th>
                            <th scope="col" class=" text-center">Payment Date</th>
                            <th scope="col" class=" text-center">Created Date</th>
                            <th scope="col" class=" text-center">Updated Date</th>
                            <th>Updated BY</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          @foreach ($claims as $claim)
                            <tr>
                              <th scope="row">
                                <div class="form-check">
                                  <input class="form-check-input claims" type="checkbox" name="claim_id[]"
                                    value="{{ $claim->id }}">
                                </div>
                              </th>
                              <td>
                                <div class="team-profile-img">
                                  <div class="avatar-lg img-thumbnail rounded-circle flex-shrink-0">
                                    <img
                                      src="@if ($claim->merchant->logo && Storage::disk('appFiles')->exists("merchant/{$claim->merchant->logo}")) {{ asset('crm/public/uploads/merchant') . '/' . $claim->merchant->logo }} @else {{ defaultProfileImage() }} @endif"
                                      alt="{{ $claim->merchant_company_name }}"
                                      class="img-fluid d-block w-100 h-100 rounded-circle">
                                  </div>
                                  <div class="team-content">
                                    <p class="text-muted mb-0">{{ $claim->merchant->company_name }}</p>
                                  </div>
                                </div>
                              </td>
                              <td class="name text-center">
                                @isset($claim->assignedStaff)
                                  {{-- <p class="text-muted mb-0">EMP ID: #{{ $claim->assignedStaff->emp_id }}</p> --}}
                                  <p class="text-muted mb-0">Name: {{ $claim->assignedStaff->full_name }}</p>
                                @endisset
                                @empty($claim->assignedStaff)
                                  <p class="badge bg-danger mb-0">Not Assigned</p>
                                @endempty
                              </td>
                              <td class="name text-center">
                                <p class="text-muted mb-0">{{ $claim->merchant->tan_number }} </p>
                              </td>
                              <td class="name text-center">
                                <p class="text-muted mb-0" style="color: #2d4187 !important;">
                                  {{ $claim->merchant->sap_code }}</p>
                              </td>
                              <td class="name text-center">{{ $claim->created_at->format('d M Y') }}</td>
                              <td class="name  text-center">
                                <p class="text-muted mb-0">
                                  <a href="{{ route('adminStaff.claim.show', Crypt::encryptString($claim->id)) }}">
                                    <span style="color: #2d4187 !important;">{{ $claim->claim_id }}</span>
                                  </a>
                                </p>
                              </td>
                              <td class="name  text-center">
                                <p class="text-muted mb-0"><span
                                    style="color: #2d4187 !important;">{{ $claim->asst_year }}</span>
                                </p>
                              </td>
                              <td class="name  text-center">
                                <p class="text-muted mb-0"><span style="color: #2d4187 !important;">
                                    {{ $claim->period_from_to }}
                                  </span>
                                </p>
                              </td>
                              <td class="name text-center">
                                <p class="text-muted mb-0"> <span
                                    style="color: #2d4187 !important;">Q{{ $claim->quarter }}</span></p>
                              </td>
                              <td class="name text-center">
                                <p class="text-muted mb-0"><span
                                    style="color: #2d4187 !important;">{{ $claim->financial_year }}</span>
                                </p>
                              </td>
                              <td class="name text-center">
                                <p class="text-muted mb-0"><span
                                    style="color: #2d4187 !important;">{{ number_format($claim->amount_credited, 2) }}</span>
                                </p>
                              </td>
                              <td class="name text-center">
                                <p class="text-muted mb-0"><span
                                    style="color: #2d4187 !important;">{{ number_format($claim->tds_claim_amount, 2) }}</span>
                                </p>
                              </td>
                              <td class="name text-center">
                                <p class="text-muted mb-0"><span
                                    style="color: #2d4187 !important;">{{ $claim->rate_of_tds }}%</span></p>
                              </td>
                              <td class="name text-center">
                                <p class="text-muted mb-0"><span
                                    style="color: #2d4187 !important;">{{ $claim->nature_of_tds }}</span></p>
                              </td>
                              <td class="name text-center">
                                <p class="text-muted mb-0"><span
                                    style="color: #2d4187 !important;">{{ $claim->certificate_no }}</span></p>
                              </td>
                              <td class="name text-center">
                                <p class="text-muted mb-0">
                                  @if ($claim->form16 && Storage::disk('appFiles')->exists("claim/{$claim->form16}"))
                                    <a href="{{ asset('crm/public/uploads/claim') . '/' . $claim->form16 }}"
                                      target="_blank">Form 16
                                      <i class="ri-download-2-line fs-17 lh-1 align-middle"></i>
                                    </a>
                                  @else
                                    N/A
                                  @endif
                                </p>
                              </td>

                              <td class="name" align="center">
                                @if ($claim->history->count() > 0)
                                  @switch($claim->history->first()->status)
                                    @case(0)
                                      <p class="badge bg-secondary mb-0">Drafted</p>
                                    @break

                                    @case(1)
                                      <p class="badge bg-primary mb-0">Submitted</p>
                                    @break

                                    @case(2)
                                      <p class="badge bg-warning mb-0">In Process</p>
                                    @break

                                    @case(3)
                                      <p class="badge bg-soft-success mb-0">Approved</p>
                                    @break

                                    @case(4)
                                      <p class="badge bg-success mb-0">Completed</p>
                                    @break

                                    @case(5)
                                      <p class="badge bg-danger mb-0">Rejected</p>
                                    @break

                                    @case(6)
                                      <p class="badge bg-soft-primary mb-0">On Hold</p>
                                    @break

                                    @default
                                      <p class="badge bg-dark mb-0">Unknown Status</p>
                                  @endswitch
                                @endif
                              </td>
                              <td class="name" align="center">
                                <p class=" mb-0" style="color: green;">
                                  {{ isset($claim->utr) ? $claim->utr : 'N/A' }}</p>
                              </td>
                              <td class="name" align="center">
                                <p class=" mb-0" style="color: green;">
                                  {{ isset($claim->sap_invoice_doc_no) ? $claim->sap_invoice_doc_no : 'N/A' }}</p>
                              </td>
                              <td class="name" align="center">
                                <p class=" mb-0" style="color: green;">
                                  {{ isset($claim->sap_payment_doc_no) ? $claim->sap_payment_doc_no : 'N/A' }}</p>
                              </td>
                              <td class="name" align="center">
                                <p class=" mb-0" style="color: green;">
                                  {{ isset($claim->amount) ? number_format($claim->amount) : 'N/A' }}</p>
                              </td>
                              <td class="name" align="center">
                                {{ isset($claim->payment_date) ? $claim->payment_date->format('d M Y') : 'N/A' }}
                              </td>
                              <td>{{ $claim->created_at->format('d M Y') }}</td>
                              <td>
                                <p class="text-muted mb-0">
                                  <span style="color: #2d4187 !important;">
                                    @if ($claim->history->count() > 0)
                                      {{ $claim->history->first()->created_at->format('d M Y') }}
                                    @else
                                      N/A
                                    @endif
                                  </span>
                                </p>
                              </td>
                              <td class="name text-center" align="center">
                                <p class="text-muted mb-0">
                                  <span style="color: #2d4187 !important;">
                                    By
                                    @if ($claim->history->count() > 0)
                                      {{ isset($claim->history->first()->updatedBy->name) ? $claim->history->first()->updatedBy->name : $claim->history->first()->updatedBy->full_name }}
                                      <br />
                                      ({{ $claim->history->first()->updatedBy->type }})
                                    @else
                                      N/A
                                    @endif
                                  </span>
                                </p>
                              </td>
                              <td>
                                <ul class="list-inline hstack gap-2 mb-0">
                                  <li class="list-inline-item" title="View">
                                    <a href="{{ route('adminStaff.claim.show', Crypt::encryptString($claim->id)) }}">
                                      <i class="ri-eye-fill align-bottom text-muted"></i>
                                    </a>
                                  </li>
                                </ul>
                              </td>
                            </tr>
                          @endforeach
                        </tbody>
                      </table>
                    </div>
                  </div>
                  </form>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>


    </div><!-- container-fluid -->
  </div><!-- End Page-content -->
  <form action="{{ route('adminStaff.approved-claims-sap-report') }}" method="post" id="approved-claim-export-form">
    @csrf
  </form>

  <script type="module" src="{{ asset('assets/adminAssets/claim.js') }}"></script>
@endsection
