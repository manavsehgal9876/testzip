@extends('adminStaff.header')
@section('adminStaffContent')
  <div class="page-content">
    <div class="">
      <div class="container-fluid">
        <div class="team-list row list-view-filter">
          <div class="col-lg-12 mt-5">
            <h5 class="mb-3">{{ $merchant->company_name }} - Representatives <a href="#"
                class="btn btn-soft-primary waves-effect waves-light mb-3" style="float:right" data-bs-toggle="modal"
                data-bs-target="#exampleModal" onclick="updateStaffInfoModal()">Add New</a></h5>
            <div class="card team-box col-sm-12">
              <div class="card-body">

                <div class="team-list grid-view-filter row">
                  @foreach ($staffs as $staff)
                    <div class="col">
                      <div class="card team-box">
                        <div class="team-cover">
                          <img src="{{ asset('assets/merchantAssets/images/small/img-9.jpg') }}" alt=""
                            class="img-fluid" />
                        </div>
                        <div class="card-body p-4">
                          <div class="row align-items-center team-row">
                            <div class="col team-settings">
                              <div class="row">
                                <div class="col">
                                  <div class="bookmark-icon flex-shrink-0 me-2">
                                    <input type="checkbox" id="favourite1" class="bookmark-input bookmark-hide">
                                    <label for="favourite1" class="btn-star">
                                      <svg width="20" height="20">
                                        <use xlink:href="#icon-star" />
                                      </svg>
                                    </label>
                                  </div>
                                </div>
                                <div class="col text-end dropdown">
                                  <a href="javascript:void(0);" id="dropdownMenuLink2" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    <i class="ri-more-fill fs-17"></i>
                                  </a>
                                  <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuLink2">
                                    <li><a class="dropdown-item" href="javascript:void(0);"><i
                                          class="ri-eye-line me-2 align-middle"></i>View</a></li>
                                    <li><a class="dropdown-item" href="javascript:void(0);"><i
                                          class="ri-star-line me-2 align-middle"></i>Favorites</a></li>
                                    <li><a class="dropdown-item" href="javascript:void(0);"><i
                                          class="ri-delete-bin-5-line me-2 align-middle"></i>Delete</a></li>
                                  </ul>
                                </div>
                              </div>
                            </div>
                            <div class="col-lg-4 col">
                              <div class="team-profile-img">
                                <div class="avatar-lg img-thumbnail rounded-circle flex-shrink-0">
                                  <img
                                    src="@if ($staff->image && Storage::disk('appFiles')->exists("merchant/{$staff->image}")) {{ asset('crm/public/uploads/merchant') . '/' . $staff->image }} @else {{ defaultProfileImage() }} @endif"
                                    alt="{{ $staff->name }}" class="img-fluid d-block rounded-circle h-100 w-100" />
                                </div>
                                <div class="team-content">
                                  <a data-bs-toggle="offcanvas" href="#offcanvasExample" aria-controls="offcanvasExample">
                                    <h5 class="fs-16 mb-1 text-center">{{ $staff->name }}</h5>
                                  </a>
                                  <p class="text-muted mb-0 text-center">{{ $staff->mobile }}</p>
                                  <p class="text-muted mb-0 text-center">{{ $staff->email }}</p>
                                  @if ($staff->status)
                                    <p class="badge bg-success mb-0 text-center">
                                      Active
                                    </p>
                                  @else
                                    <p class="badge bg-danger mb-0 text-center">
                                      Inactive
                                    </p>
                                  @endif
                                  <p class="text-muted mb-0 text-center">Joined:
                                    <span class="text-muted">{{ $staff->created_at?->format('d M, Y') }}</span>
                                  </p>
                                  @if ($staff->working)
                                    <p class="text-success mb-0 text-center">
                                      Working
                                    </p>
                                  @else
                                    <p class="text-danger mb-0 text-center">
                                      Left: {{ $staff->left_at?->format('d M, Y') }}
                                    </p>
                                  @endif
                                  @if ($staff->is_primary)
                                    <p class="text-info mb-0 text-center">
                                      Primary Staff
                                    </p>
                                  @else
                                    <p class="text-info mb-0 text-center">
                                      &nbsp;
                                    </p>
                                  @endif
                                </div>
                              </div>
                            </div>

                            <div class="col-lg-2 col">
                              <div class="text-end">
                                <a href="#" class="btn btn-soft-info view-btn mt-0" data-bs-toggle="modal"
                                  data-bs-target="#exampleModal" onclick="setStaffInfo(this)"
                                  data-staff-details="{{ $staff->toJson() }}">Update
                                  <lord-icon src="https://cdn.lordicon.com/oclwxpmm.json" trigger="loop"
                                    style="width:16px;height:16px">
                                  </lord-icon>
                                </a>

                                {{-- <a href="#" class="btn btn-soft-danger view-btn mt-2"
                                  data-url="{{ route('merchant.staff.destroy', $staff->id) }}"
                                  onclick="handleDelete(this)">Delete
                                  <lord-icon src="https://cdn.lordicon.com/dovoajyj.json" trigger="loop"
                                    style="width:16px;height:16px">
                                  </lord-icon>
                                </a> --}}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <!--end card-->
                    </div>
                  @endforeach
                  <!--end col-->
                </div>
                <!--end row-->
              </div>
            </div>
          </div>



        </div>
      </div>

      <svg class="bookmark-hide">
        <symbol viewBox="0 0 24 24" stroke="currentColor" fill="var(--color-svg)" id="icon-star">
          <path stroke-width=".4"
            d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z">
          </path>
        </symbol>
      </svg>
      <x-merchant.staff-modal :merchantId="$merchantId" />
    </div><!-- container-fluid -->
  </div><!-- End Page-content -->
  <script src="{{ asset('assets/adminStaffAssets/staff-details.js') }}"></script>
@endsection
