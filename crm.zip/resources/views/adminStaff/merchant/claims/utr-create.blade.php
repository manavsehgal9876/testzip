@extends('adminStaff.header')
@section('adminStaffContent')
  <div class="page-content">
    <div class="">

      <!-- start page title -->
      <div class="row">
        <div class="col-12">
          <div class="page-title-box d-sm-flex align-items-center justify-content-between"
            style="padding: 10px 1.5rem;
                  background-color: var(--vz-card-bg) !important;
                  -webkit-box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
                  box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
                  border-bottom: 1px solid none;
                  border-top: 1px solid none;
                  margin: -23px -1.5rem 1.5rem -1.5rem;">
            <h4 class="mb-sm-0" style="margin-left: 106px;">ADD UTR</h4>

            <div class="page-title-right" style="margin-right: 106px;">
              <ol class="breadcrumb m-0">
                <li class="breadcrumb-item"><a href="javascript:;">More</a></li>
                <li class="breadcrumb-item active">ADD UTR</li>
              </ol>
            </div>

          </div>
        </div>
      </div>
      <!-- end page title -->


      <div class="row justify-content-center">
        <div class="col-lg-6">
          <div class="card">
            <div class="card-body">
              <div class="text-center">
                <div class="row justify-content-center">
                  <div class="col-lg-9">
                    <h4 class="mt-4 fw-semibold">ADD UTR</h4>

                    <div class="mt-4">
                      <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                        data-bs-target="#exampleModal11">
                        Upload UTR by XLSX
                      </button>
                    </div>

                    <div class="row justify-content-center">
                      <lottie-player src="https://assets3.lottiefiles.com/packages/lf20_rrqimc3f.json"
                        background="transparent" speed="1" style="width: 400px; height: 400px;" loop autoplay>
                      </lottie-player>
                    </div>

                  </div>
                </div>

                <div class="row justify-content-center mt-5 mb-2">
                  <div class="col-sm-7 col-8">
                    <img src="assets/images/verification-img.png" alt="" class="img-fluid" />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!--end card-->
        </div>
        <!--end col-->
      </div>
      <!--end modal-->
      <x-admin.merchant.utr-import-modal />
      <!--end modal-->
    </div>
    <!-- container-fluid -->
  </div>
  <!-- End Page-content -->
@endsection
