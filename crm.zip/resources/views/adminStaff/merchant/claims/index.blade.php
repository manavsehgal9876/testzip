@extends('adminStaff.header')
@section('adminStaffContent')
  <div class="page-content">
    <div class="">

      <!-- start page title -->
      <div class="row">
        <div class="col-12">
          <div class="page-title-box d-sm-flex align-items-center justify-content-between"
            style="padding: 10px 1.5rem;
            background-color: var(--vz-card-bg) !important;
            -webkit-box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
            box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
            border-bottom: 1px solid none;
            border-top: 1px solid none;
            margin: -23px -1.5rem 1.5rem -1.5rem;">
            <h4 class="mb-sm-0" style="margin-left: 106px;">All Claims</h4>
          </div>
        </div>
      </div>
      <!-- end page title -->
      <div class="container-fluid">

        <div class="card">
          <div class="card-body">
            <div class="row g-2">
              <div class="col-sm-auto">
                <select class="form-control claim-status" data-type="staff">
                  <option disabled selected>Status</option>
                  <option value="">All</option>
                  <option @selected(Request('status') === '1') value="1">Submitted</option>
                  <option @selected(Request('status') === '2') value="2">In Process</option>
                  <option @selected(Request('status') === '3') value="3">Approved</option>
                  <option @selected(Request('status') === '4') value="4">Completed</option>
                  <option @selected(Request('status') === '5') value="5">Rejected</option>
                  <option @selected(Request('status') === '6') value="6">On Hold</option>
                </select>
              </div>
              <div class="col-sm-auto">
                <input type="date" class="form-control date-from" />
              </div>
              <div class="col-sm-auto">
                <input type="date" class="form-control date-till" />
              </div>
              <div class="col-sm-auto">
                <button type="button" class="btn btn-soft-primary waves-effect waves-light claim-filter">Filter</button>
              </div>
              {{-- <div class="col-sm-2">
                <button type="button" class="btn btn-soft-success waves-effect waves-light" data-bs-toggle="modal"
                  data-bs-target=".bs-example-modal-center3">Export to CSV</button>
                <div class="modal fade bs-example-modal-center3" tabindex="-1" role="dialog"
                  aria-labelledby="mySmallModalLabel" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                      <div class="modal-body text-center p-5">
                        <i class="ri-download-2-line lh-1 align-middle" style="font-size:50px;color:#0ab39c"></i>
                        <div class="mt-4">
                          <h4 class="mb-3">You are about to Export 24 Claims in CSV</h4>

                          <div class="hstack gap-2 justify-content-center">
                            <button type="button" class=" btn btn-danger" data-bs-dismiss="modal">Export</button>
                            <a href="javascript:void(0);" class="btn btn-light">Cancel</a>
                          </div>
                        </div>
                      </div>
                    </div><!-- /.modal-content -->
                  </div><!-- /.modal-dialog -->
                </div><!-- /.modal -->
              </div> --}}

              {{-- <div class="col-sm-5">
                <div class="search-box">
                  <input type="text" class="form-control" placeholder="Search By : Claim Id">
                  <i class="ri-search-line search-icon"></i>
                </div>
              </div> --}}
              <!--end col-->
              {{-- <div class="col-lg-2">

                <select class="form-select " aria-label="Default select example">
                  <option value="1">Claim Status</option>
                  <option value="1">Pending </option>
                  <option value="2">In Process</option>
                  <option value="2">Approved</option>
                  <option value="2">Completed </option>
                </select>

              </div> --}}
              {{-- <div class="col-sm-auto ms-auto">
                <div class="list-grid-nav hstack gap-1">

                  <button type="button" class="btn btn-info" data-bs-toggle="offcanvas" href="#offcanvasExample"><i
                      class="ri-filter-3-line align-bottom me-1"></i> Fliters</button>
                </div>
              </div> --}}
              <!--end col-->
            </div>
            <!--end row-->
          </div>
        </div>


        <div class="team-list row list-view-filter">

          <div class="col-lg-12">
            <div class="card team-box">
              <div class="card-body">
                <div>
                  <div class="live-preview">
                    <div class="table-responsive">
                      <table class="table align-middle table-striped table-nowrap mb-0 data-table" id="customerTable">
                        <thead>
                          <tr>
                            <th scope="col" class=" text-center">Merchant Company</th>
                            <th scope="col" class=" text-center">Assigned To</th>
                            <th scope="col" class=" text-center">TAN</th>
                            <th scope="col" class=" text-center">SAP Code</th>
                            <th scope="col" class=" text-center">Claim Date</th>
                            <th scope="col" class=" text-center">Claim ID</th>
                            <th scope="col" class=" text-center">Category</th>
                            <th scope="col" class=" text-center">Asst.Year </th>
                            <th scope="col" class=" text-center">Period From/To</th>
                            <th scope="col" class=" text-center">Quarter</th>
                            <th scope="col" class=" text-center">Financial Year </th>
                            <th scope="col" class=" text-center">Total AMT Paid/Credited </th>
                            <th scope="col" class=" text-center">TDS Claim Amount </th>
                            <th scope="col" class=" text-center">Rate of TDS </th>
                            <th scope="col" class=" text-center">TDS Section</th>
                            <th scope="col" class=" text-center">Certificate</th>
                            <th scope="col" class=" text-center">Download Form </th>
                            <th scope="col" class=" text-center">Claim Status</th>
                            <th scope="col" class=" text-center">UTR Number</th>
                            <th scope="col" class=" text-center">SAP Invoice Doc No.</th>
                            <th scope="col" class=" text-center">SAP Payment Doc No.</th>
                            <th scope="col" class=" text-center">Payment Amount</th>
                            <th scope="col" class=" text-center">Payment Date</th>
                            <th scope="col" class=" text-center">Created Date</th>
                            <th scope="col" class=" text-center">Updated At</th>
                            <th>Updated BY</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          @foreach ($claims as $claim)
                            <tr>
                              <td>
                                <div class="team-profile-img">
                                  <div class="avatar-lg img-thumbnail rounded-circle flex-shrink-0">
                                    <img
                                      src="@if ($claim->merchant->logo && Storage::disk('appFiles')->exists("merchant/{$claim->merchant->logo}")) {{ asset('crm/public/uploads/merchant') . '/' . $claim->merchant->logo }} @else {{ defaultProfileImage() }} @endif"
                                      alt="{{ $claim->merchant_company_name }}"
                                      class="img-fluid d-block w-100 h-100 rounded-circle">
                                  </div>
                                  <div class="team-content">
                                    <p class="text-muted mb-0">{{ $claim->merchant->company_name }}</p>
                                  </div>
                                </div>
                              </td>
                              <td class="name text-center">
                                @isset($claim->assignedStaff)
                                  <p class="text-muted mb-0">EMP ID: #{{ $claim->assignedStaff->emp_id }}</p>
                                  <p class="text-muted mb-0">Name: {{ $claim->assignedStaff->full_name }}</p>
                                @endisset
                              </td>
                              <td class="name text-center">
                                <p class="text-muted mb-0">{{ $claim->merchant->tan_number }} </p>
                              </td>
                              <td class="name text-center">
                                <p class="text-muted mb-0" style="color: #2d4187 !important;">
                                  {{ $claim->merchant->sap_code }}</p>
                              </td>
                              <td class="name text-center">
                                {{ $claim->created_at->format('d M Y') }}
                              </td>
                              <td class="name  text-center">
                                <p class="text-muted mb-0">
                                  <a target="_blank"
                                    href="{{ route('adminStaff.claim.show', Crypt::encryptString($claim->id)) }}">
                                    <span style="color: #2d4187 !important;">{{ $claim->claim_id }}</span>
                                  </a>
                                </p>
                              </td>
                              <td class="name  text-center">
                                <p class="text-muted mb-0"><span
                                    style="color: #2d4187 !important;">{{ $claim->category }}</span>
                                </p>
                              </td>
                              <td class="name  text-center">
                                <p class="text-muted mb-0"><span
                                    style="color: #2d4187 !important;">{{ $claim->asst_year }}</span>
                                </p>
                              </td>
                              <td class="name  text-center">
                                <p class="text-muted mb-0"><span style="color: #2d4187 !important;">
                                    {{ $claim->period_from_to }}
                                  </span>
                                </p>
                              </td>
                              <td class="name text-center">
                                <p class="text-muted mb-0"> <span
                                    style="color: #2d4187 !important;">Q{{ $claim->quarter }}</span></p>
                              </td>
                              <td class="name text-center">
                                <p class="text-muted mb-0"><span
                                    style="color: #2d4187 !important;">{{ $claim->financial_year }}</span>
                                </p>
                              </td>
                              <td class="name text-center">
                                <p class="text-muted mb-0"><span
                                    style="color: #2d4187 !important;">{{ number_format($claim->amount_credited, 2) }}</span>
                                </p>
                              </td>
                              <td class="name text-center">
                                <p class="text-muted mb-0"><span
                                    style="color: #2d4187 !important;">{{ number_format($claim->tds_claim_amount, 2) }}</span>
                                </p>
                              </td>
                              <td class="name text-center">
                                <p class="text-muted mb-0"><span
                                    style="color: #2d4187 !important;">{{ $claim->rate_of_tds }}%</span></p>
                              </td>
                              <td class="name text-center">
                                <p class="text-muted mb-0"><span
                                    style="color: #2d4187 !important;">{{ $claim->nature_of_tds }}</span></p>
                              </td>
                              <td class="name text-center">
                                <p class="text-muted mb-0"><span
                                    style="color: #2d4187 !important;">{{ $claim->certificate_no }}</span></p>
                              </td>
                              <td class="name text-center">
                                <p class="text-muted mb-0">
                                  @if ($claim->form16 && Storage::disk('appFiles')->exists("claim/{$claim->form16}"))
                                    <a href="{{ asset('crm/public/uploads/claim') . '/' . $claim->form16 }}"
                                      target="_blank">Form 16
                                      <i class="ri-download-2-line fs-17 lh-1 align-middle"></i>
                                    </a>
                                  @else
                                    N/A
                                  @endif
                                </p>
                              </td>

                              <td class="name" align="center">
                                @if ($claim->history->count() > 0)
                                  @switch($claim->history->first()->status)
                                    @case(0)
                                      <p class="badge bg-secondary mb-0">Drafted</p>
                                    @break

                                    @case(1)
                                      <p class="badge bg-primary mb-0">Submitted</p>
                                    @break

                                    @case(2)
                                      <p class="badge bg-warning mb-0">In Process</p>
                                    @break

                                    @case(3)
                                      <p class="badge bg-soft-success mb-0">Approved</p>
                                    @break

                                    @case(4)
                                      <p class="badge bg-success mb-0">Completed</p>
                                    @break

                                    @case(5)
                                      <p class="badge bg-danger mb-0">Rejected</p>
                                    @break

                                    @case(6)
                                      <p class="badge bg-soft-primary mb-0">On Hold</p>
                                    @break

                                    @default
                                      <p class="badge bg-dark mb-0">Unknown Status</p>
                                  @endswitch
                                @endif
                              </td>
                              <td class="name" align="center">
                                <p class=" mb-0" style="color: green;">
                                  {{ isset($claim->utr) ? $claim->utr : 'N/A' }}</p>
                              </td>
                              <td class="name" align="center">
                                <p class=" mb-0" style="color: green;">
                                  {{ isset($claim->sap_invoice_doc_no) ? $claim->sap_invoice_doc_no : 'N/A' }}</p>
                              </td>
                              <td class="name" align="center">
                                <p class=" mb-0" style="color: green;">
                                  {{ isset($claim->sap_payment_doc_no) ? $claim->sap_payment_doc_no : 'N/A' }}</p>
                              </td>
                              <td class="name" align="center">
                                <p class=" mb-0" style="color: green;">
                                  {{ isset($claim->amount) ? number_format($claim->amount) : 'N/A' }}</p>
                              </td>
                              <td class="name" align="center">
                                <p class=" mb-0" style="color: green;">
                                  {{ isset($claim->payment_date) ? $claim->payment_date->format('d M, Y') : 'N/A' }}
                                </p>
                              </td>
                              <td>
                                {{ $claim->created_at->format('d M Y') }}
                              </td>
                              <td>
                                @if ($claim->history->count() > 0)
                                  {{ $claim->history->first()->created_at->format('d M Y') }}
                                @else
                                  N/A
                                @endif
                              </td>
                              <td class="name text-center" align="center">
                                <p class="text-muted mb-0">
                                  <span style="color: #2d4187 !important;">
                                    By
                                    @if ($claim->history->count() > 0)
                                      @if ($claim->history->first()->updatedBy->type === 'merchant')
                                        {{ isset($claim->history->first()->updatedBy->primaryStaff->name) ? $claim->history->first()->updatedBy->primaryStaff->name : $claim->history->first()->updatedBy->full_name }}
                                      @else
                                        {{ isset($claim->history->first()->updatedBy->name) ? $claim->history->first()->updatedBy->name : $claim->history->first()->updatedBy->full_name }}
                                      @endif
                                      <br />
                                      ({{ $claim->history->first()->updatedBy->type }})
                                    @else
                                      N/A
                                    @endif
                                  </span>
                                </p>
                              </td>
                              <td>
                                <ul class="list-inline hstack gap-2 mb-0">

                                  <li class="list-inline-item" title="View">
                                    <a href="{{ route('adminStaff.claim.show', Crypt::encryptString($claim->id)) }}">
                                      <i class="ri-eye-fill align-bottom text-muted"></i>
                                    </a>
                                  </li>
                                </ul>
                              </td>
                            </tr>
                          @endforeach
                        </tbody>
                      </table>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>

        </div>
      </div>

      <svg class="bookmark-hide">
        <symbol viewBox="0 0 24 24" stroke="currentColor" fill="var(--color-svg)" id="icon-star">
          <path stroke-width=".4"
            d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z">
          </path>
        </symbol>
      </svg>

    </div><!-- container-fluid -->
  </div><!-- End Page-content -->

  <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
    <div class="offcanvas-header bg-light">
      <h5 class="offcanvas-title" id="offcanvasExampleLabel"> Fliters</h5>
      <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <!--end offcanvas-header-->
    <form action="#" class="d-flex flex-column justify-content-end h-100">
      <div class="offcanvas-body">
        <div class="mb-4">
          <div class="row">
            <div class="col-sm-6">
              <label for="datepicker-range" class="form-label text-muted text-uppercase fw-semibold mb-1">Claim
                File Date From</label>
              <input type="date" class="form-control" id="datepicker-range" data-provider="flatpickr"
                data-range="true" placeholder="Select date">
            </div>
            <div class="col-sm-6">
              <label for="datepicker-range" class="form-label text-muted text-uppercase fw-semibold mb-1">Claim
                File Date To</label>
              <input type="date" class="form-control" id="datepicker-range" data-provider="flatpickr"
                data-range="true" placeholder="Select date">
            </div>
          </div>
        </div>

        <div class="mb-4">
          <div class="row">
            <div class="col-sm-6">
              <label for="datepicker-range" class="form-label text-muted text-uppercase fw-semibold mb-1">Period
                From</label>
              <input type="text" class="form-control" id="datepicker-range" data-provider="flatpickr"
                data-range="true" placeholder="">
            </div>
            <div class="col-sm-6">
              <label for="datepicker-range" class="form-label text-muted text-uppercase fw-semibold mb-1">Period
                To</label>
              <input type="text" class="form-control" id="datepicker-range" data-provider="flatpickr"
                data-range="true" placeholder="">
            </div>
          </div>
        </div>

        <div class="mb-4">
          <label for="datepicker-range" class="form-label text-muted text-uppercase fw-semibold mb-1">Select
            Quarter</label>
          <select class="form-select " aria-label="Default select example">
            <option value="1">Quarter 1 </option>
            <option value="2">Quarter 2</option>
            <option value="2">Quarter 3</option>
            <option value="2">Quarter 4</option>
          </select>
        </div>

        <div class="mb-4">
          <div class="row">
            <div class="col-sm-6">
              <label for="datepicker-range" class="form-label text-muted text-uppercase fw-semibold mb-1">Amount
                From</label>
              <input type="text" class="form-control" id="datepicker-range" data-provider="flatpickr"
                data-range="true" placeholder="">
            </div>
            <div class="col-sm-6">
              <label for="datepicker-range" class="form-label text-muted text-uppercase fw-semibold mb-1">Amount
                To</label>
              <input type="text" class="form-control" id="datepicker-range" data-provider="flatpickr"
                data-range="true" placeholder="">
            </div>
          </div>
        </div>

        <div class="mb-4">
          <label for="datepicker-range" class="form-label text-muted text-uppercase fw-semibold mb-1">Claim
            Status</label>
          <select class="form-select " aria-label="Default select example">
            <option value="1"> In Process Claims </option>
            <option value="2"> Rejected Claims</option>
            <option value="2"> Approved Claims</option>
            <option value="2">Completed Claims</option>
          </select>
        </div>

      </div>
      <!--end offcanvas-body-->
      <div class="offcanvas-footer border-top p-3 text-center hstack gap-2">
        <button class="btn btn-light w-100">Clear Filter</button>
        <button type="submit" class="btn btn-success w-100">Filters</button>
      </div>
      <!--end offcanvas-footer-->
    </form>
  </div>
  <!--end offcanvas-->
  <script type="module" src="{{ asset('assets/adminAssets/claim.js') }}"></script>
@endsection
