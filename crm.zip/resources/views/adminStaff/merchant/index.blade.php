@extends('adminStaff.header')
@section('adminStaffContent')
  <div class="page-content">
    <div class="">

      <div class="row">
        <div class="col-12">
          <div class="page-title-box d-sm-flex align-items-center justify-content-between"
            style="padding: 10px 1.5rem;
            background-color: var(--vz-card-bg) !important;
            -webkit-box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
            box-shadow: 0 1px 2px rgb(56 65 74 / 15%);
            border-bottom: 1px solid none;
            border-top: 1px solid none;
            margin: -23px -1.5rem 1.5rem -1.5rem;">
            <h4 class="mb-sm-0" style="margin-left: 106px;">All Merchant</h4>

            <div class="page-title-right" style="margin-right: 106px;">
              <ol class="breadcrumb m-0">
                <li class="breadcrumb-item"><a href="javascript: void(0);">Merchant</a></li>
                <li class="breadcrumb-item active">All merchants</li>
              </ol>
            </div>

          </div>
        </div>
      </div>
      <!-- end page title -->
      <div class="container-fluid">

        <div class="card">
          <div class="card-body">
            <div class="row g-2">
              <div class="col-md-4">
                <form method="get" action="{{ route('adminStaff.merchants.index') }}" class="d-inline-flex">
                  <div class="search-box">
                    <input type="text" name="search" class="form-control"
                      placeholder="Search by name, tan, pan or gst...">
                    <i class="ri-search-line search-icon"></i>
                  </div>
                  <button class="btn btn-soft-primary mx-2">Filter</button>
                </form>
              </div>
              {{-- <div class="col-sm-auto">
                <select class="form-control">
                  <option disabled selected>Status</option>
                  <option>Active</option>
                  <option>In Active</option>
                </select>
              </div> --}}
              <!--end col-->
              <div class="col-sm-auto ms-auto">
                {{-- <div class="list-grid-nav hstack gap-1">
                  <button type="button" id="dropdownMenuLink1" data-bs-toggle="dropdown" aria-expanded="false"
                    class="btn btn-soft-info btn-icon fs-14"><i class="ri-more-2-fill"></i></button>
                  <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink1">
                    <li><a class="dropdown-item" href="#">All</a></li>
                    <li><a class="dropdown-item" href="#">Last Week</a></li>
                    <li><a class="dropdown-item" href="#">Last Month</a></li>
                    <li><a class="dropdown-item" href="#">Last Year</a></li>
                  </ul>
                  <button type="button" class="btn btn-info" data-bs-toggle="offcanvas" href="#offcanvasExample"><i
                      class="ri-filter-3-line align-bottom me-1"></i> Fliters</button>
                </div> --}}
              </div>
              <!--end col-->
            </div>
            <!--end row-->
          </div>
        </div>


        <div class="team-list row list-view-filter">

          <div class="col-lg-12">
            <div class="card team-box">
              <div class="card-body">
                <div>
                  <div class="table-responsive table-card border_lin0">
                    <table class="table align-middle mb-0 pb-0" id="customerTable">

                      <tbody class="list form-check-all">
                        @foreach ($merchants as $merchant)
                          <tr>
                            {{-- <th scope="row">
                              <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="chk_child" value="option1">
                              </div>
                            </th> --}}
                            <td>
                              <div class="team-profile-img">
                                <div class="avatar-lg img-thumbnail rounded-circle flex-shrink-0">
                                  <img
                                    src="@if ($merchant->logo && Storage::disk('appFiles')->exists("merchant/{$merchant->logo}")) {{ asset('crm/public/uploads/merchant') . '/' . $merchant->logo }}  @else {{ defaultProfileImage() }} @endif"
                                    alt="{{ $merchant->company_name }}"
                                    class="img-fluid d-block rounded-circle w-100 h-100">
                                </div>
                                <div class="team-content">
                                  <a href="javascript:;" aria-controls="offcanvasExample">
                                    <h5 class="fs-16 mb-1 edit-item-btn" href="#exampleModal" data-bs-toggle="modal"
                                      onclick="setMerchantInfo(this)" data-merchant-details="{{ $merchant->toJson() }}"
                                      data-path="{{ asset('crm/public/uploads/merchant') . '/' }}">
                                      {{ $merchant->company_name }} </h5>
                                  </a>
                                  <p class="text-muted mb-0">TAN: {{ $merchant->tan_number }} </p>
                                  <p class="text-muted mb-0">GST: {{ $merchant->gst_number }}</p>
                                  <p class="text-muted mb-0">PAN: {{ $merchant->pancard_number }}</p>
                                  <p class="text-muted mb-0">{{ $merchant->email }}</p>
                                  <p class="text-muted mb-0">{{ $merchant->phone }}</p>
                                  <p class="text-muted mb-0">{{ $merchant->website }}</p>
                                  <p class="text-muted mb-0">Added on: {{ $merchant->created_at->format('d, M Y') }}
                                  </p>
                                </div>
                              </div>
                            </td>
                            <td class="name">
                              <p class="text-muted mb-0">{{ $merchant->representative_name }}</p>
                              <p class="text-muted mb-0">{{ $merchant->representative_email }}</p>
                              <p class="text-muted mb-0">{{ $merchant->representative_phone }}</p>
                              <p class="text-muted mb-0">{{ $merchant->representative_designation }}</p>
                            </td>
                            <td class="name">
                              <p class="text-muted mb-0">{{ @$merchant->activeBankAccount->name }}</p>
                              <p class="text-muted mb-0">Acc No: {{ @$merchant->activeBankAccount->account_number }}
                              </p>
                              <p class="text-muted mb-0">Branch: {{ @$merchant->activeBankAccount->branch }} </p>
                              <p class="text-muted mb-0">Acc Name:
                                {{ @$merchant->activeBankAccount->acc_holder_name }}</p>
                                <p class="text-muted mb-0">IFSC:
                                {{ @$merchant->activeBankAccount->ifsc }}</p>
                            </td>
                            <td class="name" align="center">
                              <h5 class="mb-1">{{ $merchant->claimsCount }}</h5>
                              <p class="text-muted mb-0">Claims Posted</p>
                            </td>
                            <td align="center">
                              <h5 class="mb-1">{{ $merchant->closedClaimsCount }}</h5>
                              <p class="text-muted mb-0">Closed claims</p>
                            </td>
                            <td>

                              <p class="mt-2">
                                <a class="btn btn-soft-primary" href="#exampleModal" data-bs-toggle="modal"
                                  onclick="setMerchantInfo(this)" data-merchant-details="{{ $merchant->toJson() }}"
                                  data-path="{{ asset('crm/public/uploads/merchant') . '/' }}">
                                  Edit
                                </a>
                              </p>

                              <p class="mt-2">
                                <a class="btn btn-soft-success"
                                  href="{{ route('adminStaff.merchant.staff.index', ['id' => $merchant->id]) }}">
                                  Staff
                                </a>
                              </p>

                              <p class="mt-2">
                                <a class="btn btn-soft-info"
                                  href="{{ route('adminStaff.merchant.bank-details.index', ['id' => $merchant->id]) }}">
                                  Bank Acc.
                                </a>
                              </p>

                              <p class="mt-2">
                                <a class="btn btn-soft-primary" href="#mailModal" data-bs-toggle="modal"
                                  onclick="document.querySelector('.mail-merchant-id').value='{{ $merchant->id }}'"
                                  data-merchant-details="{{ $merchant->toJson() }}"
                                  data-path="{{ asset('crm/public/uploads/merchant') . '/' }}">
                                  Write Mail
                                </a>
                              </p>

                              <p @class(['mt-2', 'd-none' => isset($merchant->sap_code)]) class="mt-2">
                                <a class="btn btn-soft-danger"
                                  href="{{ route('adminStaff.merchant.sap-code-request', [$merchant->id, 'profile']) }}">
                                  Sap Code Request.
                                </a>
                              </p>

                              <p class="mt-2">
                                <a class="btn btn-soft-warning"
                                  href="{{ route('adminStaff.merchant-settlement-report', $merchant->tan_number) }}">
                                  Export Settlement Report
                                </a>
                              </p>

                              <p class="mt-2">
                                <a class="btn btn-soft-secondary"
                                  href="{{ route('adminStaff.send-merchant-settlement-report', $merchant->tan_number) }}">
                                  Send Export Settlement Report
                                </a>
                              </p>

                            </td>
                          </tr>
                        @endforeach

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            {{ $merchants->links() }}
          </div>


        </div>
      </div>

    </div><!-- container-fluid -->

  </div><!-- End Page-content -->
  <!--end offcanvas-->
  <x-admin.merchant.merchant-edit-profile-modal />
  @include('components.merchant-mail-modal')
  <script src="{{ asset('assets/adminStaffAssets/merchant.js') }}"></script>
@endsection
