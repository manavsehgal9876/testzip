@extends('adminStaff.header')
@section('adminStaffContent')
  <div class="page-content">
    <div class="container-fluid">

      <!-- start page title -->
      <div class="row">
        <div class="col-12">
          <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Staff Dashboard</h4>



          </div>
        </div>
      </div>
      <!-- end page title -->

      <div class="row">
        <div class="col-xxl-7">
          <div class="d-flex flex-column h-100">
            <div class="row h-100">
              <div class="col-12">
                <div class="card">
                  <div class="card-body p-0">
                    <div class="alert alert-warning border-0 rounded-0 m-0 d-flex align-items-center" role="alert">
                      <i data-feather="alert-triangle" class="text-warning me-2 icon-sm"></i>
                      <div class="flex-grow-1 text-truncate">
                        Hello {{ auth()->user()->full_name }}
                      </div>
                      <div class="flex-shrink-0">
                        <a href="javascript:;" class="text-reset text-decoration-underline">Last Login on :
                          {{ $lastLogin?->created_at?->format('d M, Y h:i a') }}</a>
                      </div>
                    </div>

                    <div class="row align-items-end">
                      <div class="col-sm-8">
                        <div class="p-3">
                          <p class="fs-16 lh-base">You are authorized to Read, Write and Delete the data from your panel.
                            <i class="mdi mdi-arrow-right"></i>
                          </p>
                          <div class="mt-3">
                            <a href="{{ route('merchant.logout') }}" class="btn btn-success">Logout</a>
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="px-3">
                          <img src="assets/images/logo-dark.png" class="img-fluid" alt=""
                            style="width: 100px;margin-top: -150px;margin-left: 50px;">
                        </div>
                      </div>
                    </div>
                  </div> <!-- end card-body-->
                </div>
              </div> <!-- end col-->
            </div> <!-- end row-->

            <div class="row">
              <div class="col-md-4">
                <div class="card card-animate">
                  <a href="{{ route('adminStaff.claim.index', ['status' => 4]) }}">
                    <div class="card-body">
                      <div class="d-flex justify-content-between">
                        <div>
                          <p class="fw-medium text-muted mb-0">Completed Claims</p>
                          <h2 class="mt-4 ff-secondary fw-semibold"><span class="counter-value"
                              data-target="{{ $completedClaims }}">{{ $completedClaims }}</span>
                          </h2>

                        </div>
                        <div>
                          <div class="avatar-sm flex-shrink-0">
                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                              <i data-feather="users" class="text-info"></i>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div><!-- end card body -->
                  </a>
                </div> <!-- end card-->
              </div> <!-- end col-->

              <div class="col-md-4">
                <div class="card card-animate">
                  <a href="{{ route('adminStaff.claim.index', ['status' => 2]) }}">
                    <div class="card-body">
                      <div class="d-flex justify-content-between">
                        <div>
                          <p class="fw-medium text-muted mb-0">In Process Claims </p>
                          <h2 class="mt-4 ff-secondary fw-semibold"><span class="counter-value"
                              data-target="{{ $inProcessClaims }}">{{ $inProcessClaims }}</span>
                          </h2>

                        </div>
                        <div>
                          <div class="avatar-sm flex-shrink-0">
                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                              <i data-feather="activity" class="text-info"></i>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div><!-- end card body -->
                  </a>
                </div> <!-- end card-->
              </div> <!-- end col-->

              <div class="col-md-4">
                <div class="card card-animate">
                  <a href="{{ route('adminStaff.claim.index', ['status' => 3]) }}">
                    <div class="card-body">
                      <div class="d-flex justify-content-between">
                        <div>
                          <p class="fw-medium text-muted mb-0">Approved Claims</p>
                          <h2 class="mt-4 ff-secondary fw-semibold"><span class="counter-value"
                              data-target="{{ $approvedClaims }}">{{ $approvedClaims }}</span>

                          </h2>

                        </div>
                        <div>
                          <div class="avatar-sm flex-shrink-0">
                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                              <i data-feather="clock" class="text-info"></i>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div><!-- end card body -->
                  </a>
                </div> <!-- end card-->
              </div> <!-- end col-->

              <div class="col-md-3">
                <div class="card card-animate">
                  <a href="{{ route('adminStaff.claim.index', ['status' => 1]) }}">
                    <div class="card-body">
                      <div class="d-flex justify-content-between">
                        <div>
                          <p class="fw-medium text-muted mb-0">Submitted Claims</p>
                          <h2 class="mt-4 ff-secondary fw-semibold"><span class="counter-value"
                              data-target="{{ $pendingClaims }}">{{ $pendingClaims }}</span>
                          </h2>
                        </div>
                        <div>
                          <div class="avatar-sm flex-shrink-0">
                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                              <i data-feather="external-link" class="text-info"></i>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div><!-- end card body -->
                  </a>
                </div> <!-- end card-->
              </div> <!-- end col-->

              <div class="col-md-3">
                <div class="card card-animate">
                  <a href="{{ route('adminStaff.claim.index', ['status' => 5]) }}">
                    <div class="card-body">
                      <div class="d-flex justify-content-between">
                        <div>
                          <p class="fw-medium text-muted mb-0">Rejected Claims</p>
                          <h2 class="mt-4 ff-secondary fw-semibold"><span class="counter-value"
                              data-target="{{ $pendingClaims }}">{{ $pendingClaims }}</span>
                          </h2>
                        </div>
                        <div>
                          <div class="avatar-sm flex-shrink-0">
                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                              <i data-feather="external-link" class="text-info"></i>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div><!-- end card body -->
                  </a>
                </div> <!-- end card-->
              </div> <!-- end col-->

              <div class="col-md-3">
                <div class="card card-animate">
                  <a href="{{ route('adminStaff.claim.index', ['status' => 6]) }}">
                    <div class="card-body">
                      <div class="d-flex justify-content-between">
                        <div>
                          <p class="fw-medium text-muted mb-0">On Hold Claims</p>
                          <h2 class="mt-4 ff-secondary fw-semibold"><span class="counter-value"
                              data-target="{{ $pendingClaims }}">{{ $pendingClaims }}</span>
                          </h2>
                        </div>
                        <div>
                          <div class="avatar-sm flex-shrink-0">
                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                              <i data-feather="external-link" class="text-info"></i>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div><!-- end card body -->
                  </a>
                </div> <!-- end card-->
              </div> <!-- end col-->

              <div class="col-md-3">
                <div class="card card-animate">
                  <a href="{{ route('adminStaff.claim.index') }}">
                    <div class="card-body">
                      <div class="d-flex justify-content-between">
                        <div>
                          <p class="fw-medium text-muted mb-0">Total Claims</p>
                          <h2 class="mt-4 ff-secondary fw-semibold"><span class="counter-value"
                              data-target="{{ $totalClaims }}">{{ $totalClaims }}</span>
                          </h2>
                        </div>
                        <div>
                          <div class="avatar-sm flex-shrink-0">
                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                              <i data-feather="external-link" class="text-info"></i>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div><!-- end card body -->
                  </a>
                </div> <!-- end card-->
              </div> <!-- end col-->

            </div> <!-- end row-->


          </div>
        </div> <!-- end col-->

        <div class="col-xxl-5">
          <div class="card card-height-100">
            <div class="card-header align-items-center d-flex">
              <h4 class="card-title mb-0 flex-grow-1"> Notifciations </h4>

            </div><!-- end card header -->

            <div class="card-body p-0">



              <div data-simplebar style="max-height: 350px;">
                <ul class="list-group list-group-flush border-dashed px-3">

                  @forelse ($claimHistory as $history)
                    <x-claim-history-list :history="$history" :viewLink="route('adminStaff.claim.show', Crypt::encryptString($history->claim->id))" />
                  @empty
                    <li class="list-group-item ps-0">
                      <div class="d-flex align-items-start">
                        <div class="flex-grow-1 text-center">
                          <label class="form-check-label mb-0 ps-2" for="task_one">No Claim History</label>
                        </div>
                      </div>
                    </li>
                  @endforelse


                </ul><!-- end ul -->
              </div>
              <div class="p-3">
                <a href="{{ route('adminStaff.claim-notifications') }}" class="btn btn-sm btn-success"> View All</a>
              </div>
            </div><!-- end card body -->
          </div><!-- end card -->
        </div><!-- end col -->

      </div> <!-- end row-->
    </div>
    <!-- container-fluid -->
  </div>
  <!-- End Page-content -->
@endsection
