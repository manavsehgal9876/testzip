<?php

namespace App\Http\Controllers\Admin\Merchant\Report;

use Illuminate\View\View;
use Illuminate\Http\Request;
use App\Models\Merchant\Claim;
use App\Http\Controllers\Controller;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\Claim\ApprovedClaimSapReportExport;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class ApprovedClaimSapReportController extends Controller
{
  public function show(): View
  {
    $claims = Claim::where('status', '=', 3)->get();
    return view('admin.merchant.report.approved-claim-sap-report', compact('claims'));
  }

  public function download(Request $request): BinaryFileResponse
  {
    $claims = Claim::whereIn('id', array_map('intval', $request->claimIds))->get();
    return Excel::download(new ApprovedClaimSapReportExport($claims), 'approved-claim-sap-report.xlsx');
  }
}
