<?php

namespace App\Http\Controllers\Admin\Merchant;

use App\Traits\ApiResponser;
use Illuminate\Http\Request;
use App\Models\Merchant\BankDetail;
use App\Http\Controllers\Controller;
use App\Http\Requests\Merchant\BankDetailRequest;
use App\Repositories\Merchant\BankDetailRepository;

class BankDetailController extends Controller
{
  use ApiResponser;

  public $BankDetailRepository;

  public function __construct(BankDetailRepository $BankDetailRepository)
  {
    $this->BankDetailRepository = $BankDetailRepository;
  }
  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function index(Request $request)
  {
    $bankDetails = BankDetail::where('merchant_id', (int)$request->id)->orderByDesc('id')->get();
    $anyActiveBankDetail = BankDetail::where([['merchant_id', (int)$request->id], ['status', 1]])->doesntExist();
    $merchantId = (int)$request->id;
    return view('admin.merchant.bankDetails.index', compact('bankDetails', 'anyActiveBankDetail', 'merchantId'));
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create()
  {
    //
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function store(BankDetailRequest $request)
  {
    try {
      // return new \App\Mail\Notification\NewMerchantBankAccountToAdmin([
      //   'merchantDetails' => auth()->user(),
      // ]);
      $this->BankDetailRepository->store($request);
      return redirect()->route('admin.merchant.bank-details.index', ['id' => $request->merchant_id])->with('success', 'Bank details created successfully');
    } catch (\Throwable $th) {
      dd($th);
    }
  }

  /**
   * Display the specified resource.
   *
   * @param  \App\Models\Merchant\BankDetail  $bankDetail
   * @return \Illuminate\Http\Response
   */
  public function show(BankDetail $bankDetail)
  {
    return $this->successResponse($bankDetail);
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  \App\Models\Merchant\BankDetail  $bankDetail
   * @return \Illuminate\Http\Response
   */
  public function edit(BankDetail $bankDetail)
  {
    //
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  \App\Models\Merchant\BankDetail  $bankDetail
   * @return \Illuminate\Http\Response
   */
  public function update(BankDetailRequest $request, BankDetail $bankDetail)
  {
    try {
      $this->BankDetailRepository->update($request, $bankDetail->id);
      return redirect()->route('admin.merchant.bank-details.index', ['id' => $bankDetail->merchant_id])->with('success', 'Bank details updated successfully');
    } catch (\Throwable $th) {
      dd($th);
    }
  }

  public function toggleStatus(int $id)
  {
    try {
      $response = $this->BankDetailRepository->toggleStatus($id);
      return redirect()->route('admin.merchant.bank-details.index', ['id' => $response->merchant_id])->with('success', 'Bank details status updated successfully');
    } catch (\Throwable $th) {
      dd($th);
    }
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  \App\Models\Merchant\BankDetail  $bankDetail
   * @return \Illuminate\Http\Response
   */
  public function destroy(BankDetail $bankDetail)
  {
    try {
      $this->BankDetailRepository->destroy($bankDetail->id);
      return redirect()->route('admin.merchant.bank-details.index', ['id' => $bankDetail->merchant_id])->with('success', 'Bank details deleted successfully');
    } catch (\Throwable $th) {
      dd($th);
    }
  }
}
