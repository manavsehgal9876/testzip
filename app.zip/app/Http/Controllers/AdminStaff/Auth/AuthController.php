<?php

namespace App\Http\Controllers\AdminStaff\Auth;

use App\Models\User;
use Illuminate\View\View;
use App\Actions\LogoutAll;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Models\Merchant\Claim;
use App\Actions\UpdateLastLoginDate;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Models\Merchant\ClaimHistory;
use Illuminate\Support\Facades\Password;
use Illuminate\Auth\Notifications\ResetPassword;
use App\Http\Requests\AdminStaff\Auth\LoginRequest;

class AuthController extends Controller
{

  public function dashboard(): View
  {
    $lastLogin = auth()->user()->loginHistories()->latest()->first();

    if (auth()->user()->loginHistories()->count() > 1)
      $lastLogin = auth()->user()->loginHistories()->latest()->skip(1)->first();

    $onHoldClaims = Claim::where([['status', '=', 6], ['staff_id', '=', auth()->user()->id]])->count();
    $rejectedClaims = Claim::where([['status', '=', 5], ['staff_id', '=', auth()->user()->id]])->count();
    $completedClaims = Claim::where([['status', '=', 4], ['staff_id', '=', auth()->user()->id]])->count();
    $inProcessClaims = Claim::where([['status', '=', 2], ['staff_id', '=', auth()->user()->id]])->count();
    $approvedClaims = Claim::where([['status', '=', 3], ['staff_id', '=', auth()->user()->id]])->count();
    $pendingClaims = Claim::where([['status', '=', 1], ['staff_id', '=', auth()->user()->id]])->count();
    $draftedClaims = Claim::where([['status', '=', 0], ['staff_id', '=', auth()->user()->id]])->count();
    $totalClaims = Claim::where([['staff_id', '=', auth()->user()->id]])->count();

    $claimHistory = ClaimHistory::whereHas('claim', function ($query) {
      $query->where('staff_id', auth()->user()->id);
    })
      ->latest()
      ->limit(50)
      ->get();

    return view('adminStaff.dashboard', compact('lastLogin', 'onHoldClaims', 'rejectedClaims', 'completedClaims', 'inProcessClaims', 'approvedClaims', 'pendingClaims', 'draftedClaims', 'totalClaims', 'claimHistory'));
  }

  public function login(LoginRequest $request)
  {
    LogoutAll::run();

    if (!Auth::guard('company_staff')->attempt($request->only('email', 'password'), $request->boolean('remember')))
      return redirect()->back()->withErrors('Invalid email or password');

    UpdateLastLoginDate::run(Auth::guard('company_staff')->user()->id, Auth::guard('company_staff')->user()->type);

    return redirect()->route('adminStaff.dashboard')->with('success', 'You are logged in successfully');
  }

  public function forgotPassword(Request $request)
  {
    $request->validate([
      'email' => 'required|email|max:100|exists:company_staff',
    ]);

    ResetPassword::createUrlUsing(function ($user, string $token) {
      return route('adminStaff.password.reset', ['token' => $token, 'email' => $user->email]);
    });

    $status = Password::broker('company_staff')->sendResetLink(
      $request->only('email')
    );

    return $status == Password::RESET_LINK_SENT
      ? back()->withErrors(__($status))
      : back()->withInput($request->only('email'))
      ->withErrors(__($status));
  }

  public function resetPasswordView(Request $request)
  {
    return view('adminStaff.auth.set-new-password', ['request' => $request]);
  }

  public function setNewPassword(Request $request)
  {

    $request->validate([
      'token' => 'required',
      'email' => 'required|email',
      'password' => ['required', 'confirmed', 'min:6', 'max:30'],
    ]);

    // Here we will attempt to reset the user's password. If it is successful we
    // will update the password on an actual user model and persist it to the
    // database. Otherwise we will parse the error and return the response.
    $status = Password::broker('company_staff')->reset(
      $request->only('email', 'password', 'password_confirmation', 'token'),
      function ($user) use ($request) {
        $user->forceFill([
          'password' => $request->password,
          'remember_token' => Str::random(60),
        ])->save();
      }
    );

    // If the password was successfully reset, we will redirect the user back to
    // the application's home authenticated view. If there is an error we can
    // redirect them back to where they came from with their error message.
    if ($status == Password::PASSWORD_RESET) {
      return redirect()->route('adminStaff.login')->with('success', __($status));
    }

    return back()->withErrors([
      'email' => [trans($status)],
    ]);
  }

  public function logout(Request $request)
  {
    Auth::guard('company_staff')->logout();

    $request->session()->invalidate();

    $request->session()->regenerateToken();

    return redirect()->route('adminStaff.home');
  }
}
