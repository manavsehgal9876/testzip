<?php

namespace App\Http\Controllers\AdminStaff\Merchant;

use Illuminate\View\View;
use App\Http\Controllers\Controller;
use App\Imports\SapCodeUpdateImport;
use Maatwebsite\Excel\Facades\Excel;
use App\Http\Requests\ExcelFileRequest;

class SapCodeUploaderController extends Controller
{
  public function create(): View
  {
    return view('adminStaff.merchant.upload-sap-code');
  }

  public function import(ExcelFileRequest $request)
  {
    try {
      Excel::import(new SapCodeUpdateImport, $request->excelSheet);
      return back()->with('success', 'Sap code of merchants have been updated successfully.');
    } catch (\Throwable $th) {
      dd($th);
    }
  }
}
