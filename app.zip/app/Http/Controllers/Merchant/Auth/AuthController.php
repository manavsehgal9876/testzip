<?php

namespace App\Http\Controllers\Merchant\Auth;

use Carbon\Carbon;
use App\Models\User;
use Illuminate\View\View;
use App\Actions\LogoutAll;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Models\Merchant\Staff;
use App\Models\PasswordHistory;
use Illuminate\Support\Facades\DB;
use App\Actions\UpdateLastLoginDate;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use App\Models\Merchant\ClaimHistory;
use App\Mail\MerchantPasswordResetMail;
use Illuminate\Support\Facades\Password;
use App\Repositories\Merchant\StaffRepository;
use App\Http\Requests\Merchant\Auth\LoginRequest;
use App\Http\Requests\Merchant\Auth\RegisterRequest;
use App\Http\Requests\Merchant\SetNewPasswordRequest;

class AuthController extends Controller
{
  public function patch()
  {
    // \Artisan::call('optimize:clear');
    // \Artisan::call('config:cache');
  }

  public function dashboard(): View
  {
    // $this->patch();
    $lastLogin = auth()->user()->loginHistories()->latest()->first();

    if (auth()->user()->loginHistories()->count() > 1)
      $lastLogin = auth()->user()->loginHistories()->latest()->skip(1)->first();

    $claimHistory = ClaimHistory::whereHas('claim', function ($query) {
      $query->where('merchant_id', auth()->user()->id);
    })
      ->latest()
      ->limit(50)
      ->get();
    return view('merchant.dashboard', compact('lastLogin', 'claimHistory'));
  }

  public function register(RegisterRequest $request, StaffRepository $StaffRepository)
  {
    try {
      $user = User::create($request->only('company_name', 'password', 'tan_number'));
      Auth::login($user);
      $request->merge(['is_primary' => true]);
      $StaffRepository->store($request);
      UpdateLastLoginDate::run($user->id, 'merchant');
      return redirect()->route('merchant.dashboard')->with('success', 'You are registered successfully');
    } catch (\Throwable $th) {
      dd($th);
    }
  }

  public function login(LoginRequest $request)
  {
    LogoutAll::run();

    if (!Auth::attempt($request->only('tan_number', 'password'), $request->boolean('remember')))
      return redirect()->back()->withErrors('Invalid tan number or password');

    UpdateLastLoginDate::run(auth()->user()->id, auth()->user()->type);

    return redirect()->route('merchant.dashboard')->with('success', 'You are logged in successfully');
  }

  public function forgotPassword(Request $request)
  {
    if (!User::where('tan_number', $request->tan_number)->first()->primaryStaff()->exists())
      return redirect()->back()->withErrors('No primary staff found for this tan number');

    $email = User::where('tan_number', $request->tan_number)->first()->primaryStaff->email;
    $merchantCompanyName = User::where('tan_number', $request->tan_number)->first()->company_name;
    $token = Str::random(64);

    DB::table('password_resets')->insert([
      'email' => $email,
      'token' => $token,
      'created_at' => Carbon::now()
    ]);

    Mail::to($email)->send(new MerchantPasswordResetMail(['token' => $token, 'staffEmail' => $email, 'merchantTan' => $request->tan_number, 'merchantCompanyName' => $merchantCompanyName]));

    return back()->with('success', "Password reset link has been sent to this {$email}");
  }

  public function resetPasswordView(Request $request)
  {
    return view('merchant.auth.set-new-password', ['request' => $request]);
  }

  public function setNewPassword(SetNewPasswordRequest $request)
  {
    User::where('tan_number', $request->merchant_tan)->update(['password' => Hash::make($request->password)]);

    DB::table('password_resets')->where(['email' => $request->staff_email])->delete();

    PasswordHistory::create([
      'user_id' => User::where('tan_number', $request->merchant_tan)->first()->id,
      'password' => $request->password
    ]);

    return redirect()->route('login')->with('success', 'Password has been successfully updated!');
  }

  public function logout(Request $request)
  {
    Auth::guard('web')->logout();

    $request->session()->invalidate();

    $request->session()->regenerateToken();

    return redirect()->route('home');
  }
}
