<?php

namespace App\Http\Controllers\Merchant;

use App\Traits\ApiResponser;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Merchant\LTDCCollection;
use App\Actions\Merchant\Claim\GetLTDCInfo;
use App\Actions\Merchant\Claim\FormSixteenPDFParser;
use App\Actions\Merchant\LTDCandForm26ASCalculations\CalculateLtdcAndForm26;
use App\Models\Merchant\Claim;

class FormSixteenController extends Controller
{
  use ApiResponser;

  private static string $payuPan = 'AAJCS9091D';
  /**
   * Handle the incoming request.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function __invoke(Request $request)
  {
    try {
      $file = $request->form16_file;
      $filePath = $file->path();
      $pdfResponse = FormSixteenPDFParser::run($filePath);

      $claim = Claim::where('certificate_no', '=', $pdfResponse['certificateNumber'])->first();

      if (Claim::where('certificate_no', '=', $pdfResponse['certificateNumber'])->exists() && $claim->status !== 5)
        return $this->errorResponse([], "Claim of the same period has already been processed in the system.");

      if (self::$payuPan !== $pdfResponse['payuPanNumber'])
        return $this->errorResponse([], "This form 16 doesn't belongs to Payu.");

      LTDCCollection::where([['tan_number', '=', $pdfResponse['tanNumber']], ['financial_year', '=', $pdfResponse['financialYear']]])->delete();

      CalculateLtdcAndForm26::run($pdfResponse['tanNumber'], $pdfResponse['financialYear'], explode('-', $pdfResponse['financialYear'])[0], $pdfResponse['quarter']);

      $pdfResponse['ltdcInfo'] = GetLTDCInfo::run($pdfResponse['tanNumber'], $pdfResponse['assessmentYear'], $pdfResponse['quarter']);

      return $this->successResponse(compact('pdfResponse'), 'Form 16 PDF Parsed Successfully');
    } catch (\Throwable $th) {
      return $this->errorResponse([], "Data cannot be retreived from this format for Form16A. Kindly upload the original version as downloaded from Traces website.", 409);
    }
  }
}
