<?php

namespace App\Http\Controllers\Merchant;

use Illuminate\View\View;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Models\Merchant\LTDC;
use App\Models\Admin\Form26AS;
use App\Models\Merchant\Claim;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Mail;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Crypt;
use App\Http\Requests\Merchant\ClaimRequest;
use App\Repositories\Merchant\ClaimRepository;
use App\Mail\Merchant\Claim\NotifyStaffOfClaimResubmission;

class ClaimController extends Controller
{

  public function __construct(private ClaimRepository $ClaimRepository)
  {
    $this->middleware(['EnsureBankAccountIsAddedAndActive', 'CheckIfMerchantProfileIsCompleted']);
  }

  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function index(Request $request): View
  {
    $claims = Claim::orderByDesc('updated_at')->where('merchant_id', auth()->user()->id);

    if (isset($request->status))
      $claims = $claims->where([['status', '=', (int)$request->status]]);

    $claims = $claims->get();

    return view('merchant.claims.index', compact('claims'));
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\View\View
   */
  public function create(): View
  {
    $randomStr = Str::random(30);
    session(['randomString' => $randomStr]);
    return view('merchant.claims.create', compact('randomStr'));
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\View\View
   */
  public function createManually()/* : View | RedirectResponse */
  {
    if (!isset(request()->key) || request()->key !== session('randomString'))
      return back()->withErrors('You are not allowed to access this resource.');

    return view('merchant.claims.manual-create');
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function store(ClaimRequest $request): RedirectResponse
  {
    try {
      $response = $this->ClaimRepository->store($request);

      if (!$response)
        return redirect()->route('merchant.claim.create')->withErrors('Claim with the same claim ID already exists!')->withInput($request->all());

      return redirect()->route('merchant.claim.create')->with('success', 'Claim created successfully');
    } catch (\Throwable $th) {
      return redirect()->route('merchant.claim.create')->withErrors($th->getMessage())->withInput($request->all());
    }
  }
  /**
   * Display the specified resource.
   *
   * @param  \App\Models\Merchant\Claim  $claim
   * @return \Illuminate\Http\Response
   */
  public function show(string $id): View
  {
    $claim = Claim::findOrFail(Crypt::decryptString($id));
    $route = route('merchant.claim.update', $claim->id);
    $form26AS = Form26AS::where([['deductor_tan', '=', $claim->tan_number], ['financial_year', '=', $claim->financial_year], ['quarter', '=', $claim->quarter]])->get();
    $grandTotalOfForm26AS = array_sum(array_column($form26AS->toArray(), 'total_amount_paid'));
    $grandTotalOfTds = array_sum(array_column($form26AS->toArray(), 'total_tax_deducted'));
    $ltdcs = LTDC::where([['tan_number', '=', $claim->tan_number], ['financial_year', '=', $claim->financial_year]])->get();

    return view('merchant.claims.show', compact('claim', 'route', 'form26AS', 'grandTotalOfForm26AS', 'grandTotalOfTds', 'ltdcs'));
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  \App\Models\Merchant\Claim  $claim
   * @return \Illuminate\Http\Response
   */
  public function edit(Claim $claim)
  {
    //
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  \App\Models\Merchant\Claim  $claim
   * @return \Illuminate\Http\Response
   */
  public function update(ClaimRequest $request, Claim $claim): RedirectResponse
  {
    try {
      $this->ClaimRepository->update($request, $claim->id);

      if ($claim->status === 5)
        Mail::to($claim->assignedStaff->email)->send(new NotifyStaffOfClaimResubmission($claim));

      return redirect()->route('merchant.claim.show', Crypt::encryptString($claim->id))->with('success', 'Claim updated successfully');
    } catch (\Throwable $th) {
      return back()->withErrors($th->getMessage())->withInput($request->all());
    }
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  \App\Models\Merchant\Claim  $claim
   * @return \Illuminate\Http\Response
   */
  public function destroy(Claim $claim)
  {
    //
  }
}
