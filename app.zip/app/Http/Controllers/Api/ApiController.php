<?php

namespace App\Http\Controllers\Api;

use App\Traits\ApiResponser;
use App\Http\Controllers\Controller;

class ApiController extends Controller
{
  use ApiResponser;
}
