<?php

namespace App\Http\Controllers;

use App\Models\Extension\City;
use App\Models\Extension\State;
use Illuminate\Http\JsonResponse;
use App\Http\Resources\CityResource;
use App\Http\Resources\StateResource;
use App\Http\Resources\CountryResource;
use App\Http\Controllers\Api\ApiController;

class GlobalAjaxController extends ApiController
{
  public function getCountries(): JsonResponse
  {
    return $this->successResponse(CountryResource::collection(getCountries()));
  }

  public function getStates(int $countryId): JsonResponse
  {
    return $this->successResponse(StateResource::collection(State::where('country_id', $countryId)->orderBy('name')->get()));
  }

  public function getCities(int $stateId): JsonResponse
  {
    return $this->successResponse(CityResource::collection(City::where('state_id', $stateId)->orderBy('name')->get()));
  }
}
