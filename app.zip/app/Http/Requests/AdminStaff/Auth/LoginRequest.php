<?php

namespace App\Http\Requests\AdminStaff\Auth;

use Illuminate\Validation\Rules\Password;
use Illuminate\Foundation\Http\FormRequest;

class LoginRequest extends FormRequest
{
  /**
   * Determine if the user is authorized to make this request.
   *
   * @return bool
   */
  public function authorize()
  {
    return true;
  }

  /**
   * Get the validation rules that apply to the request.
   *
   * @return array<string, mixed>
   */
  public function rules()
  {
    return [
      'email' => ['required', 'email', 'max:100', 'exists:company_staff'],
      'password' => ['required', 'max:30', Password::min(8)->numbers()->letters()->symbols()->uncompromised()],
    ];
  }

  public function messages()
  {
    return [
      'email.exists' => 'Email or password is icorrect.',
    ];
  }
}
