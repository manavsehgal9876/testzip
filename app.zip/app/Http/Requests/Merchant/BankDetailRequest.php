<?php

namespace App\Http\Requests\Merchant;

use Illuminate\Foundation\Http\FormRequest;

class BankDetailRequest extends FormRequest
{
  /**
   * Determine if the user is authorized to make this request.
   *
   * @return bool
   */
  public function authorize()
  {
    return true;
  }

  /**
   * Get the validation rules that apply to the request.
   *
   * @return array<string, mixed>
   */
  public function rules()
  {
    $id = (app('request')->segment(1) === 'admin' || app('request')->segment(1) === 'staff') ? app('request')->segment(4) : app('request')->segment(3);

    return [
      'merchant_id' => ['sometimes', 'integer', 'exists:users,id'],
      'name' => ['required', 'regex:/^[a-zA-Z0-9\s]+$/', 'max:100'],
      'branch' => ['required', 'string', 'max:100'],
      'ifsc' => ['required', 'alpha_num', 'min:11'],
      'acc_holder_name' => ['required', 'regex:/^[a-zA-Z0-9\s]+$/', 'max:100'],
      'account_number' => ['required', 'string', 'max:50', 'unique:App\Models\Merchant\BankDetail,account_number,' . $id],
      'cheque' => ['required', 'mimes:jpeg,png,jpg,docx,doc,pdf', 'max:1024'],
    ];
  }

  public function messages()
  {
    return [
      'name.regex' => 'Name must be alphanumeric only',
      'branch.regex' => 'Branch must be alphanumeric only',
      'ifsc.regex' => 'IFSC code must be alphanumeric only',
      'acc_holder_name.regex' => 'Account holder name must be alphanumeric only',
    ];
  }
}
