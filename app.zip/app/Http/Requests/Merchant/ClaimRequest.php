<?php

namespace App\Http\Requests\Merchant;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Validator;

class ClaimRequest extends FormRequest
{
  /**
   * Determine if the user is authorized to make this request.
   *
   * @return bool
   */
  public function authorize()
  {
    return true;
  }

  /**
   * Get the validation rules that apply to the request.
   *
   * @return array<string, mixed>
   */

  public function withValidator(Validator $validator)
  {
    if (auth()->user()->type === 'merchant' && app('request')->segment(3) === null) {
      $validator->addRules(['bank_id' => 'required', 'exists:App\Models\Merchant\BankDetail,id']);
    }
  }

  public function rules()
  {
    return [
      'form16_file' => ['nullable', 'mimes:pdf', 'max:1024'],
      'asst_year' => ['required'],
      'period_from_to' => ['required'],
      'quarter' => ['required', 'integer'],
      'financial_year' => ['required'],
      // 'pan_number' => ['nullable', 'alpha_num', 'max:10'],
      'amount_credited' => ['required', 'numeric'],
      'rate_of_tds' => ['required', 'numeric'],
      'nature_of_tds' => ['required'],
      'certificate_no' => ['required', 'string', 'max:100'],
      'last_updated_on' => ['required', 'date'],
      'tds_claim_amount' => ['required', 'numeric'],
      'ltdc' => ['nullable', 'string', 'max:100'],
      'ltdc_total_limit' => ['nullable', 'numeric'],
      'ltdc_rate' => ['nullable', 'numeric'],
      'tdc_limit' => ['nullable', 'numeric'],
      'status' => ['required'],
      'claim_document_status' => ['nullable'],
      'attachment_file' => ['nullable', 'mimes:pdf,jpg,jpeg,webp,png,doc,docx,xlsx,xls,csv', 'max:1024'],
      'remark' => ['nullable', 'max:200', 'string'],
    ];
  }
}
