<?php

namespace App\Http\Requests\Merchant;

use Illuminate\Validation\Rules\Password;
use Illuminate\Foundation\Http\FormRequest;

class SetNewPasswordRequest extends FormRequest
{
  /**
   * Determine if the user is authorized to make this request.
   *
   * @return bool
   */
  public function authorize()
  {
    return true;
  }

  /**
   * Get the validation rules that apply to the request.
   *
   * @return array<string, mixed>
   */
  public function rules()
  {
    return [
      'merchant_tan' => 'required|alpha_num|max:10|min:10|exists:users,tan_number',
      'staff_email' => 'required|email|exists:staff,email',
      'token' => 'required|exists:password_resets,token',
      'password' => [
        'required', 'confirmed', 'min:8', 'max:30',
        Password::min(8)->numbers()->letters()->symbols()->uncompromised()
      ],
    ];
  }
}
