<?php

namespace App\Http\Requests\Admin\Company;

use Illuminate\Validation\Rules\Password;
use Illuminate\Foundation\Http\FormRequest;

class CompanyStaffRequest extends FormRequest
{
  /**
   * Determine if the user is authorized to make this request.
   *
   * @return bool
   */
  public function authorize()
  {
    return true;
  }

  /**
   * Get the validation rules that apply to the request.
   *
   * @return array<string, mixed>
   */
  public function rules()
  {
    return [
      'emp_id' => ['nullable', 'string', 'max:20'],
      'first_name' => ['required', 'regex:/^[a-zA-Z0-9\s]+$/', 'max:50'],
      'last_name' => ['required', 'regex:/^[a-zA-Z0-9\s]+$/', 'max:50'],
      'email' => ['required', 'string', 'email', 'max:255', 'unique:App\Models\Admin\Company\CompanyStaff,email,' . app('request')->segment(3)],
      'phone' => ['nullable', 'digits:10', 'unique:App\Models\Admin\Company\CompanyStaff,phone,' . app('request')->segment(3)],
      'assign_entity' => ['required', 'exists:App\Models\Admin\Company\Company,id'],
      'department' => ['nullable', 'string', 'max:100'],
      'desgination' => ['nullable', 'string', 'max:100'],
      'branch' => ['nullable', 'string', 'max:100'],
      'photo' => ['nullable', 'mimes:jpeg,png,jpg,webp,gif', 'max:1024'],
      'password' => ['sometimes', 'max:30', Password::min(8)->numbers()->letters()->symbols()->uncompromised()],
    ];
  }
  // messages

  public function messages()
  {
    return [
      'first_name.regex' => 'First name must be alphanumeric only',
      'last_name.regex' => 'Last name must be alphanumeric only',
    ];
  }
}
