<?php

namespace App\Http\Middleware\Merchant;

use Closure;
use Carbon\Carbon;
use App\Models\User;
use Illuminate\Http\Request;
use App\Models\PasswordHistory;

class CheckPasswordFrequency
{
  /**
   * Handle an incoming request.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
   * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
   */
  public function handle(Request $request, Closure $next)
  {
    $request->validate(['tan_number' => ['required', 'string', 'alpha_num', 'max:10', 'exists:App\Models\User,tan_number']]);

    $merchant = User::where('tan_number', $request->tan_number)->first();
    $passwordHistoryCount = PasswordHistory::where('user_id', $merchant->id)->whereDate('created_at', Carbon::today())->count();

    if ($passwordHistoryCount > 3)
      return back()->withErrors('You have reached the maximum number of password changes. Please contact the administrator.');

    return $next($request);
  }
}
