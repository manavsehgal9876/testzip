<?php

namespace App\Http\Middleware;

use Closure;
use Carbon\Carbon;
use Illuminate\Support\Str;
use App\Traits\ApiResponser;
use Illuminate\Http\Request;
use App\Models\Mentor\Mentor;

class CheckIfMentorAvailable
{
  use ApiResponser;
  /**
   * Handle an incoming request.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
   * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
   */
  public function handle(Request $request, Closure $next)
  {
    try {
      $mentor = Mentor::findOrFail($request->mentor_id);
      $dayOfWeek = Str::lower(Carbon::parse($request->date)->format('l'));
      $appointmentRequestTime = Carbon::parse($request->time);
      $availableTimeFrom = Carbon::parse($mentor->time_from);
      $availableTimeTill = Carbon::createFromTimeString($mentor->time_from)->addDay();

      if (!$mentor->{$dayOfWeek} || !$appointmentRequestTime->between($availableTimeFrom, $availableTimeTill))
        return $this->errorResponse($mentor->name . ' is not available for the given date or time');

      return $next($request);
    } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $th) {
      return $this->errorResponse('No mentor found with the given mentor id.');
    } catch (\Exception $th) {
      return $this->errorResponse($th->getMessage());
    }
  }
}
