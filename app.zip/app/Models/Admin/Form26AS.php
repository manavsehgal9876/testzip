<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Form26AS extends Model
{
  use HasFactory;

  protected $table = 'form_twenty_six_a_s';

  protected $guarded = ['id'];

  protected $casts = [
    'transaction_date' => 'date',
    'date_of_booking' => 'date',
  ];
}
