<?php

namespace App\Models\Admin\Company;

use App\Models\Extension\City;
use App\Models\Extension\State;
use App\Models\Extension\Country;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Company extends Model
{
  use HasFactory;

  protected $guarded = ['id'];

  protected $casts = [
    'dob' => 'date',
  ];

  public function myCountry()
  {
    return $this->belongsTo(Country::class, 'country');
  }

  public function myState()
  {
    return $this->belongsTo(State::class, 'state');
  }

  public function myCity()
  {
    return $this->belongsTo(City::class, 'city');
  }
}
