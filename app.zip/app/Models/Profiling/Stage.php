<?php

namespace App\Models\Profiling;

use App\Models\Profiling\Tag;
use App\Models\Profiling\Question;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Stage extends Model
{
  use HasFactory;

  protected $table = 'cpr_stages';

  protected $guarded = ['id'];


  public function questions()
  {
    return $this->belongsToMany(Question::class, 'cpr_stage_mapped_questions', 'stage_id', 'question_id');
  }

  public function children()
  {
    return $this->hasMany(Stage::class, 'parent_id')->with('children');
  }

  public function tags()
  {
    return $this->belongsToMany(Tag::class, 'cpr_stage_mapped_tags', 'stage_id', 'tag_id');
  }

}
