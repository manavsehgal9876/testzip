<?php

namespace App\Models\Profiling;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Casts\Attribute;

class QuestionOption extends Model
{
  use HasFactory;

  protected $table = 'cpr_question_options';

  protected $guarded = ['id'];

  public function question()
  {
    return $this->hasOne(Question::class, 'id', 'question_id');
  }

  protected function isItSelected(): Attribute
  {
    if (auth()->check())
      if (in_array($this->id, auth()->user()->answers->pluck('id')->toArray()))
        return new Attribute(
          get: fn () => true,
        );

    return new Attribute(
      get: fn () => false,
    );
  }
}
