<?php

namespace App\Models\Merchant;

use App\Models\User;
use App\Models\Admin;
use App\Models\Merchant\Claim;
use Illuminate\Database\Eloquent\Model;
use App\Models\Admin\Company\CompanyStaff;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ClaimHistory extends Model
{
  use HasFactory;

  protected $guarded = ['id'];

  public function claim()
  {
    return $this->belongsTo(Claim::class);
  }

  public function updatedBy()
  {
    switch ($this->updated_by_role) {
      case 'merchant':
        return $this->belongsTo(User::class, 'updated_by');
        break;
      case 'Admin':
        return $this->belongsTo(Admin::class, 'updated_by');
        break;
      case 'staff':
        return $this->belongsTo(CompanyStaff::class, 'updated_by');
        break;
    }
  }

  public function claimStatus(): Attribute
  {
    return Attribute::make(
      get: function () {
        switch ($this->status) {
          case (0):
            return 'Drafted';
            break;

          case (1):
            return  'Submitted';
            break;

          case (2):
            return  'In Process';
            break;

          case (3):
            return  'Approved';
            break;

          case (4):
            return  'Completed';
            break;

          case (5):
            return  'Rejected';
            break;

          case (6):
            return  'On Hold';
            break;

          default:
            return  'Unknown Status';
        }
      }
    );
  }
}
