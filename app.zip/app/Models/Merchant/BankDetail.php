<?php

namespace App\Models\Merchant;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class BankDetail extends Model
{
  use HasFactory;

  protected $guarded = ['id'];

  protected $casts = [
    'disabled_at' => 'datetime',
    'enabled_at' => 'datetime',
  ];

  public function merchant()
  {
    return $this->belongsTo(User::class, 'merchant_id');
  }
}
