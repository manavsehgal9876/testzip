<?php

namespace App\Models\Merchant;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LTDCCollection extends Model
{
  use HasFactory;

  protected $table = 'ltdc_collection';

  protected $guarded = ['id'];

}
