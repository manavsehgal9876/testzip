<?php

namespace App\Models\Merchant;

use App\Models\User;
use App\Models\Merchant\BankDetail;
use App\Models\Merchant\ClaimHistory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Admin\Company\CompanyStaff;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Claim extends Model
{
  use HasFactory;

  protected $guarded = ['id'];

  protected $casts = [
    'last_updated_on' => 'date',
    'payment_date' => 'date',
  ];

  public function merchant()
  {
    return $this->belongsTo(User::class, 'merchant_id');
  }

  public function history()
  {
    return $this->hasMany(ClaimHistory::class, 'claim_id')->latest();
  }

  public function assignedStaff()
  {
    return $this->belongsTo(CompanyStaff::class, 'staff_id');
  }

  public function bankDetail()
  {
    return $this->belongsTo(BankDetail::class, 'bank_id');
  }
}
