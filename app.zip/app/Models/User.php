<?php

namespace App\Models;

use Illuminate\Support\Str;
use App\Models\Extension\City;
use App\Models\Merchant\Claim;
use App\Models\Merchant\Staff;
use App\Models\Extension\State;
use App\Models\Extension\Country;
use Laravel\Sanctum\HasApiTokens;
use App\Models\Merchant\BankDetail;
use Illuminate\Support\Facades\Hash;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
  use HasApiTokens, HasFactory, Notifiable;

  /**
   * The attributes that are mass assignable.
   *
   * @var array<int, string>
   */
  protected $guarded = ['id'];

  /**
   * The attributes that should be hidden for serialization.
   *
   * @var array<int, string>
   */
  protected $hidden = [
    // 'password',
    'remember_token',
  ];

  /**
   * The attributes that should be cast.
   *
   * @var array<string, string>
   */
  protected $casts = [
    'email_verified_at' => 'datetime',
    'sap_code_rqst_date' => 'datetime',
  ];

  protected function password(): Attribute
  {
    return Attribute::make(
      set: fn ($value) => Hash::make($value),
    );
  }

  protected function email(): Attribute
  {
    return Attribute::make(
      set: fn ($value) => Str::lower($value),
    );
  }

  protected function representativeEmail(): Attribute
  {
    return Attribute::make(
      set: fn ($value) => Str::lower($value),
    );
  }

  public function myCountry(): BelongsTo
  {
    return $this->belongsTo(Country::class, 'country');
  }

  public function myState(): BelongsTo
  {
    return $this->belongsTo(State::class, 'state');
  }

  public function myCity(): BelongsTo
  {
    return $this->belongsTo(City::class, 'city');
  }

  public function bankAccounts(): HasMany
  {
    return $this->hasMany(BankDetail::class, 'merchant_id');
  }

  public function activeBankAccount(): HasOne
  {
    return $this->hasOne(BankDetail::class, 'merchant_id')->where('status', '=', 1);
  }

  public function loginHistories(): HasMany
  {
    return $this->hasMany(LoginHistory::class, 'user_id')->where('type', 'merchant');
  }

  public function claims(): HasMany
  {
    return $this->hasMany(Claim::class, 'merchant_id');
  }

  public function completedClaims(): HasMany
  {
    return $this->hasMany(Claim::class, 'merchant_id')->where('status', '=', 4);
  }

  public function getClaimsCountAttribute(): int
  {
    return $this->claims()->count();
  }

  public function getDraftedClaimsCountAttribute(): int
  {
    return $this->claims()->where('status', 0)->count();
  }

  public function getPendingClaimsCountAttribute(): int
  {
    return $this->claims()->where('status', 1)->count();
  }

  public function getInProcessClaimsCountAttribute(): int
  {
    return $this->claims()->where('status', 2)->count();
  }

  public function getApprovedClaimsCountAttribute(): int
  {
    return $this->claims()->where('status', 3)->count();
  }

  public function getClosedClaimsCountAttribute(): int
  {
    return $this->claims()->where('status', 4)->count();
  }

  public function getRejectedClaimsCountAttribute(): int
  {
    return $this->claims()->where('status', 5)->count();
  }

  public function getOnHoldClaimsCountAttribute(): int
  {
    return $this->claims()->where('status', 6)->count();
  }

  public function staff(): HasMany
  {
    return $this->hasMany(Staff::class, 'merchant_id');
  }

  public function primaryStaff(): HasOne
  {
    return $this->hasOne(Staff::class, 'merchant_id')->where('is_primary', '=', 1);
  }

  public function kamStaff(): HasOne
  {
    return $this->hasOne(Staff::class, 'merchant_id')->where('is_kam', '=', 1);
  }
}
