<?php

namespace App\Exports;

use App\Models\Merchant\LTDC;
use App\Models\Admin\Form26AS;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;

class LtdcReportExport implements FromArray, WithHeadings, ShouldAutoSize, WithStyles, WithColumnFormatting
{
  public function styles(Worksheet $sheet)
  {
    return [
      1 => ['font' => ['bold' => true]],
    ];
  }

  public function columnFormats(): array
  {
    return [
      'I' => NumberFormat::FORMAT_TEXT,
      'J' => NumberFormat::FORMAT_TEXT,
      'K' => NumberFormat::FORMAT_TEXT,
      'L' => NumberFormat::FORMAT_TEXT,
    ];
  }

  public function headings(): array
  {
    return ['Merchant Name', 'TAN Number', 'Financial Year', 'Section', 'Revenue as of Date', '26AS Rate', 'LTDC Section', 'LTDC Rate', 'LTDC Limit', 'Revised LTDC Limit', 'Total Limit', 'LTDC Limit Available'];
  }

  public function __construct(private string $financialYear)
  {
  }

  public function array(): array
  {
    $form26As = Form26AS::where([['financial_year', '=', $this->financialYear]])->groupBy('deductor_tan', 'section')->get();
    $ltdcReportData = [];

    foreach ($form26As as $key => $form26) {
      $revisedLtdc = LTDC::where([['financial_year', '=', $this->financialYear], ['revised_flag', '=', 1], ['tan_number', '=', $form26->deductor_tan], ['section', '=', $form26->section]])->select('income_to_receive')->first();

      $ltdc = LTDC::where([['financial_year', '=', $this->financialYear], ['revised_flag', '=', 0], ['tan_number', '=', $form26->deductor_tan], [
        'section', '=',
        $form26->section
      ]])->first();

      $ltdcReportData[$key]['Merchant Name'] = $form26->deductor_name;
      $ltdcReportData[$key]['TAN Number'] = $form26->deductor_tan;
      $ltdcReportData[$key]['Financial Year'] = $form26->financial_year;
      $ltdcReportData[$key]['Section'] = $form26->section;
      $ltdcReportData[$key]['Revenue as of Date'] = Form26AS::where([['financial_year', '=', $this->financialYear], ['deductor_tan', '=', $form26->deductor_tan], ['section', '=', $form26->section]])->sum('total_amount_paid');
      $ltdcReportData[$key]['26AS Rate'] = $form26->rate;

      $ltdcReportData[$key]['LTDC Section'] = $ltdc?->section;
      $ltdcReportData[$key]['LTDC Rate'] = $ltdc?->rate_of_deduction;
      $ltdcReportData[$key]['LTDC Limit'] = (isset($ltdc->income_to_receive) && $ltdc->income_to_receive > 0) ? $ltdc->income_to_receive : '0';
      $ltdcReportData[$key]['Revised LTDC Limit'] = (isset($revisedLtdc?->income_to_receive) && $revisedLtdc?->income_to_receive > 0) ? $revisedLtdc?->income_to_receive : '0';
      $totalLimit = $ltdcReportData[$key]['LTDC Limit'] + $ltdcReportData[$key]['Revised LTDC Limit'];
      $ltdcReportData[$key]['Total Limit'] = $totalLimit > 0 ? $totalLimit : '0';
      $ltdcLimitAvailable = $ltdcReportData[$key]['Total Limit'] - $ltdcReportData[$key]['Revenue as of Date'];
      $ltdcReportData[$key]['LTDC Limit Available'] = ($ltdcLimitAvailable <= 0) ? '0' : $ltdcLimitAvailable;
    }
    return $ltdcReportData;
  }
}
