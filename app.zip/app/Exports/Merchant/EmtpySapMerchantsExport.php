<?php

namespace App\Exports\Merchant;

use App\Models\User;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class EmtpySapMerchantsExport implements FromArray, WithHeadings, ShouldAutoSize, WithStyles
{
  public function styles(Worksheet $sheet)
  {
    return [
      1 => ['font' => ['bold' => true]],
    ];
  }

  public function headings(): array
  {
    return [
      'Merchant Name', 'SAP Code', 'TAN No', 'Sap Code Request Date'
    ];
  }

  public function array(): array
  {
    $merchants = User::where('sap_code', '=', NULL)->get();

    $merchantsArray = [];

    foreach ($merchants as $merchant)
      $merchantsArray[] = [
        $merchant->company_name,
        $merchant->sap_code,
        $merchant->tan_number,
        isset($merchant->sap_code_rqst_date) ? $merchant->sap_code_rqst_date->format('d M, Y') : '',
      ];

    return $merchantsArray;
  }
}
