<?php

namespace App\Exports\Merchant;

use Carbon\Carbon;
use App\Models\User;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;

class RecentMonthMerchantBankUpdateExport implements FromArray, WithHeadings, ShouldAutoSize, WithStyles, WithColumnFormatting
{
  public function styles(Worksheet $sheet)
  {
    return [
      1 => ['font' => ['bold' => true]],
    ];
  }

  public function columnFormats(): array
  {
    return [
      'G' => NumberFormat::FORMAT_TEXT,
    ];
  }

  public function headings(): array
  {
    return [
      'Merchant Name', 'SAP Code', 'TAN No', 'Bank Name', 'Branch', 'Account Holder name', 'Bank Acc No', 'IFSC', 'Bank Created Date'
    ];
  }

  public function array(): array
  {
    $merchants = User::where('sap_code', '!=', null)
      // ->whereHas('claims', function ($q) {
      //   $q->where('status', '=', 6);
      // })
      ->whereHas('bankAccounts', function ($q) {
        $q->whereBetween('updated_at', [Carbon::now()->subMonth(), Carbon::now()]);
      })
      ->get();

    $merchants = $merchants->sortByDesc('bankAccounts.updated_at');

    $merchantsArray = [];

    foreach ($merchants as $merchant) {
      $merchantsArray[] = [
        $merchant->company_name,
        $merchant->sap_code,
        $merchant->tan_number,
        $merchant->activeBankAccount?->name,
        $merchant->activeBankAccount?->branch,
        $merchant->activeBankAccount?->acc_holder_name,
        "'" . $merchant->activeBankAccount?->account_number,
        $merchant->activeBankAccount?->ifsc,
        $merchant->activeBankAccount?->created_at->format('d M, Y'),
      ];
    }
    return $merchantsArray;
  }
}
