<?php

namespace App\Exports\Claim;

use App\Models\Admin\GlAccount;
use Illuminate\Database\Eloquent\Collection;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ApprovedClaimSapReportExport implements FromArray, WithHeadings, ShouldAutoSize, WithStyles
{

  public function __construct(private Collection $claims)
  {
  }

  public function styles(Worksheet $sheet): array
  {
    return [
      1 => ['font' => ['bold' => true]],
      2 => ['font' => ['bold' => true]],
      3 => ['font' => ['bold' => true]],
    ];
  }

  public function headings(): array
  {
    return [
      ['File Document number', 'Company Code', 'Posting date', 'Document date', 'Ledger', 'Document type', 'Business place', 'Section code', 'Place of Supply', 'Reference', 'Header Text', 'Currency', 'Exchange Rate', 'Posting code', 'Special G/L Indicator', 'Account', 'Amount in document currency', 'Amount in local currency', 'Tax On', 'Tax Code', 'Calculate tax', 'Assignment', 'Text', 'Profit Center', 'Partner Profit center', 'Cost center', 'Internal order', 'Payment term', 'Baseline date for payment', 'Trading Partner', 'HSN / SAC Code', 'Reference Key', 'WBS ELEMENT', 'Special periods (A/B)', 'Special Transaction Type', 'Payment Block Key', 'Name', 'City', 'Country', 'Period', 'XREF1_HD', 'Negative Posting',],

      ['', 'bkpf-bukrs', 'bkpf-budat', 'Bkpf-bldat', '', 'Bkpf-blart', 'BUPLA', 'SECCO', 'PLC_SUP', 'Bkpf-xblnr', 'Bkpf-bktxt', 'Bkpf-waers', 'Bkpf-kursf', 'Bseg-bschl', 'Bseg-umskz', '', 'Bseg-wrbtr', 'Bseg-dmbtr', '', 'Bseg-mwskz', 'Bseg-xmwst', 'Bseg-zuonr', 'Bseg-sgtxt', 'Bseg-prctr', 'bseg-pprct', 'Bseg-kostl', 'bseg-aufnr', 'Bseg-zterm', 'Bseg-zfbdt', 'Bseg-vbund', 'HSN_SAC', 'bseg-xref3', 'PS_POSID', 'BSEG-ZZZ_PERIOD', 'BSEG-ZZZ_SPTT', 'Bseg-ZLSPR', 'BAPIACPA09-NAME', 'BAPIACPA09-CITY', 'BAPIACPA09-COUNTRY', 'BKPF-MONAT XXXXXX', 'BAPIACPA09-NEG_POSTNG', '', '', 'House Bank', 'Payment Method'],

      ['', ' i.e A059', 'YYYY.MM.DD', 'YYYY.MM.DD', 'If all ledgers - empty field, if specific ledger: 0L, TL, LL, CL', 'ie. PK', '', '', '', '', '', '', 'Exchange Rate only informative; amounts are decisive for postings', '', '', 'GL accounts or vendor/customer', 'Entry mandatory', 'Entry mandatory', '', '', '', '', '', '', '', '', '', '', 'YYYY.MM.DD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '']
    ];
  }

  public function array(): array
  {
    $approvedClaims = [];
    $lastKey = 0;

    foreach ($this->claims as $key => $claim) {
      $lastKey = ++$lastKey;
      $approvedClaims[$key]['File Document number'] = $claim->id;
      $approvedClaims[$key]['Company Code'] = 'A221';
      $approvedClaims[$key]['Posting date'] =  date('Y.m.d');
      $approvedClaims[$key]['Document date'] =  date('Y.m.d');
      $approvedClaims[$key]['Ledger'] = '';
      $approvedClaims[$key]['Document type'] = 'KR';
      $approvedClaims[$key]['Business place'] = '';
      $approvedClaims[$key]['Section code'] = '';
      $approvedClaims[$key]['Place of Supply'] = '';
      $approvedClaims[$key]['Reference'] = substr($claim->claim_id, 6);
      $approvedClaims[$key]['Header Text'] = $claim->claim_id;
      $approvedClaims[$key]['Currency'] = 'INR';
      $approvedClaims[$key]['Exchange Rate'] = '';
      $approvedClaims[$key]['Posting code'] = '31';
      $approvedClaims[$key]['Special G/L Indicator'] = '';
      $approvedClaims[$key]['Account'] = $claim->merchant->sap_code;
      $approvedClaims[$key]['Amount in document currency'] = $claim->tds_claim_amount;
      $approvedClaims[$key]['Amount in local currency'] = $claim->tds_claim_amount;
      $approvedClaims[$key]['Tax On'] = '';
      $approvedClaims[$key]['Tax Code'] = '';
      $approvedClaims[$key]['Calculate tax'] = '';
      $approvedClaims[$key]['Assignment'] = $claim->tan_number;
      $approvedClaims[$key]['Text'] = $claim->claim_id;
      $approvedClaims[$key]['Profit Center'] = 'A221001';
      $approvedClaims[$key]['Partner Profit center'] = '';
      $approvedClaims[$key]['Cost center'] = '';
      $approvedClaims[$key]['Internal order'] = '';
      $approvedClaims[$key]['Payment term'] = '';
      $approvedClaims[$key]['Baseline date for payment'] = date('Y.m.d');
      $approvedClaims[$key]['Trading Partner'] = '';
      $approvedClaims[$key]['HSN / SAC Code'] = '';
      $approvedClaims[$key]['Reference Key'] = '';
      $approvedClaims[$key]['WBS ELEMENT'] = '';
      $approvedClaims[$key]['Special periods (A/B)'] = '';
      $approvedClaims[$key]['Special Transaction Type'] = '';
      $approvedClaims[$key]['Payment Block Key'] = '';
      $approvedClaims[$key]['Name'] = '';
      $approvedClaims[$key]['City'] = '';
      $approvedClaims[$key]['Country'] = '';
      $approvedClaims[$key]['Period'] = '';
      $approvedClaims[$key]['XREF1_HD'] = '';
      $approvedClaims[$key]['Negative Posting'] = '';
      $approvedClaims[$key]['empty_one'] = '';
      $approvedClaims[$key]['empty_two'] = 'HDIN2';
      $approvedClaims[$key]['empty_three'] = 'T';
    }
    $approvedClaims[][] = '';
    foreach ($this->claims as $claim) {
      $lastKey = ++$lastKey;
      $approvedClaims[$lastKey]['File Document number'] = $claim->id;
      $approvedClaims[$lastKey]['Company Code'] = 'A221';
      $approvedClaims[$lastKey]['Posting date'] =  date('Y.m.d');
      $approvedClaims[$lastKey]['Document date'] =  date('Y.m.d');
      $approvedClaims[$lastKey]['Ledger'] = '';
      $approvedClaims[$lastKey]['Document type'] = 'KR';
      $approvedClaims[$lastKey]['Business place'] = '';
      $approvedClaims[$lastKey]['Section code'] = '';
      $approvedClaims[$lastKey]['Place of Supply'] = '';
      $approvedClaims[$lastKey]['Reference'] = substr($claim->claim_id, 6);
      $approvedClaims[$lastKey]['Header Text'] = $claim->claim_id;
      $approvedClaims[$lastKey]['Currency'] = 'INR';
      $approvedClaims[$lastKey]['Exchange Rate'] = '';
      $approvedClaims[$lastKey]['Posting code'] = '40';
      $approvedClaims[$lastKey]['Special G/L Indicator'] = '';
      $approvedClaims[$lastKey]['Account'] = GlAccount::where('financial_year', $claim->financial_year)->value('gl_number');
      $approvedClaims[$lastKey]['Amount in document currency'] = $claim->tds_claim_amount;
      $approvedClaims[$lastKey]['Amount in local currency'] = $claim->tds_claim_amount;
      $approvedClaims[$lastKey]['Tax On'] = '';
      $approvedClaims[$lastKey]['Tax Code'] = '';
      $approvedClaims[$lastKey]['Calculate tax'] = '';
      $approvedClaims[$lastKey]['Assignment'] = $claim->tan_number;
      $approvedClaims[$lastKey]['Text'] = $claim->claim_id;
      $approvedClaims[$lastKey]['Profit Center'] = 'A221001';
      $approvedClaims[$lastKey]['Partner Profit center'] = '';
      $approvedClaims[$lastKey]['Cost center'] = '';
      $approvedClaims[$lastKey]['Internal order'] = '';
      $approvedClaims[$lastKey]['Payment term'] = '';
      $approvedClaims[$lastKey]['Baseline date for payment'] = date('Y.m.d');
      $approvedClaims[$lastKey]['Trading Partner'] = '';
      $approvedClaims[$lastKey]['HSN / SAC Code'] = '';
      $approvedClaims[$lastKey]['Reference Key'] = '';
      $approvedClaims[$lastKey]['WBS ELEMENT'] = '';
      $approvedClaims[$lastKey]['Special periods (A/B)'] = '';
      $approvedClaims[$lastKey]['Special Transaction Type'] = '';
      $approvedClaims[$lastKey]['Payment Block Key'] = '';
      $approvedClaims[$lastKey]['Name'] = '';
      $approvedClaims[$lastKey]['City'] = '';
      $approvedClaims[$lastKey]['Country'] = '';
      $approvedClaims[$lastKey]['Period'] = '';
      $approvedClaims[$lastKey]['XREF1_HD'] = '';
      $approvedClaims[$lastKey]['Negative Posting'] = '';
      $approvedClaims[$lastKey]['empty_one'] = '';
      $approvedClaims[$lastKey]['empty_two'] = 'HDIN2';
      $approvedClaims[$lastKey]['empty_three'] = 'T';
    }

    return $approvedClaims;
  }
}
