<?php

namespace App\Mail\Admin\Merchant;

use Illuminate\Support\Str;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class SapCodeRequest extends Mailable
{
  use Queueable, SerializesModels;

  /**
   * Create a new message instance.
   *
   * @return void
   */
  public function __construct(public $data)
  {
    //
  }

  /**
   * Build the message.
   *
   * @return $this
   */
  public function build()
  {
    $this->subject($this->data['subject'])->markdown('emails.merchant.sap-code-request');

    if (isset($this->data['merchant']->gst_document))
      $this->attach(asset('crm/public/uploads/merchant') . '/' . $this->data['merchant']->gst_document, ['as' => 'GST-DOCUMENT.' . Str::after($this->data['merchant']->gst_document, '.')]);

    if (isset($this->data['merchant']->pan_document))
      $this->attach(asset('crm/public/uploads/merchant') . '/' . $this->data['merchant']->pan_document, ['as' => 'PANCARD-DOCUMENT.' . Str::after($this->data['merchant']->pan_document, '.')]);

    if (isset($this->data['merchant']->activeBankAccount->cancel_cheque))
      $this->attach(asset('crm/public/uploads/merchant') . '/' . $this->data['merchant']->activeBankAccount->cancel_cheque, ['as' => 'CANCEL-CHEQUE.' . Str::after($this->data['merchant']->activeBankAccount->cancel_cheque, '.')]);

    return $this;
  }
}
