<?php

namespace App\Mail\Merchant\Claim;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class NotifyStaffOfClaimResubmission extends Mailable
{
  use Queueable, SerializesModels;

  /**
   * Create a new message instance.
   *
   * @return void
   */
  public function __construct(public $data)
  {
    //
  }

  /**
   * Build the message.
   *
   * @return $this
   */
  public function build()
  {
    return $this->subject('Rejected claim resubmitted! #' . $this->data->claim_id)->markdown('emails.merchant.claim.notify-staff-of-claim-resubmission');
  }
}
