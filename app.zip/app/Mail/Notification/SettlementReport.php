<?php

namespace App\Mail\Notification;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Storage;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailables\Attachment;

class SettlementReport extends Mailable
{
  use Queueable, SerializesModels;

  /**
   * Create a new message instance.
   *
   * @return void
   */
  public function __construct(public $data)
  {
  }
  /**
   * Get the attachments for the message.
   *
   * @return \Illuminate\Mail\Mailables\Attachment[]
   */
  public function attachments()
  {
    return [
      Attachment::fromStorage($this->data['fileName'])->as('settlement-report.xlsx'),
    ];
  }

  /**
   * Build the message.
   *
   * @return $this
   */
  public function build()
  {
    return $this->subject('Settlement Report')->markdown('emails.notifications.settlement-report');
  }
}
