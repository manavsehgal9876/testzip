<?php

namespace App\Imports;

use App\Models\Merchant\Claim;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Concerns\WithBatchInserts;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Carbon\Carbon;

// , ShouldQueue
class UTRImport implements ToModel, WithHeadingRow, WithValidation, WithBatchInserts, WithChunkReading
{
  /**
   * @param array $row
   *
   * @return \Illuminate\Database\Eloquent\Model|null
   */
  public function model(array $row)
  {
    $claim = Claim::where('claim_id', $row['claim_id'])->firstOrFail();

    $claim->update([
      'sap_invoice_doc_no' => $row['sap_invoice_doc_no'],
      'sap_payment_doc_no' => $row['sap_payment_doc_no'],
      'amount' => $row['amount'],
      'utr' => $row['utr'],
      'payment_date' => Carbon::parse($row['payment_date']),
      'status' => 4,
    ]);

    $claim->history()->create(['claim_id' => $claim->id, 'updated_by' => auth()->user()->id, 'updated_by_role' => auth()->user()->type, 'status' => 4, 'remark' => 'UTR imported']);
  }

  public function rules(): array
  {
    return [
      'company_code' => ['required', 'string', 'max:50'],
      'merchant_name' => ['required', 'regex:/^[a-zA-Z0-9\s]+$/', 'max:100'],
      'sap_vendor_code' => ['nullable', 'alpha_num', 'max:50'],
      'pan' => ['required', 'alpha_num', 'min:10', 'max:10'],
      'claim_id' => ['required', 'exists:App\Models\Merchant\Claim,claim_id'],
      'sap_invoice_doc_no' => ['required', 'max:50'],
      'sap_payment_doc_no' => ['required', 'max:50'],
      'amount' => ['required', 'numeric'],
      'utr' => ['required', 'alpha_num', 'max:50'],
      'payment_date' => ['required', 'date_format:d-m-Y'],
    ];
  }

  public function messages()
  {
    return [];
  }

  public function batchSize(): int
  {
    return 50;
  }

  public function chunkSize(): int
  {
    return 50;
  }
}
