<?php

namespace App\Traits;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Validator;
use Illuminate\Pagination\LengthAwarePaginator;

trait ApiResponser
{

  protected function successResponse($data, $message = '', $code = 200)
  {
    return response()->json([
      'status' => 'success',
      'message' => $message,
      'data' => empty($data) ? (object)[] : $data,
    ], $code);
  }

  protected function errorResponse($data, $message = null, $code = 404)
  {
    return response()->json([
      'status' => 'error',
      'message' => $message,
      'data' => empty($data) ? (object)[] : $data,
    ], $code);
  }
}
