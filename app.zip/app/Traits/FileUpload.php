<?php

namespace App\Traits;

use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;

trait FileUpload
{
  public function handleSingleFileUpload($file, $path): string
  {
    $fileName = Str::random(30) . time() . '.' . $file->extension();
    $file->move(public_path($path), $fileName);
    return $fileName;
  }

  public function handleMultiFileUpload($request, $key, $path, $limit = 50): array
  {
    $filesNames = [];
    foreach ($request->{$key} as $key => $file) :
      if ($key < $limit) {
        $name =  Str::random(30) . time() . '.' . $file->extension();
        $file->move(public_path($path), $name);
        $filesNames[] = $name;
      }
    endforeach;
    return $filesNames;
  }

  public function handleDeleteFile($file, $path): bool
  {
    if (Storage::disk('appFiles')->exists("{$path}{$file}")) {
      return Storage::disk('appFiles')->delete("{$path}{$file}");
    }
    return false;
  }
}
