<?php

namespace App\Actions;

use Illuminate\Support\Facades\Auth;
use Lorisleiva\Actions\Concerns\AsAction;

class LogoutAll
{
  use AsAction;

  public function handle(): bool
  {
    Auth::guard('web')->logout();
    Auth::guard('admin')->logout();
    Auth::guard('company_staff')->logout();
    session()->invalidate();
    session()->regenerateToken();

    return true;
  }
}
