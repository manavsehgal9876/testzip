<?php

namespace App\Actions\Staff;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Lorisleiva\Actions\Concerns\AsAction;
use App\Models\Admin\Form26AS as Form26ASModel;

class SummarisedForm26AS
{
  use AsAction;

  public function asController(Request $request): View
  {
    $form26as = collect([]);
    $whereCondition = [];
    $orWhereCondition = [];

    if (isset($request->financial_year))
      $whereCondition[] =  ['financial_year', '=', $request->financial_year];

    if (isset($request->quarter))
      $whereCondition[] = ['quarter', '=', $request->quarter];

    $form26as = Form26ASModel::where($whereCondition);

    $form26as = $form26as->groupBy('deductor_tan')
      ->groupBy('financial_year')
      ->groupBy('quarter')
      ->select('*', DB::raw('sum(total_amount_paid) as sumOfTotalAmountPaid'), DB::raw('sum(total_tds_deposited) as sumOfTotalTdsDesposited'));

    if (isset($request->search)) {
      $form26as = $form26as->where(function ($query) use ($request) {
        $query->where('deductor_tan', '=', $request->search)
          ->orWhere('deductor_name', 'like', '%' . $request->search . '%');
      });
    }
    $form26as = $form26as->paginate(500);

    if (!isset($request->financial_year) && !isset($request->search) && !isset($request->quarter))
      $form26as = Form26ASModel::groupBy('deductor_tan')
        ->groupBy('financial_year')
        ->groupBy('quarter')
        ->select('*', DB::raw('sum(total_amount_paid) as sumOfTotalAmountPaid'), DB::raw('sum(total_tds_deposited) as sumOfTotalTdsDesposited'))
        ->paginate(500);

    $financialYears = Form26ASModel::distinct('financial_year')->orderByDesc('financial_year')->pluck('financial_year');
    $quarters = Form26ASModel::distinct('quarter')->orderByDesc('quarter')->pluck('quarter');
    return view('adminStaff.summarised-form-26-as', compact('form26as', 'financialYears', 'quarters'));
  }
}
