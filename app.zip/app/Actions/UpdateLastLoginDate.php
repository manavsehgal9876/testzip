<?php

namespace App\Actions;

use App\Models\LoginHistory;
use Lorisleiva\Actions\Concerns\AsAction;

class UpdateLastLoginDate
{
  use AsAction;

  public function handle(int $id, string $type)
  {
    return LoginHistory::create([
      'user_id' => $id,
      'type' => $type
    ]);
  }
}
