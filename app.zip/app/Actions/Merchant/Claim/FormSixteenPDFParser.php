<?php

namespace App\Actions\Merchant\Claim;

use Carbon\Carbon;
use Illuminate\Support\Str;
use App\Traits\ApiResponser;
use Illuminate\Http\Request;
use Smalot\PdfParser\Parser;
use Lorisleiva\Actions\Concerns\AsAction;

class FormSixteenPDFParser
{
  use AsAction, ApiResponser;

  private array $quarterOne = ["April", "May", "June"];
  private array $quarterTwo = ["July", "August", "September"];
  private array $quarterThree = ["October", "November", "December"];
  private array $quarterFour = ["January", "February", "March"];

  public function handle(string $filePath)
  {
    $pdfParser = new Parser();
    $pdf = $pdfParser->parseFile($filePath);
    $content = trim(preg_replace('/\s+/', ' ', $pdf->getText()));

    $certificateNumber = trim($this->get_string_between($content, 'Certificate Number:', 'TAN of Deductor'));

    $tanNumber = trim($this->get_string_between($content, 'TAN of the deductor', 'PAN of the deductee'));

    $assessmentYear = trim($this->get_string_between($content, 'Assessment Year', 'CIT (TDS)'));

    $periodFrom = trim($this->get_string_between($content, 'Period From ', ' To'));
    $periodTo = trim($this->get_string_between($content, 'To ', ' Summary of payment Amount paid'));

    $periodFrom = Carbon::createFromFormat('d-M-Y', $periodFrom)->format('d M, Y');
    $periodTo = Carbon::createFromFormat('d-M-Y', $periodTo)->format('d M, Y');

    $summaryOfPaymentTotalRupees = (float)$this->get_string_between($content, 'Total (Rs.)', 'Summary of tax deducted at source in respect of Deductee');

    $taxDeductedTotalRupees = $this->get_string_between($content, 'has been deducted', 'has been deposited to the credit');
    $taxDeductedTotalRupees = (float)trim($this->get_string_between($taxDeductedTotalRupees, 'and a sum of Rs.   ', ' [Rs. '));

    $lastUpdatedOn = Carbon::createFromFormat('d-M-Y', trim($this->get_string_between($content, 'Last updated on', 'Page 1 of')))->format('Y-m-d');

    $natureOfPayment = Str::of($this->get_string_between($content, "(if any)", "Total (Rs.)"))->explode(' ')->map(function ($item) {
      return trim($item);
    })->toArray();
    $natureOfPayment = isset($natureOfPayment[2]) ? $natureOfPayment[2] : '';

    $quarter = $this->getQuarter(Carbon::createFromFormat('d M, Y', $periodFrom)->format('F'));

    $financialYear = $this->getFinancialYear($assessmentYear);

    $payuPanNumber = $this->get_string_between($content, 'PAN of the deductee ', ' Assessment Year');

    return compact('certificateNumber', 'tanNumber', 'assessmentYear', 'periodFrom', 'periodTo', 'summaryOfPaymentTotalRupees', 'taxDeductedTotalRupees', 'lastUpdatedOn', 'natureOfPayment', 'financialYear', 'quarter', 'payuPanNumber');
  }

  private function get_string_between($str, $starting_word, $ending_word)
  {
    $subtring_start = strpos($str, $starting_word);
    //Adding the starting index of the starting word to
    //its length would give its ending index
    $subtring_start += strlen($starting_word);
    //Length of our required sub string
    $size = strpos($str, $ending_word, $subtring_start) - $subtring_start;
    // Return the substring from the index substring_start of length size
    return substr($str, $subtring_start, $size);
  }

  public function getFinancialYear($assessmentYear): string
  {
    $year = (int) explode("-", $assessmentYear)[1];
    $yearOne = $year - 2;
    return '20' . $yearOne . '-' . $year - 1;
  }

  public function getQuarter(string $month): int
  {
    if (in_array($month, $this->quarterOne)) {
      return 1;
    } else if (in_array($month, $this->quarterTwo)) {
      return 2;
    } else if (in_array($month, $this->quarterThree)) {
      return 3;
    } else if (in_array($month, $this->quarterFour)) {
      return 4;
    }
    return 0;
  }
}
