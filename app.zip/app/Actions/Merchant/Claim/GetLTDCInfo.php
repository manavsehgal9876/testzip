<?php

namespace App\Actions\Merchant\Claim;

use App\Models\Merchant\LTDC;
use App\Models\Merchant\LTDCCollection;
use Lorisleiva\Actions\Concerns\AsAction;

class GetLTDCInfo
{
  use AsAction;

  private function handle(string $tanNumber, string $assessmentYear, int $quarter): array
  {
    $assessmentYear = substr($assessmentYear, strpos($assessmentYear, "-") + 1);
    $financialYear = "20" . $assessmentYear - 2 . "-" . $assessmentYear - 1;
    $ltdc = LTDC::where('tan_number', '=', $tanNumber)->where('financial_year', '=', $financialYear)->first();
    $sumOfIncomeToReceive = 0;

    // if ($quarter === 1 || $quarter === 2 || $quarter === 3)
    $sumOfIncomeToReceive = LTDC::where('tan_number', $tanNumber)->where('financial_year', $financialYear)->sum('income_to_receive');
    // else if ($quarter === 4)
    //   $sumOfIncomeToReceive = LTDC::where('tan_number', $tanNumber)->where('financial_year', $financialYear)->sum('income_to_receive');

    $remaningLimit = 0;
    if (isset($ltdc)) {
      $ltdcCollection = LTDCCollection::where([['tan_number', '=', $tanNumber], ['financial_year', '=', $financialYear]])->first();

      if ($quarter === 1) $remaningLimit =  (isset($ltdcCollection)) ? $ltdcCollection->quarter_one_remaining : 0;
      else if ($quarter === 2) $remaningLimit = (isset($ltdcCollection)) ? $ltdcCollection->quarter_two_remaining : 0;
      else if ($quarter === 3) $remaningLimit = (isset($ltdcCollection)) ? $ltdcCollection->quarter_three_remaining : 0;
      else if ($quarter === 4) $remaningLimit = (isset($ltdcCollection)) ? $ltdcCollection->quarter_four_remaining : 0;
    }
    
    $path = "crm/public/uploads/ltdc-{$financialYear}/";
    $pathRevised = "crm/public/uploads/ltdc-{$financialYear}-r/";

    if (isset($ltdc))
      return [
        'ltdc_available' => 'Yes',
        'ltdc_total_limit' => $sumOfIncomeToReceive,
        'ltdc_rate' => $ltdc->rate_of_deduction,
        'tdc_limit_available' => $remaningLimit,
        'file_name' => $ltdc->ltdcpdf,
        'file_path' => asset($path . $ltdc->ltdcpdf),
        'file_path_revised' => asset($pathRevised . $ltdc->ltdcpdf)
      ];

    return [
      'ltdc_available' => 'No',
      'ltdc_total_limit' => 0,
      'ltdc_rate' => 0,
      'tdc_limit_available' => 0,
      'file_name' => '',
      'file_path' => '',
      'file_path_revised' => ''
    ];
  }
}
