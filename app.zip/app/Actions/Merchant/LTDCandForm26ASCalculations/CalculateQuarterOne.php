<?php

namespace App\Actions\Merchant\LTDCandForm26ASCalculations;

use DateTime;
use App\Models\Merchant\LTDC;
use App\Models\Admin\Form26AS;
use Illuminate\Support\Facades\Log;
use App\Models\Merchant\LTDCCollection;
use Lorisleiva\Actions\Concerns\AsAction;

class CalculateQuarterOne
{
  use AsAction;

  private array $quarterOneMonths = [4, 5, 6];

  public function handle(string $tanNumber, string $financialYear, string $currentFinancialYear, int $quarter, bool $runQuarterTwo)
  {
    // calculating for the financial year of 2021-22
    $ltdc = LTDC::where([['tan_number', '=', $tanNumber], ['financial_year', '=', $financialYear], ['revised_flag', '=', 0]])->first();

    if (!isset($ltdc))
      return Log::debug('LTDC not available in the database');


    $amountToBeDeducted = (float)$ltdc->income_to_receive;
    $validFrom = DateTime::createFromFormat('d-M-y', $ltdc->valid_from)->format('Y-m-d');
    $validFromYear = DateTime::createFromFormat('d-M-y', $ltdc->valid_from)->format('Y');
    $validTill = DateTime::createFromFormat('d-M-y', $ltdc->valid_till)->format('Y-m-d');

    $quarterOneForm26ASAmountPaidSum = Form26AS::where([
      ['transaction_date', '>=', $validFrom], ['transaction_date', '<=', $validFromYear . '06' . '30'], ['deductor_tan', '=', $tanNumber]
    ])
      ->orderBy('transaction_date', 'asc')
      ->sum('total_amount_paid');

    $quarterOneRemaningAmount = $amountToBeDeducted - $quarterOneForm26ASAmountPaidSum;

    $ltdcCollection = LTDCCollection::create([
      'tan_number' => $tanNumber,
      'financial_year' => $financialYear,
      'quarter_one' => ($quarterOneRemaningAmount <= 0) ? $amountToBeDeducted : $quarterOneForm26ASAmountPaidSum,
      'quarter_one_remaining' => ($quarterOneRemaningAmount <= 0) ? 0.0 : $quarterOneRemaningAmount,
      'quarter_two' => 0.0,
      'quarter_two_remaining' => 0.0,
      'quarter_three' => 0.0,
      'quarter_three_remaining' => 0.0,
      'quarter_four' => 0.0,
      'quarter_four_remaining' => 0.0,
      'use_revise_quarter_four' => false,
    ]);

    if ($quarterOneRemaningAmount !== 0 && $runQuarterTwo) CalculateQuarterTwo::run($tanNumber, $financialYear, $currentFinancialYear, $quarter, $ltdcCollection, $quarterOneRemaningAmount, $quarter > 2 ? true : false);
    // dd($validFrom, $validTill, $amountToBeDeducted, $quarterOneForm26ASAmountPaidSum, $quarterOneRemaningAmount);
    return true;
  }
}
