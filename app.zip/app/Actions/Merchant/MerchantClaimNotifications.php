<?php

namespace App\Actions\Merchant;

use Illuminate\View\View;
use App\Models\Merchant\ClaimHistory;
use Lorisleiva\Actions\Concerns\AsAction;

class MerchantClaimNotifications
{
  use AsAction;

  public function asController(): View
  {
    $claimHistory = ClaimHistory::whereHas('claim', function ($query) {
      $query->where('merchant_id', auth()->user()->id);
    })
      ->latest()
      ->paginate(100);

    return view('merchant.claim-notifications', compact('claimHistory'));
  }
}
