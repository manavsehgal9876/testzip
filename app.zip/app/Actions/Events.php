<?php

namespace App\Actions;

use App\Models\Event;
use Illuminate\View\View;
use Lorisleiva\Actions\Concerns\AsAction;

class Events
{
  use AsAction;

  public function handle(): View
  {
    $events = Event::orderByDesc('id')->paginate(100);
    return view('merchant.events', compact('events'));
  }
}
