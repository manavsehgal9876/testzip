<?php

namespace App\Actions\Admin\Merchant;

use App\Models\User;
use Illuminate\Support\Facades\Mail;
use Lorisleiva\Actions\Concerns\AsAction;
use App\Mail\Admin\Merchant\SapCodeRequest;

class MerchantSapCodeRequest
{
  use AsAction;

  public function asController(int $merchantId, string $for)
  {
    $merchant = User::findOrFail($merchantId);
    $merchantName = $merchant->company_name;
    Mail::to(config('myconfig.TDS_SUPER_EMAIL'))->send(new SapCodeRequest([
      'merchant' => $merchant,
      'subject' => ($for === 'profile') ? 'Merchant SAP code request!' : 'Merchant bank detail update request!',
      'body' => ($for === 'profile') ? "You have received sap code generation request for the merchant ({$merchantName}). You can find the details below." : "You have received bank details update request for the merchant ({$merchantName}). You can find the details below.",
    ]));
    $merchant->update(['sap_code_rqst_date' => now()->format('Y-m-d')]);
    return back()->with('success', 'Request sent successfully.');
  }
}
