<?php

namespace App\Actions\Admin\Staff;

use App\Traits\ApiResponser;
use Illuminate\Http\Request;
use App\Models\Merchant\Claim;
use Illuminate\Http\JsonResponse;
use App\Models\CompanyStaffAssignedClaim;
use Lorisleiva\Actions\Concerns\AsAction;

class AssignClaimsToStaff
{
  use AsAction, ApiResponser;

  public function handle(Request $request): JsonResponse
  {
    foreach ($request->claimIds as  $id) {
      Claim::find($id)->update(['staff_id' => $request->staff_id]);
      CompanyStaffAssignedClaim::create(['staff_id' => $request->staff_id, 'claim_id' => $id]);
    }
    return $this->successResponse([], 'Claim has been assigned to the staff.');
  }
}
