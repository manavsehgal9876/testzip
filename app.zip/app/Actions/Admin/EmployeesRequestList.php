<?php

namespace App\Actions\Admin;

use App\Models\EmployeeRequestEmail;
use Lorisleiva\Actions\Concerns\AsAction;

class EmployeesRequestList
{
  use AsAction;

  public function asController()
  {
    $emails = EmployeeRequestEmail::orderBy('created_at', 'desc')->get();
    return view('employer.employees-request-list', compact('emails'));
  }
}
