<?php

namespace App\Actions\Admin;

use App\Imports\ImportForm26AS;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\BeforeImportForm26AS;
use App\Http\Requests\ExcelFileRequest;
use Lorisleiva\Actions\Concerns\AsAction;
use Illuminate\Validation\ValidationException;

class Form26ASImport
{
  use AsAction;

  public function handle(ExcelFileRequest $request)
  {
    try {
      UploadForm26ASExcelAndDispatchJob::run($request);
      $mail = config('myconfig.TDS_SUPER_EMAIL');
      return back()->with('success', "Form 26AS sheet upload status will be notified on {$mail}");
    } catch (ValidationException  $th) {
      // dd($th, $th->errors());
      return back()->withErrors($th->errors());
    } catch (\Throwable $th) {
      dd($th);
    }
  }
}
