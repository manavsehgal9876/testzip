<?php

namespace App\Actions\Admin;

use Illuminate\View\View;
use Illuminate\Http\Request;
use App\Models\Merchant\LTDC;
use Lorisleiva\Actions\Concerns\AsAction;

class MerchantLTDS
{
  use AsAction;

  public function asController(Request $request): View
  {
    if (isset($request->financial_year)) {
      $ltdcs = LTDC::where('financial_year', $request->financial_year)->get();
    } else {
      $ltdcs = LTDC::get();
    }

    $financialYears = LTDC::distinct('financial_year')->orderByDesc('financial_year')->pluck('financial_year');
    return view('admin.ltdc', compact('ltdcs', 'financialYears'));
  }
}
