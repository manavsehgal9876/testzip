<?php

namespace App\Actions\Admin;

use Illuminate\Bus\Batch;
use App\Traits\FileUpload;
use App\Models\ImportSheet;
use Illuminate\Support\Str;
use App\Jobs\ProcessForm26AS;
use App\Imports\ImportForm26AS;
use App\Jobs\AfterForm26ASImport;
use App\Jobs\BeforeForm26ASImport;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Bus;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\BeforeImportForm26AS;
use Lorisleiva\Actions\Concerns\AsAction;

class UploadForm26ASExcelAndDispatchJob
{
  use AsAction, FileUpload;

  protected function handle($request)
  {
    if ($request->hasfile('excelSheet')) :
      $request->request->add(['sheet' => $this->handleSingleFileUpload($request->excelSheet, 'uploads/merchant/')]);
    endif;

    $fileNameWithPath = public_path('uploads/merchant/' . $request->sheet);

    ImportSheet::create([
      'file' => $request->sheet,
      'type' => 'form_26_as_sheet',
      'user_id' => auth()->user()->id,
      'user_type' => auth()->user()->type,
    ]);

    Bus::chain([
      new BeforeForm26ASImport(['file' => $fileNameWithPath]),
      // new AfterForm26ASImport(['file' => $fileNameWithPath]),
    ])->dispatch();
  }
}
