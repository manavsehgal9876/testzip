<?php

namespace App\Actions\Admin\Reports;

use Maatwebsite\Excel\Facades\Excel;
use App\Exports\Form26AsReportExport;
use Lorisleiva\Actions\Concerns\AsAction;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class Form26AsReports
{
  use AsAction;

  public function handle(string $financialYear): BinaryFileResponse
  {
    return Excel::download(new Form26AsReportExport($financialYear), 'form-26-as-report.xlsx');
  }
}
