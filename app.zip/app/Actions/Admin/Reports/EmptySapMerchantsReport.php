<?php

namespace App\Actions\Admin\Reports;

use Maatwebsite\Excel\Facades\Excel;
use App\Exports\Merchant\EmtpySapMerchantsExport;
use Lorisleiva\Actions\Concerns\AsAction;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class EmptySapMerchantsReport
{
  use AsAction;

  public function handle(): BinaryFileResponse
  {
    return Excel::download(new EmtpySapMerchantsExport, 'empty-sap-merchants-report.xlsx');
  }
}
