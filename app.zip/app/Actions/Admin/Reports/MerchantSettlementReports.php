<?php

namespace App\Actions\Admin\Reports;

use Maatwebsite\Excel\Facades\Excel;
use App\Exports\MerchantSettlementExport;
use Lorisleiva\Actions\Concerns\AsAction;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class MerchantSettlementReports
{
  use AsAction;

  public function handle(string $tanNumber): BinaryFileResponse
  {
    return Excel::download(new MerchantSettlementExport($tanNumber), 'merchant-settlement-report.xlsx');
  }
}
