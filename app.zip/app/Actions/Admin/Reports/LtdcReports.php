<?php

namespace App\Actions\Admin\Reports;

use App\Exports\LtdcReportExport;
use Maatwebsite\Excel\Facades\Excel;
use Lorisleiva\Actions\Concerns\AsAction;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class LtdcReports
{
  use AsAction;

  public function handle(string $financialYear): BinaryFileResponse
  {
    return Excel::download(new LtdcReportExport($financialYear), 'ltdc-report.xlsx');
  }
}
