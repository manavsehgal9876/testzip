<?php

namespace App\Actions\Admin\Reports;

use Maatwebsite\Excel\Facades\Excel;
use App\Exports\Merchant\MerchantsExport;
use Lorisleiva\Actions\Concerns\AsAction;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class MerhantsReport
{
  use AsAction;

  public function handle($emptySapCode = 0, $monthlyBankUpdate = 0): BinaryFileResponse
  {
    return Excel::download(new MerchantsExport($emptySapCode, $monthlyBankUpdate), 'merchants-report.xlsx');
  }
}
