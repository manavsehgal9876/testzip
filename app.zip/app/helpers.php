<?php

use App\Models\Extension\City;
use App\Models\Extension\State;
use App\Models\Extension\Country;
use App\Models\Admin\Company\CompanyStaff;

if (!function_exists('getDropdowns')) {
  function getDropdowns($dropdownName)
  {
    // return Dropdown::where([['displayflag', '=', 1], ['parent', '=', 0], ['dropdown_name', '=', $dropdownName]])->first();
  }
}

if (!function_exists('getCountries')) {
  function getCountries()
  {
    return Country::all();
  }
}

if (!function_exists('getStates')) {
  function getStates($countryId = 0)
  {
    return State::where('country_id', $countryId)->orderBy('name')->get();
  }
}

if (!function_exists('getCities')) {
  function getCities($stateId = 0)
  {
    return City::where('state_id', $stateId)->orderBy('name')->get();
  }
}

if (!function_exists('defaultProfileImage')) {
  function defaultProfileImage()
  {
    return asset('assets/merchantAssets/images/user.png');
  }
}

if (!function_exists('getDefaultStaffID')) {
  function getDefaultStaffID(): int
  {
    return CompanyStaff::where('email', config('myconfig.TDS_SUPER_EMAIL'))->value('id');
  }
}
