<?php

namespace App\View\Components;

use Illuminate\Support\Str;
use Illuminate\View\Component;

class Testimonials extends Component
{
  public $name;
  public $slug;
  public $content;
  public $icon;
  public $path;
  /**
   * Create a new component instance.
   *
   * @return void
   */
  public function __construct($name, $content, $icon, $path)
  {
    $this->name = Str::limit(ucwords(Str::lower($name)), 32);
    $this->content = $content;
    $this->icon = $icon;
    $this->path = $path;
  }

  /**
   * Get the view / contents that represent the component.
   *
   * @return \Illuminate\Contracts\View\View|\Closure|string
   */
  public function render()
  {
    return view('components.testimonials');
  }
}
