<?php

namespace App\View\Components;

use Illuminate\Support\Str;
use Illuminate\View\Component;

class CarePlanCard extends Component
{
  public $title;
  public $slug;
  public $shortDesc;
  public $thumbnail;
  public $path;
  public $viewCount;
  public $fees;
  public $progressBar;
  /**
   * Create a new component instance.
   *
   * @return void
   */
  public function __construct($title, $slug, $shortDesc, $thumbnail, $path, $viewCount, $fees, $progressBar)
  {
    $this->title = $title;
    $this->slug = $slug;
    $this->shortDesc = Str::limit($shortDesc);
    $this->thumbnail = $thumbnail;
    $this->path = $path;
    $this->viewCount = $viewCount;
    $this->fees = $fees === 0.00 || !isset($fees) ? 'Free' : number_format($fees, 0);
    $this->progressBar = $progressBar;
  }

  /**
   * Get the view / contents that represent the component.
   *
   * @return \Illuminate\Contracts\View\View|\Closure|string
   */
  public function render()
  {
    return view('components.care-plan-card');
  }
}
