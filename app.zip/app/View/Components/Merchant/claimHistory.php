<?php

namespace App\View\Components\Merchant;

use Illuminate\View\Component;

class claimHistory extends Component
{
  public $histories;
  /**
   * Create a new component instance.
   *
   * @return void
   */
  public function __construct($histories)
  {
    $this->histories = $histories;
  }

  /**
   * Get the view / contents that represent the component.
   *
   * @return \Illuminate\Contracts\View\View|\Closure|string
   */
  public function render()
  {
    return view('components.merchant.claim-history');
  }
}
