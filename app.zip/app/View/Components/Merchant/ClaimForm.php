<?php

namespace App\View\Components\Merchant;

use Illuminate\View\Component;

class ClaimForm extends Component
{
  public $claim;
  public string $route;
  public $form26AS;
  public float $grandTotalOfForm26AS;
  public float $grandTotalOfTds;
  public $ltdcs;
  /**
   * Create a new component instance.
   *
   * @return void
   */
  public function __construct($claim, string $route, $form26AS, $grandTotalOfForm26AS, $grandTotalOfTds, $ltdcs)
  {
    $this->claim = $claim;
    $this->route = $route;
    $this->form26AS = $form26AS;
    $this->grandTotalOfForm26AS = $grandTotalOfForm26AS;
    $this->grandTotalOfTds = $grandTotalOfTds;
    $this->ltdcs = $ltdcs;
  }

  /**
   * Get the view / contents that represent the component.
   *
   * @return \Illuminate\Contracts\View\View|\Closure|string
   */
  public function render()
  {
    return view('components.merchant.claim-form');
  }
}
