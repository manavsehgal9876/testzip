<?php

namespace App\Repositories\Admin;

use App\Repositories\BaseRepository;
use App\Models\Admin\Company\CompanyStaff;

class CompanyStaffRepository extends BaseRepository
{

  public function store($request, array $password)
  {
    $this->handleFiles($request);
    $staff = CompanyStaff::create($request->except('_token', 'photo') + $password);
    return CompanyStaff::find($staff->id);
  }

  public function update($request, $id)
  {
    $staff = CompanyStaff::find($id);
    $this->handleFiles($request, $staff);
    return $staff->update($request->except('_token', '_method', 'photo'));
  }

  public function handleFiles($request, $staff = null)
  {
    if ($request->hasfile('photo')) :
      $request->request->add(['image' => $this->handleSingleFileUpload($request->photo, 'uploads/company/')]);
      if (isset($staff))
        $this->handleDeleteFile($staff->image, 'company/');
    endif;
    return true;
  }

  public function toggleStatus($id)
  {
    $companyStaff = CompanyStaff::find($id);
    $companyStaff->status = $companyStaff->status ? 0 : 1;
    $companyStaff->save();
    return true;
  }

  public function destroy($id)
  {
    $staff = CompanyStaff::find($id);
    $this->handleDeleteFile($staff->image, 'company/');
    $staff->delete();
  }
}
