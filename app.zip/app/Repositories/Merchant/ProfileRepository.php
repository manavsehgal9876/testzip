<?php

namespace App\Repositories\Merchant;

use App\Models\User;
use App\Repositories\BaseRepository;

class ProfileRepository extends BaseRepository
{

  public function store($request)
  {
    $this->handleFiles($request);
    $request->merge(['added_by' => auth()->user()->id]);
    User::create($request->except('_token', 'pancard', 'gst', 'tan', 'logo_file', 'representative_photo'));
    return true;
  }

  public function update($request, $id)
  {
    $user = User::find($id);
    $this->handleFiles($request, $user);

    if (!isset($request->password))
      $request->request->remove('password');
    $user->update($request->except('_token', '_method', 'pancard', 'gst', 'tan', 'logo_file', 'representative_photo'));
    return true;
  }

  public function handleFiles($request, $user = null)
  {
    if ($request->hasfile('pancard')) :
      $request->request->add(['pan_document' => $this->handleSingleFileUpload($request->pancard, 'uploads/merchant/')]);
      if (isset($user))
        $this->handleDeleteFile($user->pancard_document, 'merchant/');
    endif;

    if ($request->hasfile('gst')) :
      $request->request->add(['gst_document' => $this->handleSingleFileUpload($request->gst, 'uploads/merchant/')]);
      if (isset($user))
        $this->handleDeleteFile($user->gst_document, 'merchant/');
    endif;

    if ($request->hasfile('tan')) :
      $request->request->add(['tan_document' => $this->handleSingleFileUpload($request->tan, 'uploads/merchant/')]);
      if (isset($user))
        $this->handleDeleteFile($user->tan_document, 'merchant/');
    endif;

    if ($request->hasfile('logo_file')) :
      $request->request->add(['logo' => $this->handleSingleFileUpload($request->logo_file, 'uploads/merchant/')]);
      if (isset($user))
        $this->handleDeleteFile($user->tan_document, 'merchant/');
    endif;

    if ($request->hasfile('representative_photo')) :
      $request->request->add(['representative_image' => $this->handleSingleFileUpload($request->representative_photo, 'uploads/merchant/')]);
      if (isset($user))
        $this->handleDeleteFile($user->representative_image, 'merchant/');
    endif;
    return true;
  }
}
